<?php

class WPLMS_Front_End_Generate_Fields {

	function __construct(){

	}

	function generate_fields(){
		case 'text':
		break;
		case 'switch':
		break;
		
		case 'date':
		break;
		case 'textarea':
		break;
		case 'editor':
		break;

	}

}