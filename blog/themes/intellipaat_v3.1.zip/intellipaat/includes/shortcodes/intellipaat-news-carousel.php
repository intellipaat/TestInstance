<?php 

add_shortcode('new_carousel','news_carousel_generator');

function news_carousel_generator($atts){
	
	extract( shortcode_atts( array(

      'id'   => '',
	  'class'=> '',
	  
      ), $atts ) );
	
	$output = " ";
	
	$args = array(
			'showposts' => -1,
			'post_type' => 'news'			
		);
	$query = new WP_Query( $args );
	
	if($query->have_posts()){
		
		
		 $output .= "<div id='news_carousel' class='news_carousel flexslider'  data-block-min='1' data-block-max='1' data-block-width='268'>";
		 
		   $output .= "<h3 class='heading'> News</h3>";
		   
		   $output .= "<a class='heading_more' href='http://bigdataonlinetraining.us/media/'>+</a>";
		 
			$output .= "<ul class='slides'>";
		
			 while ( $query->have_posts() ) { $query->the_post();
				
				$output .= "<li>";
				
					$output .= "<div class='block side'>";
						
					   $output .= "<div class='block_media'>";
					   
					   		$output .= '<a href="'.get_post_meta(get_the_id(),'intellipaat-post-href',true).'">' . get_the_post_thumbnail( get_the_id()) . '</a>';
						
					   $output .= "</div>";
					
						$output .= "<div class='block_content'>";
						
							$output .= '<h4 class="block_title"><a  class="course_icon_text" href="'.get_post_meta(get_the_id(),'intellipaat-post-href',true).'">' . get_the_title() . '</a></h4>';
							
							$output .= "<div class='date'>";
							
							$output .=  "<small>".get_the_date()."</small>";
							
							$output .= "</div>";
							
							$output .= "<p class='block_desc'>".get_the_excerpt()."</p>";
							
					    $output .= "</div>";					
					
					$output .= "</div>";
					
				$output .= "</li>"; 
				
			}
			
			$output .= "</ul>";			
			
		  $output  .= "</div>";
		  
		  wp_reset_postdata();
			
		//$output .= "</div>";
		
	}
	
	return $output;
}

?>
