<footer class="hidden-sm hidden-xs">
    <div class="container">
        <div class="row">
            <div class="footertop">
                <?php 
                           /* if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('topfootersidebar') ) : ?>
                <?php endif;*/ 
					if(function_exists('intellipaat_recent_posts'))
						intellipaat_recent_posts();
				
				?>
            </div>
        </div>
        <div class="row">
            <div class="footerbottom">
                <?php 
                    if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('bottomfootersidebar') ) : ?>
                <?php endif; ?>
            </div>
        </div>
    </div> 
</footer>
<div id="footerbottom">
    <div class="container">
        <div class="row">       
            <div <?php /*?>id="footermenu"<?php */?> class="col-md-8 hidden-sm hidden-xs">
                <?php
                        $args = array(
                            'theme_location'  => 'footer-menu',
                            'container'       => '',
                            'menu_class'      => 'footermenu',
                            'fallback_cb'     => 'vibe_set_menu',
                        );
                        wp_nav_menu( $args );
                ?>
            </div> 
            <div id="copyright" class="col-md-4 text-right">
            	&copy; Copyright 2011-<?php echo date('Y');?> intellipaat.com. All Rights Reserved
            </div>
                         
            
            	
            
               <?php /*?><div id="footer-right" class="sidebar col-md-3  col-sm-6 hidden-xs">
                    <a class="btns teach " href="<?php echo esc_url( get_permalink( get_page_by_title( 'Become an Instructor' ) ) ); ?>">
                        <i class="icon-rocket"></i>
                        Teach on Intellipaat
                    </a>
                    
                    <a class="btns ufo" href="<?php echo esc_url( get_permalink( get_page_by_title( 'Intellipaat For Organizations' ) ) ); ?>">
                        <i class="icon-building-24"></i>
                        Intellipaat For Organizations
					</a>                    
               </div>
                    	<?php */?>	
            
        </div>

        <div class="row">
        	<div class="secure-pay">
            	<p class="secure-pay-info"><strong>100%</strong> Secure Payments. All major credit & debit cards accepted Or Pay by Paypal.</p>

            	<p class="pay_methods"><?php /*?>Payment method <?php */?><span> </span></p>
             </div>
        </div>
    </div>
    
    <div id="scrolltop">
        <a><i class="icon-arrow-1-up"></i><span><?php _e('top','vibe'); ?></span></a>
    </div>
    
</div>

<nav id="info-stripe" class="navbar navbar-default navbar-fixed-bottom">
  <div class="info-stripe-container">
  
        <p id="how-it-works" class="navbar-left hidden-xs">
        	<a href="#" class="navbar-link"><i class="icon-lightbulb-shine"></i><span class="text">How our support Works?</span></a>
        </p>
        <div id="support-process-wrap" class="hidden">
            <div class="container">
       			 <div class="row">
                    <div class="support-process aligncenter">
                    	<button type="button" class="close-popup" title="Close"><i class="icon-cross"></i></button>
                        <img class="resonsive-img" src="<?php echo get_stylesheet_directory_uri()?>/images/support_process.png">
                    </div>
        		</div>
			</div>
        </div>
        
        <p id="live_chat" class="navbar-right fr">
        	<a href="#" class="navbar-link"><i class="icon-chat mail"></i><span class="text">Live chat</span></a>
        </p>
        
        <div class="navbar-right">
        	<div class="contact-no"  itemscope itemtype="http://schema.org/Person">
                <meta content="<?php  bloginfo('name');  ?>" itemprop="name">
                <span class="india-number">
                	<i class="icon-call-old-telephone phone"> </i>  
                    <span itemprop="telephone"><span class="phone-1">+91-8769551384</span><span class="phone-2"> / +91-9784286179</span> </span>
                </span> 
                <span class="us-toll"><strong>US :</strong>   <span itemprop="telephone">1-800-216-8930</span>(Toll Free)</span>
                <span class="hdmaito">
                    <a href="mailto:sales@intellipaat.com" itemprop="email" style="text-transform:lowercase;">
                    	<i class="icon-letter-mail-1 mail"></i>sales@intellipaat.com
                    </a>
                </span>
            </div>
        </div>
    	
  </div>
</nav>

</div><!-- END PUSHER -->
</div><!-- END MAIN -->


	<!-- SCRIPTS -->
 
<?php
wp_footer();
?>    
<?php
echo vibe_get_option('google_analytics');
?>
</body>
</html>