<?php 

add_shortcode('reviews','reviews_generator');

function reviews_generator($atts){
	global $wpdb;

	/*
	extract( shortcode_atts( array(

      		'id'   => '',
	  
      ), $atts ) );
	*/
	/*$output = "";
	 $args = array(
        'number'=>160,
        'offset'=>0,
        'status'=>'approve',
        'order'=>'DESC',
		'orderby'=>'comment_author_email',
    );
	 */
	//$comments = get_comments($args);
	//$query = "SELECT * FROM $wpdb->comments as c JOIN (SELECT DISTINCT comment_author, comment_author_email FROM $wpdb->comments) as dc WHERE c.comment_author_email = dc.comment_author_email ORDER BY c.comment_date_gmt DESC LIMIT 160"; var_dump($query);

	$query = "SELECT DISTINCT * FROM $wpdb->comments WHERE comment_type = '' AND comment_approved = '1' GROUP BY comment_author_email ORDER BY comment_date_gmt DESC LIMIT 80";
	
	$comments = $wpdb->get_results( $query );
	
	$output = '<div class="reviewlist commentlist"> ';
	$count = 0;
	
	foreach($comments as $comment ){
			
			if($count %2 == 0) $output .= '<div class="row"> ';
		
			$rating ='';
			$url = ('http://' == $comment->comment_author_url) ? '' : $comment->comment_author_url;
				$url = esc_url( $url, array('http', 'https') );
				if( $url ) {
						$url  = '<div class="pull-right">Follow Me on <a rel="nofollow noindex" class="linkedin_url" href="' . esc_attr( $url  ) . '">LinkedIn</a></div>';
				}  
				else
					$url ='';
				  
			$commenttitle = get_comment_meta($comment->comment_ID, 'review_title', true );
			if( $commentrating = get_comment_meta( $comment->comment_ID, 'review_rating', true ) ) {
			  $rating .= '<div class="comment-rating star-rating">';
			  for($i=0;$i<5;$i++){
				if($commentrating > $i)
				  $rating .='<span class="fill"></span>';
				else
				  $rating .='<span></span>';
			  }
			  $rating .='</div>'; 
			}  
			
			$output .= '<div class="col-md-6"> ';
				$output .= '<div class="col-md-6 comment"> ';
					 $output .=   '<div class="comment-body" id="div-comment-'.$comment->comment_ID.'">
											<div class="comment-author vcard">
											'.get_avatar( $comment->comment_author_email , 120 ).'			<cite class="fn">'.apply_filters( 'comment_author',$comment->comment_author ) .'</cite> 	
											</div>
									
							
									<p>' .( ( $commenttitle) ? '<strong>' . esc_attr( $commenttitle ) . '</strong><br/><br/>' : '').$comment->comment_content.'</p>
									'.$rating.'
									'.$url .'
								</div>'; 
				$output .= '</div> '; 
			$output .= '</div> '; 
			
			if($count %2 == 1) $output .= '</div> ';
			$count++;
	}
	$output .= ' </div> ';
	$output .=   paginate_comments_links( array('prev_text' => '&laquo;', 'next_text' => '&raquo;') );
	return $output;
}

?>
