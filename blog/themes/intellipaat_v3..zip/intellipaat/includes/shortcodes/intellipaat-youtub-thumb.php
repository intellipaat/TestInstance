<?php 

add_shortcode( 'videothumb', 'video_thumbnail' );

function video_thumbnail($atts){
	
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < 5; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
	
	extract( shortcode_atts( array(

		  'id'   => 'Rq6kcjUubbU',
		  'class'=> 'col-md-4',
		  'name' => ''

      ), $atts ) );
	
	
	$output = "<div class='thumb_course_links ".$class."'>";	
	
		$output .= "<div class='crop_thumb'>";			
			
				//if(is_user_logged_in() || isset($_COOKIE['intellipaat_visitor']) ){
			
					$output .= "<a class='hs-rsp-popup popup-youtube hiddendiv' href='http://www.youtube.com/watch?v=".$id."'>";
					
					$output .= "<img src='//img.youtube.com/vi/".$id."/0.jpg' height='150px' width='200px' title='Click to watch video' class='thumb-img'>";
										
					$output .= "<span class='play-video icon-play-alt'></span></a>";
								
				/*}
				else{
	
					$output .="<a class='popup-with-form' href='#login-form'>";
					
					$output .= "<img src='//img.youtube.com/vi/".$id."/0.jpg' height='150px' width='200px' class='thumb-img'>";
										
					$output .= "<span class='play-video icon-play-alt'></span></a>";
	
				}*/
		
		$output .= "</div>";
		
		if(isset($name) && $name!=''){			
			$output .= "</span><p>$name</p>";			
		}
		
	$output .= "</div>";
		
	return $output;
}


add_action('wp_footer','form_to_login_user');

function form_to_login_user(){	
	
	if(is_user_logged_in() || isset($_COOKIE['intellipaat_visitor']) || !is_singular( 'course' ))
		return;
		
    global $post;
	?>	
    
	<div id="login-form"  class="white-popup-block mfp-hide">
		<?php global $user_ID, $user_identity; get_currentuserinfo();  ?>      
              
        <div id="login-div" class="row tab_content_login clearfix">
            
            <?php /*?><div class="col-md-6 col-md-offset-0 login-sub visible login">
                <h2>Signup or Login</h2>    
    
                <?php do_action( 'wordpress_social_login' ); ?> 
                
            </div><!--login-sub ends--><?php */?>
            
		   <?php
                $nonce = wp_create_nonce("intellipaat_visitor_secure_signup_nonce");
                $link = admin_url('admin-ajax.php?action=intellipaat_visitor_secure_signup');
            ?>
            
            <div class="col-md-10 col-md-offset-1 login-sub visible register">
                <h2>Enter your details</h2>
                
                 <form method="post" action="<?php echo $link; ?>" name="signup_form" id="signup_form" class="wp-user-form">                                 
                
                    <div class="row">
                       <div class="input-group  col-md-6">
                          <span class="input-group-addon  icon-user"></span>
                          <input type="text" class="form-control" name="first_name" required="required"  size="20" id="first_name" tabindex="1" placeholder="First Name (Required)"/> 
                        </div>
                       <div class="input-group  col-md-6">
                          <span class="input-group-addon  icon-user"></span>
                          <input type="text" class="form-control" name="last_name" required="required"  size="20" id="last_name" tabindex="2" placeholder="Last Name (Required)"/> 
                        </div>
                    </div>
                    <br />
                    <div class="input-group">
                        <span class="input-group-addon icon-globe"></span>
                        <select class="form-control chosen-select" name="country" required="required" tabindex="3"  data-placeholder="<?php _e( 'Choose country &hellip;', 'woocommerce' ); ?>" title="Select your Country">	
                        	<option value=""></option>	
                        	<?php 
								$countries = WC()->countries->countries;
								foreach($countries as $country_code => $country){
										echo '<option value="'.$country_code.'">'.$country.'</option>';
									}
							?>
                        </select> 
                    </div>
                    <br />
                    <div class="input-group">
                        <span class="input-group-addon icon-envelope"></span>
                        <input type="email" class="form-control" name="user_email" required="required"  size="20" id="user_login" tabindex="4" placeholder="Email Address (Required)"/> 
                    </div>
                    <br />
                    <div class="input-group">
                        <span class="input-group-addon icon-telephone-24"></span>
                        <input type="text"  class="form-control"  name="phone"  placeholder="Phone (Optional)" id="phno" tabindex="5" />
                    </div>
                    <br />       
                                                           
                    <input type="hidden" name="nonce" value="<?php echo $nonce ; ?>" class="SecKey" /> 
                    <input type="hidden" name="page_id" value="<?php echo $post->ID ; ?>" />        
                    <input type="submit" name="user-submit"  id="signup_submit" value="Submit" tabindex="6" class="pull-right user-submit"/>                        
                   
                 </form>
            </div><!--login sub ends-->
        </div>
    </div>
    <?php wp_enqueue_script('jquery-cookie');
}
?>