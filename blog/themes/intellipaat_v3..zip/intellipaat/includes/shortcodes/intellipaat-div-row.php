<?php
function row_shortcode($atts, $content)
{
	$divrow = "<div class='row'>".$content."</div>";
	return $divrow;
}
add_shortcode('row','row_shortcode');
?>