<?php

include("course/index.php");

?>