<?php

/*
*	WP ajax to send sale initiate email to admin
*/
add_action("wp_ajax_intellipaat_userbase", "intellipaat_userbase_callback");
add_action("wp_ajax_nopriv_intellipaat_userbase", "intellipaat_userbase_callback");

function intellipaat_userbase_callback() {
	die(intellipaat_userbase());
}

function intellipaat_userbase(){
	if(TLD == 'com'){
		global $wpdb;
		return $wpdb->get_var( $wpdb->prepare( 
			"
				SELECT sum(meta_value) 
				FROM $wpdb->postmeta 
				WHERE meta_key = %s
			", 
			'vibe_students'
		) );
	}
	else{
		$user_total = file_get_contents('https://intellipaat.com/wp-admin/admin-ajax.php?action=intellipaat_userbase');
		if($user_total)
			return $user_total;
		else 
			return '200,000';
	}
}


/*
*	WP ajax to send sale initiate email to admin
*/
add_action("wp_ajax_intellipaat_visitor_purchase", "intellipaat_visitor_purchase_callback");
add_action("wp_ajax_nopriv_intellipaat_visitor_purchase", "intellipaat_visitor_purchase_callback");

function intellipaat_visitor_purchase_callback() {

  /* if ( !wp_verify_nonce( $_REQUEST['nonce'], "intellipaat_visitor_purchase_nonce")) {
      exit("No naughty business please");
   } 
   
	$nonce = wp_create_nonce("intellipaat_visitor_purchase_nonce"); 
	*/  
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {

		$now = date('Y-m-d H:i:s');

		$message = '<!DOCTYPE HTML>
						<html>
						<head></head>
						<body>
							<tableborder="1" cellpadding="5" bordercolor="#333333">
								<tr><td style="border:1px solid #cdcdcd;">Key</td><td style="border:1px solid #cdcdcd;>Value</td></tr>';
							
								foreach($_REQUEST as $k => $v){
									$message .=	'<tr style="border:1px solid #cdcdcd;><td>'.$k.'</td><td style="border:1px solid #cdcdcd;>'.$v.'</td></tr>';
								}
								/*<strong>New Visitor</strong> @ '.site_url().' <br /><br />
								<strong>Email</strong> : '.$_REQUEST['billing_email'].' <br />
								<strong>Phone</strong> : '.$_REQUEST['phone'].'  <br />
								<strong>Visited url</strong> : '.get_permalink($_REQUEST['page_id']).'<br />
								<strong>IP Address </strong>: '.$_SERVER['REMOTE_ADDR'].' <br />
								<strong>Date/time</strong> '.$now.'*/

			$message .=				'</table>
										<hr />';
			
			ob_start(); ?>
			
							<table border="1" cellpadding="5" bordercolor="#333333" class="shop_table">
								<thead>
									<tr>
										<th class="product-name"><?php _e( 'Product', 'vibe' ); ?></th>
										<th class="product-total"><?php _e( 'Total', 'vibe' ); ?></th>
									</tr>
								</thead>
								<tfoot>
						
									<tr class="cart-subtotal">
										<th><?php _e( 'Cart Subtotal', 'vibe' ); ?></th>
										<td><?php wc_cart_totals_subtotal_html(); ?></td>
									</tr>
						
									<?php foreach ( WC()->cart->get_coupons( 'cart' ) as $code => $coupon ) : ?>
										<tr class="cart-discount coupon-<?php echo esc_attr( $code ); ?>">
											<th><?php _e( 'Coupon:', 'vibe' ); ?> <?php echo esc_html( $code ); ?></th>
											<td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
										</tr>
									<?php endforeach; ?>
						
									<?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>
						
										<?php do_action( 'woocommerce_review_order_before_shipping' ); ?>
						
										<?php wc_cart_totals_shipping_html(); ?>
						
										<?php do_action( 'woocommerce_review_order_after_shipping' ); ?>
						
									<?php endif; ?>
						
									<?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
										<tr class="fee">
											<th><?php echo esc_html( $fee->name ); ?></th>
											<td><?php wc_cart_totals_fee_html( $fee ); ?></td>
										</tr>
									<?php endforeach; ?>
						
									<?php if ( WC()->cart->tax_display_cart === 'excl' ) : ?>
										<?php if ( get_option( 'woocommerce_tax_total_display' ) === 'itemized' ) : ?>
											<?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
												<tr class="tax-rate tax-rate-<?php echo sanitize_title( $code ); ?>">
													<th><?php echo esc_html( $tax->label ); ?></th>
													<td><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
												</tr>
											<?php endforeach; ?>
										<?php else : ?>
											<tr class="tax-total">
												<th><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
												<td><?php echo wc_price( WC()->cart->get_taxes_total() ); ?></td>
											</tr>
										<?php endif; ?>
									<?php endif; ?>
						
									<?php foreach ( WC()->cart->get_coupons( 'order' ) as $code => $coupon ) : ?>
										<tr class="order-discount coupon-<?php echo esc_attr( $code ); ?>">
											<th><?php _e( 'Coupon:', 'vibe' ); ?> <?php echo esc_html( $code ); ?></th>
											<td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
										</tr>
									<?php endforeach; ?>
						
									<?php do_action( 'woocommerce_review_order_before_order_total' ); ?>
						
									<tr class="order-total">
										<th><?php _e( 'Order Total', 'vibe' ); ?></th>
										<td><?php wc_cart_totals_order_total_html(); ?></td>
									</tr>
						
									<?php do_action( 'woocommerce_review_order_after_order_total' ); ?>
						
								</tfoot>
								<tbody>
									<?php
										do_action( 'woocommerce_review_order_before_cart_contents' );
						
										foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
											$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
						
											if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
												?>
												<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
													<td class="product-name">
														<?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key ); ?>
														<?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <strong class="product-quantity">' . sprintf( '&times; %s', $cart_item['quantity'] ) . '</strong>', $cart_item, $cart_item_key ); ?>
														<?php echo WC()->cart->get_item_data( $cart_item ); ?>
													</td>
													<td class="product-total">
														<?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?> <small>(Inclusive of all taxes)</small>
													</td>
												</tr>
												<?php
											}
										}
						
									?>
								</tbody>
							</table>

                     <?php
				$cart =	ob_get_contents();
				ob_end_clean();
		$message .=				$cart.'</body>
						</html>' ;
		
		$headers .= "Reply-To: ".$_REQUEST['billing_email']." \r\n";
		
		$headers .= "MIME-Version: 1.0 \r\n";
		
		$headers .= "Content-type: text/html; charset=utf-8 \r\n";
		
		$headers .= "Content-Transfer-Encoding: quoted-printable \r\n";
					
		wp_mail( get_option( 'admin_email' ) , "A new sale initiated by ".$_REQUEST['billing_first_name']." ".$_REQUEST['billing_last_name']."@ ".site_url(), $message, $headers); 
		
		global $wpdb;
		
		/*$now = date('Y-m-d H:i:s');
		$wpdb->insert( 
			$wpdb->prefix.'cf7dbplugin_submits', 
			array( 
				'submit_time' 	=> 	$now ,
				'form_name'		=>	'Checkout New Sales',
				'field_name'	=>	'',
				'email'			=> 	$_REQUEST['user_email'] ,
				'phone' 		=> 	$_REQUEST['phone'], 
				'ip' 			=> 	$_SERVER['REMOTE_ADDR'] ,
				'visited_url' 	=> 	get_permalink($_REQUEST['page_id']), 
			)
		);
		*/
		$result['type'] = "success";
		$result['inserted_row'] = $wpdb->insert_id ;
      	$result = json_encode($result);
      	echo $result;
   }
   else {
      header("Location: ".$_SERVER["HTTP_REFERER"]);
   }

   die();
}


/*
*	WP ajax to get secutiry key for visitor form
*/
add_action("wp_ajax_nopriv_intellipaat_visitor_secure_key", "intellipaat_visitor_secure_key_callback");

function intellipaat_visitor_secure_key_callback() {
	die( wp_create_nonce("intellipaat_visitor_secure_signup_nonce") );
}

/*
*	WP ajax to to submit visitor form and regirter user.
*/
add_action("wp_ajax_nopriv_intellipaat_visitor_secure_signup", "intellipaat_visitor_secure_signup_callback");

function intellipaat_visitor_secure_signup_callback() {

   if ( !wp_verify_nonce( $_REQUEST['nonce'], "intellipaat_visitor_secure_signup_nonce") && !is_singular( 'course' )) {
      exit("No naughty business please");
   }   
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
	   		
		$fname  = isset($_REQUEST['first_name']) ? $_REQUEST['first_name'] : '' ;
		$lname  = isset($_REQUEST['last_name']) ? $_REQUEST['last_name'] : '' ;
		$email = $_REQUEST['user_email'];
		$mobile = isset($_REQUEST['phone']) ? $_REQUEST['phone'] : '';
		$country_code = $_REQUEST['country'];
		$country = WC()->countries->countries[$country_code];
		$course_title  = html_entity_decode(get_the_title($_REQUEST['page_id']),ENT_QUOTES, 'UTF-8');
		$description  = '';
		$referer  = get_permalink($_REQUEST['page_id']);
		$lead_source = 'Visitor Sign Up';
		
		global $wpdb;
		$now = date('Y-m-d H:i:s');
	   	$wpdb->insert( 
			$wpdb->prefix.'intellipaat_visitors', 
			array( 
				'name' => $fname.' '.$lname,
				'email' => $email,
				'phone' => $mobile, 
				'country' => $country,
				'course' => $course_title, 
				'ip' => $_SERVER['REMOTE_ADDR'] ,
				'visited_url' => $referer, 
				'date_time' => $now ,
			)
		);	 //adding record to visitor table	
		$visitor_id = $wpdb->insert_id;
		$result['inserted_row'] = $visitor_id ;
		
		setcookie('intellipaat_visitor', true, time()+60*60*24*30, '/');
		setcookie('intellipaat_visitor_email', $email, time()+60*60*24*30, '/');
		if($mobile)
			setcookie('intellipaat_visitor_phone', $mobile, time()+60*60*24*30, '/');	
		
		/***** Updating student count on course page ******/
		$udate_result = $wpdb->query(
							 $wpdb->prepare( "UPDATE $wpdb->postmeta  SET meta_value =  meta_value + 1 WHERE  meta_key LIKE 'vibe_students' AND post_id=%d", $_REQUEST['page_id'])
						);
		if($udate_result)
			$result['student_count'] = 'updated student count. '.$udate_result;		
		
		/***** Validating email address ******/
		//$email_object = verify_email($email);
		$verify_status = 1;//$email_object->verify_status;
		
		/*$email_status_in_mail = '<br><br>
			<strong>Verify Status</strong> - ' . ($verify_status ? "OK" :"BAD"). '<br>
			<strong>Verify status_desc</strong> - ' . $email_object->verify_status_desc.'<br><br>
			<strong>verify-email.org Authentication status</strong> - ' . ($email_object->authentication_status ? "success" : "invalid user") .'<br>
			<strong>Limit status</strong> - ' . ($email_object->limit_status ? " verification is not allowed": "not limited" ). '<br>
			<strong>Limit desc</strong> - ' . $email_object->limit_desc  ;
		
		/***** Adding to log table ******/
		/*if($verify_status)
			$desc='Valid Email';
		else if(!$email_object->verify_status_desc)
			$desc='Fake email or may be from Invalid Domain';
		else{
			$desc = strip_tags($email_object->verify_status_desc);
			$desc=substr($desc , strpos($desc, '550'), 99);
		}*/
		
		/*$wpdb->insert( 
			$wpdb->prefix.'intellipaat_visitors_log', 
			array( 
				'id' => $visitor_id,
				'email' => $email,
				'flag' => $verify_status, 
				'reason' => $desc,
			)
		);	 //adding record to visitor table	
		$visitor_id = $wpdb->insert_id;*/
		
		/* Zoho code disabled temporary
		$xml  = '<?xml version="1.0" encoding="UTF-8"?>'; // same error with or without this line
		$xml .= '<Leads>';
		$xml .= '<row no="1">';
		if(isset($fname)) $xml .= '<FL val="First Name">'.$fname.'</FL>';
		if(isset($lname)) $xml .= '<FL val="Last Name">'.$lname.'</FL>';
		$xml .= '<FL val="Email">'.$email.'</FL>';
		if(isset($mobile))  $xml .= '<FL val="Mobile">'.$mobile.'</FL>';
		$xml .= '<FL val="Country">'.$country.'</FL>';
		$xml .= '<FL val="Courses">'.html_entity_decode($course_title,ENT_QUOTES, 'UTF-8').'</FL>';
		$xml .= '<FL val="Lead Source">'.$lead_source.'</FL>';
		$xml .= '<FL val="Referrer">'.$referer.'</FL>';
		$xml .= '</row>';
		$xml .= '</Leads>';
		ZohoCRM_API_call($xml); //Zoho CRM API call for lead genaration.*/
		
		/*** Sugar CRM api Call ****
		$session_id = intellipaat_LoginToSugarCRM();
		$parameters = array(
								"session" => $session_id,
								"module_name" => "Leads",
								'name_value_list'=>array(  
										array('name'=>'first_name','value'=>$fname ),  
										array('name'=>'last_name','value'=>$lname ),  
										array('name'=>'status', 'value'=>'New'),  
										array('name'=>'phone_mobile', 'value'=>$mobile),  
										array('name'=>'lead_source','value'=>str_replace(' ','_',$lead_source)), 
										array('name'=>'primary_address_country','value'=>$country),
										array('name'=>'email1','value'=>$email),  
										array('name'=>'description','value'=>$description ),  
										array('name'=>'reference_url_c','value'=>$referer  ),  
										array('name'=>'course_title_c','value'=>$course_title ),
									)								
							);
		
		SugarCRM_API_call("set_entry", $parameters);*/
		
		/*** Create user account on website if email is valid and account not present with same mail address **/
		if ( email_exists($email) == false && $verify_status ) {
			$user_id = wc_create_new_customer($email);
			
			if ( !is_wp_error( $user_id ) ){
				$userdata = array(
					'ID'			=>  $user_id,
					'first_name'	=>  $fname,
					'last_name'		=>  $lname,
					'display_name' 	=>	$fname.' '.$lname,
				);
				
				wp_update_user( apply_filters( 'woocommerce_checkout_customer_userdata', $userdata, $this ) );
				
				update_user_meta($user_id, 'billing_first_name', $fname);
				update_user_meta($user_id, 'shipping_first_name', $fname);
				update_user_meta($user_id, 'billing_last_name', $lname);
				update_user_meta($user_id, 'shipping_last_name', $lname);
				update_user_meta($user_id, 'billing_email', $email);
				update_user_meta($user_id, 'billing_phone', $mobile);
				update_user_meta($user_id, 'billing_country', $country_code);
				update_user_meta($user_id, 'shipping_country', $country_code);
				wp_set_current_user($user_id);
				wp_set_auth_cookie($user_id);
				$result['user_id'] = $user_id ;	
			}	
			else{ //If user creation fails then send an email to admin 
				wp_mail( "mane.makarand@gmail.com" , "Visitor Sign up form user creation failure", print_r($user_id, TRUE) ); 
				$result['user'] = "No user account created and mail sent to admin";
			}
		} 
		
		/***** Send mail to amin *****/
		$message = '<!DOCTYPE HTML>
						<html>
						<head></head>
						<body>
							<p>
								<strong>New Visitor</strong> @ '.site_url().' <br /><br />
								<strong>Full Name</strong> : '.$fname.' '.$fname.' <br />
								<strong>Email</strong> : '.$email.' <br />
								<strong>Phone</strong> : '.$mobile.'  <br />
								<strong>Country</strong> : '.$country.'  <br />
								<strong>Course Title</strong> : '.$course_title.'  <br />
								<strong>Visited url</strong> : '.$referer.'<br />
								<strong>IP Address </strong>: '.$_SERVER['REMOTE_ADDR'].' <br />
								<strong>Date/time</strong> '.$now.$email_status_in_mail. '
							</p>
						</body>
						</html>' ;
		
		$headers .= "Reply-To: ".$email." \r\n";
		
		$headers .= "MIME-Version: 1.0 \r\n";
		
		$headers .= "Content-type: text/html; charset=utf-8 \r\n";
		
		$headers .= "Content-Transfer-Encoding: quoted-printable \r\n";
		
		$headers .= 'Cc: sales@intellipaat.com' . "\r\n";
					
		wp_mail( get_option( 'admin_email' ) , "New visitor @ ".site_url(), $message, $headers); 
		
		if($verify_status)
			intellipaat_add_visitor_to_abandon();
		
		$result['type'] = "success";
		$result['email_status'] = $verify_status;
		$result['desc'] = $desc;
      	$result = json_encode($result);
      	echo $result;
   }
   else {
      header("Location: ".$_SERVER["HTTP_REFERER"]);
   } 

   die();
}

/*
Query to create table

CREATE TABLE IF NOT EXISTS `ip_intellipaat_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `visited_url` varchar(150) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

*/

function verify_email($email){

	$username	= 'mkrndmane';
	$password	= 'maxs150188';
	$api_url	= 'http://api.verify-email.org/api.php?';
				
	$url		= $api_url . 'usr=' . $username . '&pwd=' . $password . '&check=' . $email;
	
	$object		= json_decode(remote_get_contents($url)); // the response is received in JSON format; here we use the function remote_get_contents($url) to detect in witch way to get the remote content
			
	return $object;
			
	/*echo 'The email address ' . $email . ' is ' . ($object->verify_status?'GOOD':'BAD or cannot be verified') . '  '; 
	echo 'authentication_status - ' . $object->authentication_status . ' (your authentication status: 1 - success; 0 - invalid user)'; 
	echo 'limit_status - ' . $object->limit_status . ' (1 - verification is not allowed, see limit_desc; 0 - not limited)'; 
	echo 'limit_desc - ' . $object->limit_desc . ' '; 
	echo 'verify_status - ' . $object->verify_status . ' (entered email is: 1 - OK; 0 - BAD)'; 
	echo 'verify_status_desc - ' . $object->verify_status_desc . ' ';*/

}

// Get remote file contents, preferring faster cURL if available
function remote_get_contents($url)
{
        if (function_exists('curl_get_contents') AND function_exists('curl_init'))
        {
                return curl_get_contents($url);
        }
        else
        {
                // A litte slower, but (usually) gets the job done
                return file_get_contents($url);
        }
}

function curl_get_contents($url)
{
        // Initiate the curl session
        $ch = curl_init();
        
        // Set the URL
        curl_setopt($ch, CURLOPT_URL, $url);
        
        // Removes the headers from the output
        curl_setopt($ch, CURLOPT_HEADER, 0);
        
        // Return the output instead of displaying it directly
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        
        // Execute the curl session
        $output = curl_exec($ch);
        
        // Close the curl session
        curl_close($ch);
        
        // Return the output as a variable
        return $output;
}

function intellipaat_add_visitor_to_abandon() {
	
	if(TLD != 'com' && TLD != 'us' )
		return;
		
	if(is_user_logged_in()) {
		
		global $woocommerce;
		
		if (function_exists('WC')) {
			$visitor_cart = WC()->cart->get_cart();
		} else {
			$visitor_cart = $woocommerce->cart->get_cart();
		}
		
		if ( sizeof( $visitor_cart ) <= 0 ){
			//if there is nothing in cart then I have added same course in cart.
			$course_id = $_REQUEST['page_id']; 			
			$pid=get_post_meta($course_id,'vibe_product',true);
			if(!$pid)
				$pid=get_post_meta($course_id,'intellipaat_online_training_course',true);
			
			if($pid)
				$woocommerce->cart->add_to_cart( $pid );
			else
				return;	
				
			$visitor_cart = $woocommerce->cart->get_cart();
			
			if ( sizeof( $visitor_cart ) <= 0 )
				return ;
			
			do_action( 'woocommerce_cart_updated' );
			
			$cart = WC()->instance()->cart;
			$cart_id = $cart->generate_cart_id($pid);
			$cart_item_id = $cart->find_product_in_cart($cart_id);
			
			if($cart_item_id){
			   $cart->set_quantity($cart_item_id,0);
			}
		}else{
			do_action( 'woocommerce_cart_updated' );
		}

		
	}else {
		intellipaat_rac_guest_entry_checkout_ajax(); // modified function for Guests
	}

}

function intellipaat_rac_guest_entry_checkout_ajax(){
	
	global $woocommerce;
	if (!is_user_logged_in()) {
		if (!isset($_COOKIE['rac_cart_id'])) { //means they didn't come mail
			if (function_exists('icl_register_string')) {
				$currentuser_lang = isset($_SESSION['wpml_globalcart_language']) ? $_SESSION['wpml_globalcart_language'] : ICL_LANGUAGE_CODE;
			} else {
				$currentuser_lang = 'en';
			}
			$visitor_mail = $_POST['user_email'];
			$visitor_first_name = $_POST['first_name'];
			$visitor_last_name = $_POST['last_name'];
			$visitor_phone = $_POST['phone'];
			$ip_address = $_SERVER["REMOTE_ADDR"];
		
			if (function_exists('WC')) {
				$visitor_cart = WC()->cart->get_cart();
			} else {
				$visitor_cart = $woocommerce->cart->get_cart();
			}
			
			if ( sizeof( $visitor_cart ) <= 0 ){
				//if there is nothing in cart then I have added same course in cart.
				$course_id = $_REQUEST['page_id']; 			
				$pid=get_post_meta($course_id,'vibe_product',true);
				if(!$pid)
					$pid=get_post_meta($course_id,'intellipaat_online_training_course',true);
				
				if($pid)
					$woocommerce->cart->add_to_cart( $pid );
				else
					return;	
					
				$visitor_cart = $woocommerce->cart->get_cart();
				
				$cart = WC()->instance()->cart;
				$cart_id = $cart->generate_cart_id($pid);
				$cart_item_id = $cart->find_product_in_cart($cart_id);
				
				if($cart_item_id){
				   $cart->set_quantity($cart_item_id,0);
				}
			}
			if ( sizeof( $visitor_cart ) <= 0 )
				return ;
				
			$visitor_details = $visitor_cart;
			
			$visitor_details['visitor_mail'] = $visitor_mail;
			$visitor_details['first_name'] = $visitor_first_name;
			$visitor_details['last_name'] = $visitor_last_name;
			$visitor_details['visitor_phone'] = $visitor_phone;
			
			global $wpdb;
			$table_name = $wpdb->prefix . 'rac_abandoncart';
			$cart_content = maybe_serialize($visitor_details);
			$user_id = "000";
			$current_time = current_time('timestamp');
			if (get_option('rac_remove_carts') == 'yes') {


				if (get_option('rac_remove_new') == 'yes') {

					$wpdb->delete($table_name, array('email_id' => $visitor_mail, 'cart_status' => 'NEW'));
				}

				if (get_option('rac_remove_abandon') == 'yes') {

					$wpdb->delete($table_name, array('email_id' => $visitor_mail, 'cart_status' => 'ABANDON'));
				}
			}

			//check for duplication
			@$check_ip = $wpdb->get_results("SELECT * FROM $table_name WHERE ip_address ='$ip_address' AND cart_status='NEW'");
			if (!is_null($check_ip[0]->id) && !empty($check_ip[0]->id)) {//update
				$wpdb->update($table_name, array('cart_details' => $cart_content, 'user_id' => $user_id, 'email_id' => $visitor_mail), array('id' => $check_ip[0]->id));
			} else {//Insert New entry
				$wpdb->insert($table_name, array('cart_details' => $cart_content, 'user_id' => $user_id, 'email_id' => $visitor_mail, 'cart_abandon_time' => $current_time, 'cart_status' => 'NEW', 'ip_address' => $ip_address, 'wpml_lang' => $currentuser_lang));
				setcookie("rac_checkout_entry", $wpdb->insert_id, time() + 3600, "/");
			}
			// echo $wpdb->insert_id;
		}
	}

}

?>