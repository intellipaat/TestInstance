<?php 
	get_header( 'buddypress' );
	
	
?>
<script>
jQuery(document).ready(function(){
	jQuery(".accordian").click(function(){
	
		jQuery(this).addClass('active_arrow').removeClass('active_arrow_remove');
		var id = jQuery(this).attr("alt");
		jQuery('#'+id).toggleClass("accordian_active");
		if(!jQuery('#'+id).hasClass("accordian_active"))
		{
			jQuery(this).removeClass('active_arrow').addClass('active_arrow_remove');
		}
	})
});
</script>
<section id="title" class="clear clearfix">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-8">
                <?php vibe_breadcrumbs(); ?>
            </div>
            <div class="col-md-3 col-sm-4">
            	<?php get_template_part('templates/search','form'); ?>
            </div>
        </div>
    </div>
</section>

<section id="content">
    <div class="container">
        <div class="row">
            <div id="sidebar-left" class="sidebar-left col-md-3 col-sm-3">
                <div class="sidebar">
                	<?php 
						if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
							the_post_thumbnail();
						} 
					?>	
                    <?php  	get_sidebar('left'); ?>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div id="item-body" class="content">           
                    
                    <?php while ( have_posts() ) : the_post(); ?>
                        <h1> <?php the_title(); ?></h1>
                        <hr></hr>
                        <?php 											
                                $video_id= get_post_meta($post->ID, 'intellipaat-videothumb',true);
                                
                                if(isset($video_id) && !empty($video_id)){
                                    echo '<div class="featured-video">'.do_shortcode('[videothumb class="col-md-13" id="'.$video_id.'" alt="'.get_the_title().' Video"]').'</div>';
                                }
                            ?> 
                        <?php the_content(); ?>
                    
                     <?php endwhile; ?>
                    <div class="post-navigation page-navigation clear clearfix">  
                        <div class="pull-left text-left"><?php previous_post_link('%link', '&laquo;  Previous'); ?></div>
                        <div class="pull-right text-right"><?php next_post_link('%link', 'Next &raquo;'); ?></div>
                    </div>
                </div><!-- #item-body -->
                

                
            </div>
            <div id="sidebar-right" class=" sidebar-right col-md-3 col-sm-3">
                <div class="sidebar">
                    <?php get_sidebar('right'); ?>
                </div>
            </div>  
        </div>
    </div>
</section>

<?php get_footer( 'buddypress' ); ?>