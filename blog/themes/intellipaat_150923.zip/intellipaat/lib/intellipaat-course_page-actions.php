<?php


/**
* Adds upcoming batch table in course content using wplms_before_course_description action
*
*/



if(class_exists('WPLMS_Events_Interface')){
	function intellipaat_event_calendar($course=NULL) {
		global $post;
		$course_id = get_the_ID();
		$current_date = date('Y-m-d');
		
		$args = array( 
					  'post_type' => WPLMS_EVENTS_CPT,
				);		
		
		$args['meta_query']=array(
			'relation' => '"AND"',
		);
		$args['meta_query'][]=array(
			'key' => 'vibe_start_date',
			'compare' => '>',
			'value' => $current_date,
			'type' => 'DATE'
		);		
		/*$args['meta_query'][]=array(
			'key' => 'vibe_end_date',
			'compare' => '>',
			'value' => $current_date,
			'type' => 'DATE'
		);*/
		$args['meta_query'][]=array(
			'key' => 'vibe_event_course',
			'compare' => '=',
			'value' => get_the_ID(),
			'type' => 'DECIMAL'
		);
		$args['orderby']='meta_value';
		$args['order']='ASC';
		$args['meta_key'] = 'vibe_start_date';
	
		$eventdaysquery = new WP_Query( $args );
		
		if($eventdaysquery->have_posts()){
			echo '<h4><b>Upcoming Batches:</b> </h4>';
			echo '<table class="table upcoming_batches">
					<thead>
						<tr>
							<th>STARTS</th>
							<th>DURATION</th>
							<th class="remove_table_class">DAYS</th>
							<th>Time &nbsp;&nbsp;&nbsp; 
								<select id="time_zone">
									<option value="+5.50" data-notice="All timings are in Indian Standard Time zone ( GMT + 5:30 )" data-value="IST">IST</option>
									<option value="+0.00" data-notice="All timings are in Greenwich Mean Time zone ( GMT + 0:00 )" data-value="GMT">GMT</option>
									<option value="-4.00" data-notice="All timings are in Eastern Daylight Time zone ( GMT - 4:00 )" data-value="EDT">EDT</option>
									<option value="-5.00" data-notice="All timings are in Central Daylight Time zone ( GMT - 5:00 )" data-value="CDT">CDT</option>
									<option value="-7.00" data-notice="All timings are in Pacific Daylight Time zone ( GMT -7:00 )" data-value="PDT">PDT</option>
								</select>
							</th>
							<th> </th>
						</tr>
					</thead>
					<tbody class="context">';
		
			$check=vibe_get_option('direct_checkout');
			$check =intval($check);
			
			while ( $eventdaysquery->have_posts() ) {
				$eventdaysquery->the_post();
				$icon = get_post_meta($post->ID,'vibe_icon',true);
				$color = get_post_meta($post->ID,'vibe_color',true);
				$start_date = get_post_meta($post->ID,'vibe_start_date',true);
				$end_date = get_post_meta($post->ID,'vibe_end_date',true);
				$start_time =  get_post_meta(get_the_ID(),'vibe_start_time',true);
				$end_time =  get_post_meta(get_the_ID(),'vibe_end_time',true);
				$duration = get_post_meta(get_the_ID(),'intellipaat_course_duration',true);
				$days = get_post_meta(get_the_ID(),'intellipaat_course_days',true);
				$product=get_post_meta(get_the_ID(),'vibe_product',true);
				
				$product_link='';
				
				if(isset($check) &&  $check){
					$product_link  .= point_to_com_site(get_permalink($course_id)).'?type=onlineTraining&redirect';
				}
				else{
					$product_link = point_to_com_site(get_permalink($product));
				}
				
				if(isset($product) && $product)
					$product_link = '<a href="'.$product_link.'" class="add_to_cart_button">Register &rsaquo;&rsaquo;</a>';
				
				
				echo '<tr>
						<td><span class="date" rel="dateTime-'.get_the_ID().'" data-date="'.date('d M Y',strtotime($start_date)).'">'.date('dS, M',strtotime($start_date)).'</span></td>	
						<td>'.$duration.'</td>	
						<td>'.implode(', ',$days).'</td>	
						<td><span class="start_time" rel="dateTime-'.get_the_ID().'" data-start_time="'.$start_time.'">'.$start_time.'</span> - <label>To :</label> <span class="end_time" rel="dateTime-'.get_the_ID().'" data-end_time="'.$end_time.'">'.$end_time.'</span></td>
						<td>'.$product_link.'</td>				
				</tr>';
			}
			
			echo '</tbody></table>';
		}
		wp_reset_postdata();
		wp_enqueue_script('jquery-cookie');
		?>
        	 <script>
				var default_time = '<?php echo $_COOKIE['default_time'] ?>'; //load batch with defalut by cookie time zone preference
				   
				if(default_time == ''){
					default_time = 'IST';
				}
		
				function calcTime(myDateTime, offset, returnType) {
					d = new Date(Date.parse(myDateTime+' GMT+0530'));
					utc = d.getTime() + (d.getTimezoneOffset() * 60000);
					nd = new Date(utc + (3600000*offset));
					if(returnType == 'date' )
						return moment(nd).format('Do, MMM');	
					else if(returnType == 'time' )
						return moment(nd).format('hh:mm A');	
					else
						return nd.toLocaleString();		
				}
				
				jQuery(document).ready(function(){ 
					jQuery('#time_zone').change(function(){
						var TimezoneOffset = jQuery(this).val();
						jQuery('span.date').each(function(){
							var date = jQuery(this).data('date');
							var rel = jQuery(this).attr('rel');
							var start_dateTime = date +' '+jQuery('span.start_time[rel='+rel+']').data('start_time');
							var end_dateTime = date +' '+jQuery('span.end_time[rel='+rel+']').data('end_time');
							jQuery(this).text(calcTime(start_dateTime, TimezoneOffset, 'date'));
							jQuery('span.start_time[rel='+rel+']').text(calcTime(start_dateTime, TimezoneOffset, 'time'));
							jQuery('span.end_time[rel='+rel+']').text(calcTime(end_dateTime, TimezoneOffset, 'time'));
						});
						jQuery('span.notice').text(jQuery(this).find(':selected').data('notice'));
						jQuery.cookie('default_time', jQuery(this).find(':selected').data('value'), { expires: 30 , path: '/' });
					});				
					var defaultOffset = jQuery('option[data-value='+default_time+']').val();
					jQuery('#time_zone').val(defaultOffset).trigger('change');				
				});
			</script>
        <?php
	}
	
	add_action('wplms_before_course_description','intellipaat_event_calendar' );
}

/**
* Adds course details below course content using bp_after_course_home_content action
*
*/

function intellipaat_after_course_home_content(){
	$id =get_the_ID();
	
	$intellipaat_course_certification = get_field('intellipaat_course_certification', $id); 
	if(!empty($intellipaat_course_certification)){
		echo '<div id="certification" class="content hidden-xs"><h4 class="heading"><b>Certification</b> </h4>'. $intellipaat_course_certification.'</div>';
	}
	
	$intellipaat_selfpaced_vs_instructor_based = get_field('intellipaat_selfpaced_vs_instructor_based', $id); 
	if(!empty($intellipaat_selfpaced_vs_instructor_based)){
		echo '<div id="self-instructor" class="content hidden-xs"><h4 class="heading"><b>Self-Paced Vs Instructor LED Online</b> </h4>'.$intellipaat_selfpaced_vs_instructor_based.'</div>';	
	}
}

add_action('bp_after_course_home_content','intellipaat_after_course_home_content' );


function intellipaat_course_nav_menu_filter($menu){
	unset($menu['members']);
	return $menu;
}
//add_filter('wplms_course_nav_menu', 'intellipaat_course_nav_menu_filter');


/**
*	To manupulate thumbnail_generator output for class view
*/
function intellipaat_course_duration(){
	global $post;
	/*$duration = get_post_meta($post->ID,'vibe_duration',true);
	if($duration)
		return '<span class="intelli_duration pull-right"><i class="icon-clock"> </i> '.$duration.' Hrs</span>';
	else
		return '';*/
		
	$key_feature = get_field('course_1_key_feature');
	if(!empty($key_feature)){
		//preg_match_all('!\d+!', $key_feature, $hours);
		$hours = str_replace(array('-','+'), array('',''), filter_var($key_feature, FILTER_SANITIZE_NUMBER_INT));
		if(is_numeric($hours))
			return '<span class="intelli_duration pull-right"><i class="icon-clock"> </i> '.$hours.' Hrs</span>';
	}
	return '';
}
add_filter( 'vibe_thumb_instructor_meta', 'intellipaat_course_duration' );

function intellipaat_thumb_student_count($val){
	return '<span class="intelli_students"><i class="icon-users"> </i>'.$val.'</span>';
}
add_filter( 'vibe_thumb_student_count', 'intellipaat_thumb_student_count', 10 , 1 );

function intellipaat_thumb_course_meta($val){
	$votes = '';
	$count=get_post_meta(get_the_ID(),'rating_count',true);
	if($count > 0)
		$votes = '<meta itemprop="votes" content="'.$count.'">';
		
	$val = str_replace(array('Students', 'STUDENTS', '( 0 REVIEWS )'), 'Learners', $val);
	$val = str_replace(array('<div class="star-rating">', '( <strong itemprop="count">', ' )', ' itemprop="size"'), array('<div class="star-rating hide">', '<a class="review link" href="#reviews"> <strong class="hide" itemprop="count">', ' </a>'.$votes, ' ' ), $val);
	//$val = preg_replace(array('/(//\d/ '.'REVIEWS//)/'), ' ', $val);
	return $val;
}
add_filter( 'wplms_course_meta', 'intellipaat_thumb_course_meta', 10 , 1 );
add_filter( 'vibe_thumb_student_count', 'intellipaat_thumb_course_meta', 10 , 1 );

function intellipaat_course_thumb_extras($output=''){
	global $post;
	$course_id = get_the_ID();
	$key_feature = "";		
	
	for($i=1; $i<=3 ; $i++){		
		$key_value = get_field("course_".$i."_key_feature");	

		//check if both key and value are set
		if(isset($key_value) && !empty($key_value) ){	
			$output .=  '<span>'.$key_value.'</span>';	
		}
														
	}
	if(isset($output) && !empty($output))
		$output =  '<div class="extra_details">'.$output .'</div>';	
	
	return $output;
}
add_filter( 'wplms_course_thumb_extras', 'intellipaat_course_thumb_extras' );

function intellipaat_add_to_cart_button_on_categorypage($out=''){
	global $post;
	$course_id = get_the_ID();
	$pid = get_post_meta($course_id,'vibe_product',true);
	if(!$pid)
		$pid = get_post_meta($course_id,'intellipaat_online_training_course',true);
	
	$out .='</div><div class="woocommerce center">';
	$product = new WC_Product( $pid );

	if ( $product->is_on_sale() ) 
		 $out .= apply_filters( 'woocommerce_sale_flash', '<span class="onsale">' . __( 'Sale!', 'woocommerce' ) . '</span>', $post, $product );
		 
	if(!is_tax('course-cat'))
		return $out;
		
	if($url = do_shortcode('[add_to_cart_url id="'.$pid.'"]'))
		$out .= '<a href="'.$url.'" rel="nofollow" data-product_id="'.$pid.'" class="button course_cat_page">Add to cart</a>';
		
	return $out;
}
add_filter( 'wplms_course_thumb_extras', 'intellipaat_add_to_cart_button_on_categorypage' );


function intellipaat_thumb_reviews($val){
	return '';
}
add_filter( 'vibe_thumb_reviews', 'intellipaat_thumb_reviews', 10 , 1 );


function intellipaat_course_credits($course_credits, $course_id){
	$pid = get_post_meta($course_id,'vibe_product',true);
	if(!$pid ){
		$pid=get_post_meta($course_id,'intellipaat_online_training_course',true);
		if(isset($pid) && $pid !='' && function_exists('get_product')){
			
			$product = get_product( $pid );
			if(is_object($product))
			$course_credits = '<strong>'.$product->get_price_html().'</strong>';
		}
		
	}else{
		$course_credits = str_replace('<strong itemprop="offers" itemscope itemtype="http://schema.org/Offer">', '<strong>',$course_credits);	
	}
	return $course_credits;
}
add_filter( 'wplms_course_credits', 'intellipaat_course_credits', 10 , 2 );


/**
*	To manupulate all courses page
*/
  
add_filter('rewrite_rules_array', 'intellipaat_insertrules');
add_filter('query_vars', 'intellipaat_insertqv');
  
// Adding fake pages' rewrite rules
function intellipaat_insertrules($rules)
{
	$newrules = array();
	$newrules['all-courses/?(.*)/?$'] = 'index.php?pagename=all-courses&course_category=$matches[1]';
  
	return $newrules + $rules;
}
  
// Tell WordPress to accept our custom query variable
function intellipaat_insertqv($vars)
{
	array_push($vars, 'course_category');
	return $vars;
}

// Remove WordPress's default canonical handling function
 

add_filter('wp_head', 'intellipaat_rel_canonical');
function intellipaat_rel_canonical()
{
	global $wp_the_query;
	
	if (!is_page( 'all-courses' ))
		return;
	$course_category = get_query_var('course_category');
	
	if (!$id = $wp_the_query->get_queried_object_id())
            return;
  
	$link = trailingslashit(get_permalink($id));

	// Make sure fake pages' permalinks are canonical
	if (!empty($course_category))
		$link .= user_trailingslashit($course_category);

	echo '<link rel="canonical" href="'.$link.'" />';
}



/***
*	Load addiional courses from other category using ajax method
**/

add_action("wp_ajax_intellipaat_all_course_page_filterd", "intellipaat_all_course_page_filterd_callback");
add_action("wp_ajax_nopriv_intellipaat_all_course_page_filterd", "intellipaat_all_course_page_filterd_callback");

function intellipaat_all_course_page_filterd_callback() {

   if ( !wp_verify_nonce( $_REQUEST['nonce'], "intellipaat_all_course_page_nonce")) {
      exit("No naughty business please");
   } 
	$course_category = $_REQUEST['course_category'];
   	filtered_course_loop($course_category);
	die();
}

/***
*	Flush transient cache on some events
**/
add_action("save_post","intellipaat_filtered_course_cache");
add_action("wp_trash_post","intellipaat_filtered_course_cache");
add_action("untrash_post","intellipaat_filtered_course_cache");
function intellipaat_filtered_course_cache(){
    global $post;
	$post_type = get_post_type( $post );
	
	if($post_type != 'course' )
		return;
	intellipaat_flush_course_cache();
}
add_action('w3tc_flush_objectcache', 'intellipaat_flush_course_cache');
add_action('w3tc_flush_file', 'intellipaat_flush_course_cache');
add_action('w3tc_flush_memcached', 'intellipaat_flush_course_cache');
add_action('w3tc_flush_dbcache', 'intellipaat_flush_course_cache');
add_action('w3tc_flush', 'intellipaat_flush_course_cache');
add_action('w3tc_flush_all', 'intellipaat_flush_course_cache');
function intellipaat_flush_course_cache(){
	$terms = get_terms( 'course-cat' );
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
		foreach ( $terms as $term ) {
			delete_transient('all_courses_'.$term->slug);
		}
	}		
	delete_transient('all_courses_new-courses');
	delete_transient('all_courses_fast-moving-courses');
	delete_transient('all_courses_home_page');
	delete_transient('browse_course_menu');
}

function filtered_course_loop($course_category){
	$taxonomy = 'course-cat';
	if($course_category == ''){
		$default_cat = vibe_get_option('default_courses_cat');
		$default_cat_obj = get_term( $default_cat, $taxonomy );
		$course_category = $default_cat_obj->slug;
	}
	
	
	$cached_course_category = get_transient( 'all_courses_'.$course_category );
	if ( false === $cached_course_category || current_user_can('edit_posts') ) {
		
		$cached_course_category = '';
		$class = $course_category ? $course_category : $default_cat_slug ;
		$posts= get_field('intellipaat_custom_category_order', get_term_by( 'slug', $course_category, $taxonomy )  ); //fetch custom order for course as category. Advanced fileds.
		
		if($posts)
		{		
			global $post;	
			foreach($posts as $post){
							
				$cached_course_category .=  '<div class="'.$class.' course_items col-md-3 col-sm-6" >';
				
				if(function_exists('thumbnail_generator')){
					$cached_course_category .=  thumbnail_generator($post,'course','medium',1,1,1);
				}       	
				
				$cached_course_category .=  "</div>";				
			}			
		}
		else
		{
			$args = array(
				'showposts' =>  -1,
				'post_type' => 'course',
				'order' => 'ASC',
				'orderby' => 'menu_order',
				'course-cat' => $course_category
			);
			
			/*if($course_category && $course_category != 'new-courses' && $course_category != 'fast-moving-courses')
				$args['course-cat']= $course_category;
			else if($course_category && $course_category == 'new-courses'){
				$args['order']			= 'ASC';
				$args['orderby']		= 'meta_value_num';
				$args['meta_key']		= 'intellipaat_order_new_course';
				$args['meta_query']		= array(
													array(
														'key'     => 'intellipaat_new_course',
														'value'   => 1,
														'compare' => '=',
													),
												);
			}
			else {      
				$args['order']			= 'ASC';
				$args['orderby']		= 'meta_value_num';
				$args['meta_key']		= 'intellipaat_order_fast_moving';
				$args['meta_query']		= array(
													array(
														'key'     => 'intellipaat_fast_moving',
														'value'   => 1,
														'compare' => '=',
													),
												);
			}*/
								
			$query = new WP_Query( $args );
			
			if ($query->have_posts()) :
				
			
						 
					while ( $query->have_posts() ) : $query->the_post(); 
						/*$terms = get_the_terms( get_the_ID(), 'course-cat' );
						foreach($terms as $term){
							$class .= $term->slug.' ';
						}*/
						/*$intellipaat_fast_moving_new = get_field('intellipaat_fast_moving_new');	
						if($intellipaat_fast_moving_new)
							$class .= implode(' ', $intellipaat_fast_moving_new);
						$pid=get_post_meta(get_the_ID(),'vibe_product',true);
						if($pid)
							$class .= 'self-paced';*/
					
						
						$cached_course_category .=  '<div class="'.$class.' course_items col-md-3 col-sm-6" >';
						
							
						
						if(function_exists('thumbnail_generator')){
							$cached_course_category .=  thumbnail_generator($query->post,'course','medium',1,1,1);
						}       	
						
						$cached_course_category .=  "</div>";
						
			
					endwhile;	
			else :
			
					$cached_course_category .=  '<div class="'.$class.' course_items col-md-3 col-sm-6" >';
					$cached_course_category .= '<h2>We did\'t found any course matching your request.</h2>';
					$cached_course_category .=  "</div>";
					
			endif;	
			
		}
		
		wp_reset_postdata();	
		
		if(!is_user_logged_in())
			set_transient( 'all_courses_'.$course_category, $cached_course_category,  WEEK_IN_SECONDS );
	}
	
				//	echo  "<!--queries : ".  get_num_queries()." Seconds: ".timer_stop( 0 )."-->";
	
	echo $cached_course_category;
}

add_action('after_setup_theme','intellipaat_alter_wplms_hooks', 20);
function intellipaat_alter_wplms_hooks(){
	remove_action('wp_ajax_quiz_question', 'quiz_question');
	remove_filter('wplms_course_product_id','wplms_expired_course_product_id',10,3); // This hook called in vice course module plugin. For ingnoring error I removed this filter
	
	remove_action('wplms_unit_header','wplms_custom_unit_header',10,2); //intructor name
	remove_action('wplms_course_unit_meta','vibe_custom_print_button'); //print unit button
}

/*
*	Fixing "Too fast or answer not marked" issue in Quiz
*	http://support.vibethemes.com/support/solutions/articles/1000165098-fixing-too-fast-or-answer-not-marked-issue-in-quiz
*/
remove_filter('check_comment_flood', 'check_comment_flood_db');
add_filter('comment_flood_filter', '__return_false');

/*
*	Hide Correct answer and explanation till the user has passed the Quiz
*	http://support.vibethemes.com/support/solutions/articles/1000182141-hide-correct-answer-and-explanation-till-the-user-has-passed-the-quiz
*
*	You can totally hide the correct answer in the quiz results by adding this css in Customizer -> Custom CSS section :
*	http://support.vibethemes.com/support/discussions/topics/1000055389?page=1
*/
add_filter('wplms_show_quiz_correct_answer','wplms_check_passed_quiz',10,2);
function wplms_check_passed_quiz($return,$quiz_id){
	$user_id = get_current_user_id();
	$marks = get_post_meta($quiz_id,$user_id,true);
	if(isset($marks) && is_numeric($marks)){
		$passing_score = get_post_meta($quiz_id,'vibe_quiz_passing_score',true);
		if(is_numeric($passing_score) && $marks < $passing_score)
			return false;
	}
	return $return;
}


//BEGIN QUIZ
add_action('wp_ajax_quiz_question', 'intellipaat_quiz_question'); // Only for LoggedIn Users
if(!function_exists('intellipaat_quiz_question')){
  function intellipaat_quiz_question(){
      
      $quiz_id= $_POST['quiz_id'];
      $ques_id= $_POST['ques_id'];

      

      if ( isset($_POST['start_quiz']) && wp_verify_nonce($_POST['start_quiz'],'start_quiz') ){ // Same NONCE just for validation

        $user_id = get_current_user_id();
        $quiztaken=get_user_meta($user_id,$quiz_id,true);
        

         if(isset($quiztaken) && $quiztaken){
            if($quiztaken > time()){
                the_intellipaat_quiz('quiz_id='.$quiz_id.'&ques_id='.$ques_id);  
            }else{
              echo '<div class="message error"><h3>'.__('Quiz Timed Out .','vibe').'</h3>'; 
        echo '<p>'.__('If you want to attempt again, Contact Instructor to reset the quiz.','vibe').'</p></div>';
            }
            
         }else{
            echo '<div class="message info"><h3>'.__('Start Quiz to begin quiz.','vibe').'</h3>'; 
            echo '<p>'.__('Click "Start Quiz" button to start the Quiz.','vibe').'</p></div>';
         }

     }else{
                echo '<div class="message error"><h3>'.__('Quiz not active.','vibe').'</h3>'; 
                echo '<p>'.__('Contact your instructor or site admin.','vibe').'</p></div>';
     }
     die();
  }  
}

remove_filter('bp_course_admin_before_course_students_list','bp_course_admin_search_course_students',10,2);
add_filter('bp_course_admin_before_course_students_list','intellipaat_course_admin_search_course_students',10,2);
function intellipaat_course_admin_search_course_students($students,$course_id){

	$course_statuses = apply_filters('wplms_course_status_filters',array(
		0 => __('Expired Course','vibe'),
		1 => __('Start Course','vibe'),
		2 => __('Continue Course','vibe'),
		3 => __('Under Evaluation','vibe'),
		4 => __('Course Finished','vibe')
		));
	echo '<form method="get" action="">
			<input type="hidden" value="admin" name="action">
			'.(isset($_GET['item_page'])?'<input type="hidden" name="item_page" value="'.$_GET['item_page'].'">':'').'
			<select name="status"><option value="">'.__('Filter by Status','vibe').'</option>';
			foreach($course_statuses as $key =>$value){
				echo '<option value="'.$key.'" '.selected($_GET['status'],$key).'>'.$value.'</option>';
			}
	echo  '</select>';
	do_action('wplms_course_admin_form',$students,$course_id);
	echo '<input type="text" name="student" value="'.$_GET['student'].'" placeholder="'.__('Enter student username/email','vibe').'" class="input" />
			<input type="submit" value="'.__('Let\'s find','vibe').'" />
		 </form>';
    if(isset($_GET['student']) && $_GET['student']){
    	$args = array(
			'search'         => $_GET['student'],
			'search_columns' => array( 'login', 'email','nicename'),
			'fields' => array('ID'),
			'meta_query' => array(
				array(
					'key' => $course_id,
					'compare' => 'EXISTS'
					)
				),
		);
    	$user_query = new WP_User_Query( $args );
    	$users = $user_query->get_results();

		if(count($users)){
			$students=array();
			foreach($users as $user){
				if(is_object($user) && isset($user->ID))
					$students[]=$user->ID;
			}
		}else{
			$info_message = 'Unable to find member using "'. $_GET['student'].'". You may try again using email or username.';
			wc_print_notice( $info_message, 'error' );
		}
    }
	return $students;
}

/*
*	Remove instructor list from course search page
*/
add_filter('wplms_course_search_selects','intellipaat_custom_search_args');
function intellipaat_custom_search_args($args){
 $args = 'instructors=0&cats=1&level=1';
return $args;
}

function the_unit_desc($id=NULL){
    if(!isset($id))
      return;
	echo get_unit_desc($id);
}

function get_unit_desc($id=NULL){
    if(!isset($id))
      return;
	
	$before	='<div class="unit_desc">'; //<h4 class="heading">Basic unit description</h4>
	$after ='</div>';
	
	$desc = get_field('intellipaat_brief_unit_description', $id);
	if(!empty($desc ))
		return $before.$desc.$after;
	
	return $desc;
}
/*
*	Prints description before unit.
*/
function intellipaat_unit_content_filter($content){
	global $post;
	if( is_singular('unit') && !is_admin()){
			$desc = get_unit_desc($post->ID);
			$content = $desc.$content;
	}
	return $content;
}
add_filter('the_content', 'intellipaat_unit_content_filter');

/*=== UNIT TRAVERSE =====*/
remove_action('wp_ajax_unit_traverse', 'unit_traverse');
remove_action( 'wp_ajax_nopriv_unit_traverse', 'unit_traverse' );
add_action('wp_ajax_unit_traverse', 'intellipaat_unit_traverse');
add_action( 'wp_ajax_nopriv_unit_traverse', 'intellipaat_unit_traverse' );

function intellipaat_unit_traverse(){
  $unit_id= $_POST['id'];
  $course_id = $_POST['course_id'];
  if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'security')){
     _e('Security check Failed. Contact Administrator.','vibe');
     die();
  }

  //verify unit in course
  $units = bp_course_get_curriculum_units($course_id);
  if(!in_array($unit_id,$units)){
    _e('Session not in Course','vibe');
    die();
  }

  // Check if user has taken the course
  $user_id = get_current_user_id();
  $coursetaken=get_user_meta($user_id,$course_id,true);

  //if(!isset($_COOKIE['course'])) {
    if($coursetaken>time()){
      setcookie('course',$course_id,$expire,'/');
      $_COOKIE['course'] = $course_id;
    }else{
      $pid=get_post_meta($course_id,'vibe_product',true);
      $pid=apply_filters('wplms_course_product_id',$pid,$course_id,-1); // $id checks for Single Course page or Course page in the my courses section
      if(is_numeric($pid))
        $pid=get_permalink($pid);

      echo '<div class="message"><p>'.__('Course Expired.','vibe').'<a href="'.$pid.'" class="link alignright">'.__('Click to renew','vibe').'</a></p></div>';
      die();
    }
  //}
  
  if(isset($coursetaken) && $coursetaken){
      
      // Drip Feed Check    
      $drip_enable=get_post_meta($course_id,'vibe_course_drip',true);

      
      if(vibe_validate($drip_enable)){

          $drip_duration = get_post_meta($course_id,'vibe_course_drip_duration',true);
          $drip_duration_parameter = apply_filters('vibe_drip_duration_parameter',86400);

          $unitkey = array_search($unit_id,$units);
          if($unitkey == 0){
            $pre_unit_time=get_post_meta($units[$unitkey],$user_id,true);

            if(!isset($pre_unit_time) || $pre_unit_time ==''){
              update_post_meta($units[$unitkey],$user_id,current_time('timestamp'));
              if(is_numeric($units[1]))
                //Parmas : Next Unit, Next timestamp, course_id, userid
                do_action('wplms_start_unit',$units[$unitkey],$course_id,$user_id,$units[1],(current_time('timestamp')+$drip_duration*$drip_duration_parameter));
            }
          }else{

             $pre_unit_time=get_post_meta($units[($unitkey-1)],$user_id,true);

             if(isset($pre_unit_time) && $pre_unit_time){
                
                $drip_duration_parameter = apply_filters('vibe_drip_duration_parameter',86400);

                $value = $pre_unit_time + $drip_duration*$drip_duration_parameter;
                $value = apply_filters('wplms_drip_value',$value,$units[($unitkey-1)],$course_id,$units[$unitkey]);

                //print_r(date('l jS \of F Y h:i:s A',$value).' > '.date('l jS \of F Y h:i:s A',current_time('timestamp')));

               if($value > current_time('timestamp')){
                      echo '<div class="message"><p>'.__('Session will be available in ','vibe').tofriendlytime($value-current_time('timestamp')).'</p></div>';
                      die();
                  }else{
                      $pre_unit_time=get_post_meta($units[$unitkey],$user_id,true);
                      if(!isset($pre_unit_time) || $pre_unit_time ==''){
                        update_post_meta($units[$unitkey],$user_id,current_time('timestamp'));
                        //Parmas : Next Unit, Next timestamp, course_id, userid
                        do_action('wplms_start_unit',$units[$unitkey],$course_id,$user_id,$units[$unitkey+1],(current_time('timestamp')+$drip_duration*$drip_duration_parameter));
                      }
                  } 
              }else{
                  echo '<div class="message"><p>'.__('Session can not be accessed.','vibe').'</p></div>';
                  die();
              }    
            }
          }  

      // END Drip Feed Check  
      
      echo '<div id="unit" class="'.get_post_type($unit_id).'_title" data-unit="'.$unit_id.'">';
        do_action('wplms_unit_header',$unit_id,$course_id);

        $minutes=0;
        $mins = get_post_meta($unit_id,'vibe_duration',true);
        $unit_duration_parameter = apply_filters('vibe_unit_duration_parameter',60);
        if($mins){
          if($mins > $unit_duration_parameter){
            $hours = floor($mins/$unit_duration_parameter);
            $minutes = $mins - $hours*$unit_duration_parameter;
          }else{
            $minutes = $mins;
          }
        
          do_action('wplms_course_unit_meta',$unit_id);
          if($mins < 9999){ 
            if($unit_duration_parameter == 1)
              echo '<span><i class="icon-clock"></i> '.(isset($hours)?$hours.__(' Minutes','vibe'):'').' '.$minutes.__(' seconds','vibe').'</span>';
            else if($unit_duration_parameter == 60)
              echo '<span><i class="icon-clock"></i> '.(isset($hours)?$hours.__(' Hours','vibe'):'').' '.$minutes.__(' minutes','vibe').'</span>';
            else if($unit_duration_parameter == 3600)
              echo '<span><i class="icon-clock"></i> '.(isset($hours)?$hours.__(' Days','vibe'):'').' '.$minutes.__(' hours','vibe').'</span>';
          } 

        }
      echo '<br /><h1>'.get_the_title($unit_id).'</h1>';
          the_sub_title($unit_id);
      echo '<div class="clear"></div>';
      echo '</div>';
        the_intellipaat_unit($unit_id); 
      
              $unit_class='unit_button';
              $hide_unit=0;
              $nextunit_access = vibe_get_option('nextunit_access');
              

              $k=array_search($unit_id,$units);
              $done_flag=get_user_meta($user_id,$unit_id,true);

              $next=$k+1;
              $prev=$k-1;
              $max=count($units)-1;

              echo  '<div class="unit_prevnext"><div class="col-md-3">';
              if($prev >=0){

                if(get_post_type($units[$prev]) == 'quiz'){
                  echo '<a href="#" data-unit="'.$units[$prev].'" class="unit '.$unit_class.'">'.__('Previous Quiz','vibe').'</a>';
                }else    
                  echo '<a href="#" id="prev_unit" data-unit="'.$units[$prev].'" class="unit unit_button">'.__('Previous Session','vibe').'</a>';
              }
              echo '</div>';

              echo  '<div class="col-md-6">';
              if(get_post_type($units[($k)]) == 'quiz'){
                $quiz_status = get_user_meta($user_id,$units[($k)],true);
                if(is_numeric($quiz_status)){
                  if($quiz_status < time()){
                    echo '<a href="'.bp_loggedin_user_domain().BP_COURSE_SLUG.'/'.BP_COURSE_RESULTS_SLUG.'/?action='.$units[($k)].'" class="quiz_results_popup">'.__('Check Results','vibe').'</a>';
                  }else{
                      $quiz_class = apply_filters('wplms_in_course_quiz','');
                      echo '<a href="'.get_permalink($units[($k)]).'" class=" unit_button '.$quiz_class.' continue">'.__('Continue Quiz','vibe').'</a>';
                  }
                }else{
                    $quiz_class = apply_filters('wplms_in_course_quiz','');
                    echo '<a href="'.get_permalink($units[($k)]).'" class=" unit_button '.$quiz_class.'">'.__('Start Quiz','vibe').'</a>';
                }
              }else  
                  echo ((isset($done_flag) && $done_flag)?'': apply_filters('wplms_unit_mark_complete','<a href="#" id="mark-complete" data-unit="'.$units[($k)].'" class="unit_button">'.__('Mark this Session Complete','vibe').'</a>',$unit_id,$course_id));

              echo '</div>';

              echo  '<div class="col-md-3">';

              if($next <= $max){

                if(isset($nextunit_access) && $nextunit_access){
                    $hide_unit=1;

                    if(isset($done_flag) && $done_flag){
                      $unit_class .=' ';
                      $hide_unit=0;
                    }else{
                      $unit_class .=' hide';
                      $hide_unit=1;
                    }
                }

                if(get_post_type($units[$next]) == 'quiz'){
                      echo '<a href="#" id="next_quiz" data-unit="'.$units[$next].'" class="unit '.$unit_class.'">'.__('Proceed to Quiz','vibe').'</a>';
                }else  
                  echo '<a href="#" id="next_unit" '.(($hide_unit)?'':'data-unit="'.$units[$next].'"').' class="unit '.$unit_class.'">'.__('Next Session','vibe').'</a>';
              }
              echo '</div></div>';
          
        }
        die();
}  
/*
*	Redeclaration of function the_unit()
*/
if(!function_exists('the_intellipaat_unit')){
  function the_intellipaat_unit($id=NULL){
    if(!isset($id))
      return;
    
    do_action('wplms_before_every_unit',$id);
    
    $post_type = get_post_type($id);
    $the_query = new WP_Query( 'post_type='.$post_type.'&p='.$id );
    $user_id = get_current_user_id();

    while ( $the_query->have_posts() ):$the_query->the_post();
    
    $unit_class = 'unit_class';
    $unit_class=apply_filters('wplms_unit_classes',$unit_class,$id);
    echo '<div class="main_unit_content '.$unit_class.'">';

    if($post_type == 'quiz'){ 
      $expiry = get_user_meta($user_id,$id,true);
      if(is_numeric($expiry) && $expiry < time()){
        $message = get_post_meta($id,'vibe_quiz_message',true);
        echo apply_filters('the_content',$message);
      }else{
        the_content();  
      }
    }else{
		the_unit_desc($id);
		the_content();  
    }
    
    wp_link_pages(array(
      'before'=>'<div class="unit-page-links page-links"><div class="page-link">',
      'link_before' => '<span>',
      'link_after'=>'</span>',
      'after'=> '</div></div>'));

    echo '</div>';
    endwhile;
    wp_reset_postdata();
    if(get_post_type($id) == 'unit')
    do_action('wplms_after_every_unit',$id);

    echo intellippat_course_get_unit_attachments($id);

    echo '<div class="unitforum">'.vibe_get_option('support_note').'</div>';
  }
}

if(!function_exists('intellippat_course_get_unit_attachments')){

  function intellippat_course_get_unit_attachments($id=NULL){
      if(!is_numeric($id)){
        global $post;
        $id=$post->ID;
      }

      $return='';
      $attachments =& get_children( 'post_type=attachment&output=ARRAY_N&order=ASC&post_parent='.$id);//&orderby=menu_order
       if($attachments && count($attachments)){
            $att= '';

            $count=0;
          foreach( $attachments as $attachmentsID => $attachmentsPost ){
          
          $type=get_post_mime_type($attachmentsID);

          if($type != 'image/jpeg' && $type != 'image/png' && $type != 'image/gif'){
              
              if($type == 'application/zip')
                $type='icon-compressed-zip-file';
              else if($type == 'video/mpeg' || $type== 'video/mp4' || $type== 'video/quicktime')
                $type='icon-movie-play-file-1';
              else if($type == 'text/csv' || $type== 'text/plain' || $type== 'text/xml')
                $type='icon-document-file-1';
              else if($type == 'audio/mp3' || $type== 'audio/ogg' || $type== 'audio/wmv')
                $type='icon-music-file-1';
              else if($type == 'application/pdf')
                $type='icon-text-document';
              else
                $type='icon-file';

              $count++;

              $att .='<li><i class="'.$type.'"></i>'.wp_get_attachment_link($attachmentsID).'</li>';
            }
          }

        if($count){
          $return ='<div class="unitattachments"><h4>'.__('Attachments','vibe').'<span><i class="icon-download-3"></i>'.$count.'</span></h4><ul id="attachments">';
          $return .= $att;
          $return .= '</ul></div>';
        }
      }
      return $return;
    }
}

?>