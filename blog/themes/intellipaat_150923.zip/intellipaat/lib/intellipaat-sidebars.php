<?php

add_action( 'widgets_init', 'intellipaat_bottom_sidebar' );

function intellipaat_bottom_sidebar() {

	/* Register the 'footer bottom' sidebar.
	register_sidebar(
		array(
			'id' => 'footerimg',
			'name' => __( 'Footer Img' ),
			'description' => __( 'This sidebar will show widgets in footer.' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="footertitle">',
			'after_title' => '</h4>'
		)
	); */
	
	/* Register the 'contact' sidebar to display in single course right side. 
	
	register_sidebar(
		array(
			'id' => 'contactus',
			'name' => __( 'Course page Contact us' ),
			'description' => __( 'This sidebar will show widgets in right side of single course display.' ),
			'before_widget' => '<div id="%1$s" class="widget widget-contact pricing %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="footertitle">',
			'after_title' => '</h4>'
		)
	);*/

	/* Repeat register_sidebar() code for additional sidebars.
	
	register_sidebar( array(
		'name' => 'Event Sidebar',
		'id' => 'eventsidebar',
		'before_widget' => '<div class="widget woocart">',
		'after_widget' => '</div>',
		'before_title' => '<h4 class="widget_title">',
		'after_title' => '</h4>',
		'description'   => __('This is the default widget area/sidebar shown in online training calender.','vibe')
	) );*/
	
	/* Repeat register_sidebar() code for additional sidebars.*/
	
	register_sidebar( array(
		'name' => 'Tutorial left sidebar',
		'id' => 'tutorialsidebar',
		'before_widget' => '<div class="widget tutorial-widget">',
		'after_widget' => '</div>',
		'before_title' => '<h4 class="widget_title">',
		'after_title' => '</h4>',
		'description'   => __('This is the default widget area/sidebar shown left side of tutorial pages.','vibe')
	) );
 
}

?>
