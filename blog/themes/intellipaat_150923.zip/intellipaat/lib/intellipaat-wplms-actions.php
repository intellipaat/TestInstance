<?php

/*
*	Removed Groups menu from top logged in user popup
*/
function ialm_logged_in_top_menu($loggedin_menu){
	if ( !in_array( 'paid-memberships-pro/paid-memberships-pro.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) )) {
		unset($loggedin_menu['membership']);
	}
	return $loggedin_menu;
}
add_filter('wplms_logged_in_top_menu','ialm_logged_in_top_menu');



/*function intellipaat_font_query_args($args){
		$args = str_replace('Open Sans', 'Open+Sans',$args);
		return $args;
}
add_filter('vibe_font_query_args','intellipaat_font_query_args');*/
?>