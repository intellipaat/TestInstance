<?php 

function intellipaat_interview_question_posttype(){
	
	register_post_type('interview-question',
		array (
			'labels' => array(
				'name'					=> __('Interview Questions', 'intellipaat'),
				'menu_name'				=> __('Interview Questions', 'intellipaat'),
				'singular_name'			=> __('Interview Question', 'intellipaat'),
				'all_items'				=> __('All Interview Questions', 'intellipaat'),
				'parent_item'           => __('Parent Interview Question', 'intellipaat'),
				'parent_item_colon'     => __('Parent Interview Question:', 'intellipaat'),
				'add_new'				=> __('Add Interview Question', 'intellipaat'),
				'add_new_item'			=> __('Add new Interview Question', 'intellipaat'),
				'edit_item'				=> __('Edit Interview Question', 'intellipaat'),
				'new_item'				=> __('New Interview Question', 'intellipaat'),
				'view_item'				=> __('View Interview Question', 'intellipaat'),
				'search_items'			=> __('Search Interview Questions', 'intellipaat'),
				'not_found'				=> __('No Interview Question found', 'intellipaat'),
				'not_found_in_trash'	=> __('No Interview Questions Found in Trash', 'intellipaat')
			),
			'public'				=> true,
			'show_ui'				=> true,
			'has_archive'			=> true,
			'show_in_nav_menus' 	=> true,
			'capability_type'		=> 'page',
			'hierarchical'			=> false,
			'exclude_from_search'	=> true,
			'publicly_queryable'	=> true,
			'query_var'				=> true,
			'map_meta_cap'        	=> true,
			'rewrite'				=> array(
				'slug'					=> 'interview-question',
				'hierarchical'	 		=> true,
				'with_front'			=> false
			),
			'menu_position'			=> 20,
			'menu_icon'				=> 'dashicons-smiley',
			'supports'				=> array(
				'title',
				'thumbnail',
				'editor',
				'page-attributes',
				'revision',
				'custom-fields',
			)
		)
	);
	

	$args = array(
		'hierarchical'          => true,
		'labels'                =>  array(
											'name'                       => _x( 'Interview Question Category', 'taxonomy general name' ),
											'singular_name'              => _x( 'Category', 'taxonomy singular name' ),
											'search_items'               => __( 'Search Interview Question Categories' ),
											'popular_items'              => __( 'Popular Interview Question Categories' ),
											'all_items'                  => __( 'All Interview Question Categories' ),
											'parent_item'                => null,
											'parent_item_colon'          => null,
											'edit_item'                  => __( 'Edit Category' ),
											'update_item'                => __( 'Update Category' ),
											'add_new_item'               => __( 'Add New Category' ),
											'new_item_name'              => __( 'New Category Name' ),
											'separate_items_with_commas' => __( 'Separate Categories with commas' ),
											'add_or_remove_items'        => __( 'Add or remove Categories' ),
											'choose_from_most_used'      => __( 'Choose from the most used Categories' ),
											'not_found'                  => __( 'No Categories found.' ),
											'menu_name'                  => __( 'Category' ),
										),
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => false,
	);

	register_taxonomy( 'iq-category', 'interview-question', $args );

}

add_action('init', 'intellipaat_interview_question_posttype');




?>