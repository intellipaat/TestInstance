<?php 
add_shortcode('carousel_thumb','carouselthumb_generator');

function carouselthumb_generator($atts){
	
	extract( shortcode_atts( array(

      'id'   => '',
	  'class'=> '',
	  
      ), $atts ) );
	
	$output = " ";
	
	if(isset($id) && !empty($id)){
	 $thumbs= explode(',' , $id);	
	
		//$output .= "<div class='v_module v_column stripe_container fullwidth v_first'>";
		
		 $output .= "<div id='thumb_carousel' class='thumb_carousel flexslider'  data-block-min='2' data-block-max='4' data-block-width='200'>";
		 
			$output .= "<ul class='slides'>";
		
			foreach($thumbs as $thumb){
				
				$output .= "<li>";
				
					$output .= wp_get_attachment_image( $thumb , 'full');
					
				$output .= "</li>"; 
				
			}
			
			$output .= "</ul>";
			
		  $output  .= "</div>";
		  
		  $output  .= "<style>
					#thumb_carousel {
						padding: 15px;
						position: relative;
					}
					#thumb_carousel .slides li img {
						border: 1px solid #C5B5CC;
					}
					#thumb_carousel .slides > li {
						margin-right: 15px;
					}
					#thumb_carousel .flex-direction-nav li a {
						cursor: pointer;
						display: block;
						height: 30px;
						margin: -20px 0 0;
					   
						position: absolute;
						top: 50%;
						width: 30px;
					}
					#thumb_carousel ul li .flex-prev {
						left: -15px;
					}
					#thumb_carousel ul li .flex-next {
					   
						right: -18px;
					}
					#thumb_carousel > ul li a i {
						background-color: #A09DBE;
						color: white;
						padding: 5px;
						border-radius: 100%;
						width: 29px !important;
						display: block;
						text-align: center;
						opacity: 0.5;
						z-index: 999;
					}</style>";
			
		//$output .= "</div>";
		
	}
	
	return $output;
}

?>