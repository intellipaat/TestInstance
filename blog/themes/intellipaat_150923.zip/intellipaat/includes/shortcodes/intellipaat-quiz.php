<?php 

add_shortcode( 'quiz', 'intellipaat_quiz' );

function intellipaat_quiz($atts){
	
	global $post;
	
	extract( shortcode_atts( array(

		  'id'			=>	'',
		  'title'		=>	'Sample Quiz -> '.get_the_title($post->ID)

      ), $atts ) );
	
	
				
		$output ='<div class="sample-quiz">							
					';
						
						//if(is_user_logged_in() || isset($_COOKIE['intellipaat_visitor']) ){
							
							$output .= '<a href="'.get_permalink($id).'" class="quiz-link">
											<i class="icon-code-html-file-1"></i>	
											'.$title.' 
										</a>';
																				
						/*}
						else{
			
							$output .= '<a class="popup-with-form" href="#login-form">
											<i class="icon-bookmark-file-1"></i>	
											'.$title.' <span class="pull-right">Download</span>
										</a>';
			
						}*/
	
	$output .= 		'
				</div>';
	
	return $output;
}

/*
*	http://stackoverflow.com/questions/11990902/how-to-force-pdf-to-download-beginner
*	http://css-tricks.com/snippets/htaccess/force-files-to-download-not-open-in-browser/
*/

?>