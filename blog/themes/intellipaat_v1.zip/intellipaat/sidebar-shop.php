<?php
if ( is_shop() ) :
?>
<div class="woocart sidebar">
    <?php
        the_widget('WC_Widget_Cart', 'title=0&hide_if_empty=1');
    ?>
</div>
<div class="shopsidebar">
    <?php
    if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('shop') ) : ?>
   <?php endif; ?>
</div>
<?php
else:
?>
<div class="productsidebar">
    <?php
    if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('product') ) : ?>
   <?php endif; ?>
</div>

<?php
endif;
?>