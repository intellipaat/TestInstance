<footer class="hidden-xs">
    <div class="container">
        <div class="row">
            <div class="footertop">
                <?php 
                            if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('topfootersidebar') ) : ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="footerbottom">
                <?php 
                    if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('bottomfootersidebar') ) : ?>
                <?php endif; ?>
            </div>
        </div>
    </div> 
    <div id="scrolltop">
        <a><i class="icon-arrow-1-up"></i><span><?php _e('top','vibe'); ?></span></a>
    </div>
</footer>
<div id="footerbottom">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 footer_copyright">
            	<div class="clearfix">
                <h2 id="footerlogo"><a href="<?php echo vibe_site_url(); ?>"><img src="<?php  echo apply_filters('wplms_logo_url',VIBE_URL.'/images/logo.png'); ?>" alt="<?php echo get_bloginfo('name'); ?>" /></a></h2>
                <?php $copyright=vibe_get_option('copyright'); echo (isset($copyright)?do_shortcode($copyright):'&copy; 2013, All rights reserved.');?>
                </div>
                <div class="clear clearfix"></div>
                <div id="footer_social_icons">
                      <?php  echo vibe_socialicons(); ?>
                 </div>
                         
            </div>
            
		 <?php if ( is_active_sidebar( 'footerimg' ) ) : ?>
         
          <div class="col-md-3 bottom-img col-sm-6 footer_newsletter">
         
                <?php dynamic_sidebar( 'footerimg' ); ?>
         
         </div>
             
              <?php endif; ?>	
            
            <div class="col-md-3 col-sm-6 hidden-xs">
                <?php
                    $footerbottom_right = vibe_get_option('footerbottom_right');
                    if(isset($footerbottom_right) && $footerbottom_right){
                        echo '<div id="footer_social_icons">';
                        echo vibe_socialicons();
                        echo '</div>';
                    }else{
                        ?>
                        <div id="footermenu">
                        	<h4 class="footertitle">Intellipaat</h4>
                            <?php
                                    $args = array(
                                        'theme_location'  => 'footer-menu',
                                        'container'       => '',
                                        'menu_class'      => 'footermenu',
                                        'fallback_cb'     => 'vibe_set_menu',
                                    );
                                    wp_nav_menu( $args );
                            ?>
                        </div> 
                        <?php
                    }
                ?>
            </div>            
            
            	
            <?php //if ( is_active_sidebar( 'bottom_right' ) ) : ?>
            
               <div id="footer-right" class="sidebar col-md-3  col-sm-6 hidden-xs">
					<?php //dynamic_sidebar( 'bottom_right' ); ?>
                    <a class="btns teach " href="<?php echo esc_url( get_permalink( get_page_by_title( 'Become an Instructor' ) ) ); ?>">
                        <i class="icon-rocket"></i>
                        Teach on Intellipaat
                    </a>
                    
                    <a class="btns ufo" href="<?php echo esc_url( get_permalink( get_page_by_title( 'Intellipaat For Organizations' ) ) ); ?>">
                        <i class="icon-building-24"></i>
                        Intellipaat For Organizations
					</a>                    
               </div>
                    
                <?php //endif; ?>			
            
        </div>
    </div>
</div>
<div id="footerinfo" class="hidden-xs">
	<div class="container">
        <div class="row">
        	<div class="col-md-7">
            	<p class="secure-pay-info"><span><strong>100%</strong> Secure Payments.</span> <span>All major credit & debit cards accepted Or Pay by Paypal</span></p>
            </div>
        	<div class="col-md-5">
            	<p class="pay_methods"><?php /*?>Payment method <?php */?><span> </span></p>
            </div>
        </div>
    </div>
</div>
</div><!-- END PUSHER -->
</div><!-- END MAIN -->
	<!-- SCRIPTS -->
 
<?php
wp_footer();
?>    
<?php
echo vibe_get_option('google_analytics');
?>
</body>
</html>