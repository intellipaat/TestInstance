<?php 

define('TLD', end(explode('.', $_SERVER['HTTP_HOST'])));

add_theme_support( 'post-thumbnails' );

include_once('includes/all-functions.php');

include_once('lib/intellipaat-course_page-actions.php');
include_once('lib/intellipaat-comments-actions.php');
include_once('lib/intellipaat-theme-actions.php');
include_once('lib/intellipaat-security-actions.php');
include_once('lib/intellipaat-user-registration-actions.php');
include_once('lib/intellipaat-woocommerce-actions.php');
include_once('lib/intellipaat-ajax-actions.php');

if(file_exists( get_stylesheet_directory() . '/lib/intellipaat-'.TLD.'-actions.php'))
	include_once( 'lib/intellipaat-'.TLD.'-actions.php');


function point_to_com_site($link){
	return str_replace(array('http://','.in','.uk'),array('https://','.com','.com'), $link );
}

function intellipaat_selfpaced_course_button($id=NULL){
  global $post;
  $rel = (TLD == 'com' ? '' : 'rel="nofollow"') ;
  if(isset($id) && $id)
    $course_id=$id;
   else 
    $course_id=get_the_ID();

  // Free Course
   $free_course= get_post_meta($course_id,'vibe_course_free',true);

  if(!is_user_logged_in() && vibe_validate($free_course)){
    echo apply_filters('wplms_course_non_loggedin_user','<a href="'.get_permalink($course_id).'?error=login" class="course_button button full" '.$rel.'>'.__('Self-Paced Course','vibe').'</a>'); 
    return;
  }

   $take_course_page=get_permalink(vibe_get_option('take_course_page'));
   $user_id = get_current_user_id();

   do_action('wplms_the_course_button',$course_id,$user_id);

  /* $coursetaken=get_user_meta($user_id,$course_id,true);
   
   if(isset($free_course) && $free_course && $free_course !='H' && is_user_logged_in()){

      $duration=get_post_meta($course_id,'vibe_duration',true);
      $course_duration_parameter = apply_filters('vibe_course_duration_parameter',86400);
      $new_duration = time()+$course_duration_parameter*$duration; //parameter 86400

      $new_duration = apply_filters('wplms_free_course_check',$new_duration);
      if(update_user_meta($user_id,$course_id,$new_duration)){
        $group_id=get_post_meta($course_id,'vibe_group',true);
        if(isset($group_id) && $group_id !=''){
          groups_join_group($group_id, $user_id );
        }
      }
      $coursetaken = $new_duration;      
   }*/
	
   if(isset($coursetaken) && $coursetaken && is_user_logged_in()){
	   
	  echo '<a href="http://intellipaat.com/elearning/login/index.php" class="'.((isset($id) && $id )?'':'course_button full ').'button" '.$rel.'>'.__('Start Course','vibe').'</a>'; 
    	
	}else{
      $pid=get_post_meta($course_id,'vibe_product',true);
      $pid=apply_filters('wplms_course_product_id',$pid,$course_id);
      $extra ='';
      if(isset($pid) && $pid){
		  $product = get_product( $pid );
		  if(is_object($product))
			$credits = $product->get_price_html();
			//$credits = apply_filters('wplms_course_credits',$credits,$id);
			
			echo '<div itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
					<h5 class="credits price">'.bp_course_get_course_credits('course_id='.$course_id).'</h5>
					<meta itemprop="price" content="'.$product->get_price().'">
					<meta itemprop="priceCurrency" content="'.get_woocommerce_currency().'">
					<link itemprop="availability" href="http://schema.org/'.($product->is_in_stock() ? 'InStock' : 'OutOfStock').'">
				</div>
				<a href="'.point_to_com_site(get_permalink($pid)).'" class="'.((isset($id) && $id )?'':' ').'button" '.$rel.'>'.__('Take Self-Paced Course','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; 
      }
   }
}

function intellipaat_online_course_button($id=NULL){
  global $post;
  $rel = (TLD == 'com' ? '' : 'rel="nofollow"') ;
  if(isset($id) && $id)
    $course_id=$id;
   else 
    $course_id=get_the_ID();
	
	$pid=get_post_meta($course_id,'intellipaat_online_training_course',true);
 
	if(!empty($pid) && $pid != 'null' && $pid != NULL ){
	  // Free Course
	   //$free_course= get_post_meta($course_id,'intellipaat_online_free_course',true);
	
	  if(!is_user_logged_in() && vibe_validate($free_course)){
		echo apply_filters('wplms_course_non_loggedin_user','<a href="'.get_permalink($course_id).'?error=login" class="course_button button full" '.$rel.'>'.__('Online training','vibe').'</a>'); 
		return;
	  }
	
	   $take_course_page=get_permalink(vibe_get_option('take_course_page'));
	   $user_id = get_current_user_id();
	
	   /*do_action('wplms_the_course_button',$course_id,$user_id);
	
	   $coursetaken=get_user_meta($user_id,$course_id,true);
	   
	   if(isset($free_course) && $free_course && $free_course !='H' && is_user_logged_in()){
	
		  $duration=get_post_meta($course_id,'vibe_duration',true);
		  $course_duration_parameter = apply_filters('vibe_course_duration_parameter',86400);
		  $new_duration = time()+$course_duration_parameter*$duration; //parameter 86400
	
		  $new_duration = apply_filters('wplms_free_course_check',$new_duration);
		  if(update_user_meta($user_id,$course_id,$new_duration)){
			$group_id=get_post_meta($course_id,'vibe_group',true);
			if(isset($group_id) && $group_id !=''){
			  groups_join_group($group_id, $user_id );
			}
		  }
		  $coursetaken = $new_duration;
	   }*/
		
	   if(isset($coursetaken) && $coursetaken && is_user_logged_in()){
		  
		  echo '<a href="http://intellipaat.com/elearning/login/index.php" class="'.((isset($id) && $id )?'':'course_button full ').'button"  '.$rel.'>'.__('Start Online training','vibe').'</a>'; 
			
		}else{
			$pid=apply_filters('wplms_course_product_id',$pid,$course_id);
			$extra ='';
			if(isset($pid) && $pid){
			  
			if(vibe_validate($free_course)){
				$credits .= apply_filters('wplms_free_course_price','FREE');
			}else{
				
				if(isset($pid) && $pid !='' && function_exists('get_product')){
					
					$product = get_product( $pid );
					if(is_object($product))
					$credits = $product->get_price_html();
					//$credits = apply_filters('wplms_course_credits',$credits,$id);
					
					echo '<div itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
							<h5 class="credits price">'.$credits .'</h5>
							<meta itemprop="price" content="'.$product->get_price().'">
							<meta itemprop="priceCurrency" content="'.get_woocommerce_currency().'">
							<link itemprop="availability" href="http://schema.org/'.($product->is_in_stock() ? 'InStock' : 'OutOfStock').'">
						</div>
							<a href="'.point_to_com_site(get_permalink($pid)).'" class="'.((isset($id) && $id )?'':' ').'button" '.$rel.'>'.__('Take Online training','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; 
				
					//echo '<h5 class="credits">'.$credits .'</h5><a href="'.point_to_com_site(get_permalink($pid)).'" class="'.((isset($id) && $id )?'':' ').'button">'.__('Take Online training','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; 
				}else{
						echo '';
				}
			}
			
			/*echo '<div class="course_details"><ul><li><i class="icon-wallet-money"></i> <h5 class="credits">'.$credits .'</h5></li></ul></div>';
			echo '<a href="'.get_permalink($pid).'" class="'.((isset($id) && $id )?'':'course_button full ').'button">'.__('Take Online training','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; */
		  }
	   }
	}
}


function intellipaat_the_course_details($args=NULL){
  echo intellipaat_get_the_course_details($args);
}

function intellipaat_get_the_course_details($args=NULL){
  $defaults=array(
    'course_id' =>get_the_ID(),
    );
  $r = wp_parse_args( $args, $defaults );
  extract( $r, EXTR_SKIP );

  $precourse=get_post_meta($course_id,'vibe_pre_course',true);
  $maximum = get_post_meta($course_id,'vibe_max_students',true);
  $badge=get_post_meta($course_id,'vibe_course_badge',true);
  $certificate=get_post_meta($course_id,'vibe_course_certificate',true);
  $level = vibe_get_option('level');
  if(isset($level) && $level)
    $levels=get_the_term_list( $course_id, 'level', '', ', ', '' );

  $course_details = array(
    //'price' => '<li><i class="icon-wallet-money"></i> <h5 class="credits">'.bp_course_get_course_credits('course_id='.$course_id).'</h5></li>',
   // 'precourse'=>((isset($precourse) && $precourse!='')?'<li><i class="icon-clipboard-1"></i> '.__('* REQUIRES','vibe').' <a href="'.get_permalink($precourse).'">'.get_the_title($precourse).'</a></li>':''),
   // 'time' => apply_filters('wplms_course_details_time','<li><i class="icon-clock"></i>'.get_the_course_time('course_id='.$course_id).'</li>'),
  //  'level' => ((isset($level) && $level && strlen($levels)>5)?'<li><i class="icon-bars"></i> '.$levels.'</li>':''),
  //  'seats' => ((isset($maximum) && is_numeric($maximum) && $maximum < 9999 )?'<li><i class="icon-users"></i> '.$maximum.' '.__('SEATS','vibe').'</li>':''),
   // 'badge' => ((isset($badge) && $badge && $badge !=' ')?'<li><i class="icon-award-stroke"></i> '.__('Course Badge','vibe').'</li>':''),
   // 'certificate'=> (vibe_validate($certificate)?'<li><i class="icon-certificate-file"></i>  '.__('Course Certificate','vibe').'</li>':''),
    );

  $course_details = apply_filters('wplms_course_details_widget',$course_details);
  global $post;
  $return ='<div class="course_details">
              <ul>'; 
  foreach($course_details as $course_detail){
    if(isset($course_detail) && strlen($course_detail) > 5)
      $return .=$course_detail;
  }
  $return .=  '</ul>
            </div>';
   return apply_filters('wplms_course_front_details',$return);
}

//replace vibe_breadcrumbs() funciton
if(!function_exists('vibe_breadcrumbs') && function_exists('yoast_breadcrumb') ){
	function vibe_breadcrumbs() {  
		$breadcrumbs = yoast_breadcrumb('<p id="breadcrumbs">','</p>',false);

		if(is_singular('course')){
			global $post;
			$wpseo_internallinks = get_option('wpseo_internallinks');
			$breadcrumbs_home = $wpseo_internallinks['breadcrumbs-home'];
			
			$term_list = wp_get_post_terms($post->ID, 'course-cat', array("fields" => "names"));
			if($term_list){
				if (in_array("Big Data", $term_list) || in_array("Cloud Computing", $term_list) || in_array("Application Development", $term_list)){
					$breadcrumbs = str_replace($breadcrumbs_home, 'Hadoop' , $breadcrumbs);
				}
				if (in_array("Business Intelligence", $term_list) || in_array("Data Mining", $term_list) || in_array("DataBase", $term_list)){
					$breadcrumbs = str_replace($breadcrumbs_home, 'Big data' , $breadcrumbs);
				}
			}
		}			
		echo $breadcrumbs;
	}
}


function intellipaat_browse_course_menu($cats){
	$taxonomy = 'course-cat';
	echo '<div id="browse_courses" class="cats-dropdown cats-toggle">';
		echo '<div class="dropdown-toggle" data-toggle="dropdown">
					<a href="#" class="white-link button">
						<span class="nav-bars alignleft "><span class="nav-one"></span><span class="nav-two"></span><span class="nav-three"></span></span>
						<span class="text alleft"> Browse Courses</span>
					</a>
			</div>';

		if($cats)
			$cats = explode(',', $cats);
		else 
			$cats = get_terms($taxonomy , array('orderby' => 'id'));

		$no_of_cats = count($cats);
		$no_of_courses_shown_in_cat = $no_of_cats;
		echo '<div class="dropdown-menu" >';
			echo '<ul class="dropdown-menu-list">';
			/*if(is_user_logged_in()){
				echo '<li>
							<a class="main-cat" href="'.site_url('#Discover_Courses').'">
								<i class="icon-rocket cat-icon"></i>
								<span>Recommended for You</span>
							</a>
						</li>';
				echo '<li class="divider"></li>';
			}*/
			foreach($cats as $cat){
				$term = get_term( $cat, $taxonomy );
				echo '<li  data-submenu-id="submenu-'.$term->slug.'"><a class="main-cat menu-item" href="javascript:void(0)" title="'.$term->name.'" ><span>'.$term->name.'</span><i class="icon-arrow-1-right arr"></i></a>';
				$courses = get_posts(array(
								'posts_per_page' => -1,
								'post_type' => 'course',
								$taxonomy => $term->slug,
								'orderby' => 'menu_order',
								'order' => 'ASC'
							));
				$no_of_courses = count($courses );
				$box_width = 300*(intval( $no_of_courses/$no_of_courses_shown_in_cat)+1)+30;
				$count = 0;
					
					echo '<div id="submenu-'.$term->slug.'" class="dropdown-menu sub" style="width:'.$box_width.'px">';
					echo '<h4 class="heading">All '.$term->name.' courses</h4>';
					foreach ( $courses as $course ) : 
						if($count%$no_of_courses_shown_in_cat == 0)
							echo '<ul class="browse-sub-menu">';

						echo '<li>
								<a href="'.get_permalink($course->ID).'">'.get_the_title($course->ID).'</a>
							</li>'; 
						$count++;

						if($count%$no_of_courses_shown_in_cat == 0 || $count == $no_of_courses)
							echo '</ul>';
					endforeach; 

					echo '</div>';
				wp_reset_postdata();
				echo '</li>';
			}
			echo '</ul>';
		echo '</div>';
	echo '</div>';
}


?>