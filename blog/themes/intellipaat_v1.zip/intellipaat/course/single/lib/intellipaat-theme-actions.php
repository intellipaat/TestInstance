<?php

/**
* Adds upcoming batch table in course content using wplms_before_course_description action
*
*/

global $post;

if(class_exists('WPLMS_Events_Interface')){
	function intellipaat_event_calendar($course=NULL) {
		
		$current_date = date('Y-m-d');
		
		$args = array( 
					  'post_type' => WPLMS_EVENTS_CPT,
				);		
		
		$args['meta_query']=array(
			'relation' => '"AND"',
		);
		$args['meta_query'][]=array(
			'key' => 'vibe_start_date',
			'compare' => '>',
			'value' => $current_date,
			'type' => 'DATE'
		);		
		/*$args['meta_query'][]=array(
			'key' => 'vibe_end_date',
			'compare' => '>',
			'value' => $current_date,
			'type' => 'DATE'
		);*/
		$args['meta_query'][]=array(
			'key' => 'vibe_event_course',
			'compare' => '=',
			'value' => get_the_ID(),
			'type' => 'DECIMAL'
		);
		$args['orderby']='meta_value';
		$args['order']='ASC';
		$args['meta_key'] = 'vibe_start_date';
	
		$eventdaysquery = new WP_Query( $args );
		
		if($eventdaysquery->have_posts()){
			echo '<h4><b>Upcoming Batches:</b> </h4>';
			echo '<table class="table upcoming_batches">
					<thead>
						<tr>
							<th>STARTS</th>
							<th>DURATION</th>
							<th class="remove_table_class">DAYS</th>
							<th>Time</th>
						</tr>
					</thead>
					<tbody class="context">';
			
			while ( $eventdaysquery->have_posts() ) {
				$eventdaysquery->the_post();
				global $post;
				$icon = get_post_meta($post->ID,'vibe_icon',true);
				$color = get_post_meta($post->ID,'vibe_color',true);
				$start_date = get_post_meta($post->ID,'vibe_start_date',true);
				$end_date = get_post_meta($post->ID,'vibe_end_date',true);
				$start_time =  get_post_meta(get_the_ID(),'vibe_start_time',true);
				$end_time =  get_post_meta(get_the_ID(),'vibe_end_time',true);
				$duration = get_post_meta(get_the_ID(),'intellipaat_course_duration',true);
				$days = get_post_meta(get_the_ID(),'intellipaat_course_days',true);
				
				echo '<tr>
						<td>'.date('dS, M',strtotime($start_date)).'</td>	
						<td>'.$duration.'</td>	
						<td>'.implode(', ',$days).'</td>	
						<td>'.$start_time.' - '.$end_time.'</td>				
				</tr>';
			}
			
			echo '</tbody></table>';
		}
		wp_reset_postdata();
		
	}
	
	add_action('wplms_before_course_description','intellipaat_event_calendar' );
}

/**
* Adds course details below course content using bp_after_course_home_content action
*
*/

function intellipaat_after_course_home_content(){
	$id =get_the_ID();
	
	$intellipaat_course_certification = get_field('intellipaat_course_certification', $id); 
	if(!empty($intellipaat_course_certification)){
		echo '<div id="certification" class="content"><h4 class="heading"><b>Certification</b> </h4>'. $intellipaat_course_certification.'</div>';
	}
	
	$intellipaat_selfpaced_vs_instructor_based = get_field('intellipaat_selfpaced_vs_instructor_based', $id); 
	if(!empty($intellipaat_selfpaced_vs_instructor_based)){
		echo '<div id="self-instructor" class="content"><h4 class="heading"><b>Self-Paced Vs Instructor LED Online</b> </h4>'.$intellipaat_selfpaced_vs_instructor_based.'</div>';	
	}
}

add_action('bp_after_course_home_content','intellipaat_after_course_home_content' );

 /*function auto_login_new_user( $sanitized_user_login, $user_email, $errors ) {
	  if( email_exists( $user_email )) {
			wp_set_current_user($user_id);
			wp_set_auth_cookie($user_id);
			wp_redirect( home_url() );
			die();
	   }       
}*/
//add_action( 'user_register', 'auto_login_new_user' , 9, 3);

function wc_auto_login($wc_post){
	$email = $wc_post['billing_email'];	
	 if( email_exists( $email  )) {
		 	$user = get_user_by( 'email', $email  );
			wp_set_current_user($user->ID);
			//wp_set_auth_cookie($user->ID);
	   }
}
add_action( 'woocommerce_after_checkout_validation', 'wc_auto_login' , 9, 1);

add_filter('wp_nav_menu_items','sk_wcmenucart', 10, 2);
function sk_wcmenucart($menu, $args) {
 
	// Check if WooCommerce is active and add a new item to a menu assigned to Primary Navigation Menu location
	if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || ( 'mobile-menu' !== $args->theme_location && 'top-menu' !== $args->theme_location ) )
		return $menu;
 
	ob_start();
		global $woocommerce;
		$viewing_cart = __('View your shopping cart', 'intellipaat');
		$start_shopping = __('Start shopping', 'intellipaat');
		$cart_url = $woocommerce->cart->get_cart_url();
		$shop_page_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
		$cart_contents_count = $woocommerce->cart->cart_contents_count;
		$cart_contents = sprintf(_n('%d item', '%d items', $cart_contents_count, 'intellipaat'), $cart_contents_count);
		$cart_total = $woocommerce->cart->get_cart_total();
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
		// if ( $cart_contents_count > 0 ) {
			if ($cart_contents_count == 0) {
				$menu_item = '<li class="menu-item woo-cart-menu empty"><a class="wcmenucart-contents" href="'. $shop_page_url .'" title="'. $start_shopping .'">';
			} else {
				$menu_item = '<li class="menu-item woo-cart-menu filled"><a class="wcmenucart-contents" href="'. $cart_url .'" title="'. $viewing_cart .'">';
			}
 
			$menu_item .= '<i class="icon-shopping-cart"></i> ';
 
			$menu_item .= $cart_contents.' - '. $cart_total;
			$menu_item .= '</a></li>';
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
		// }
		echo $menu_item;
	$social = ob_get_clean();
	return $menu . $social;
 
}

/**
*	To manupulate thumbnail_generator output for class view
*/
function intellipaat_course_duration(){
	global $post;
	$duration = get_post_meta($post->ID,'vibe_duration',true);
	if($duration)
		return '<span class="intelli_duration pull-right"><i class="icon-clock"> </i> '.$duration.' Hrs</span>';
	else
		return '';
}
add_filter( 'vibe_thumb_instructor_meta', 'intellipaat_course_duration' );

function intellipaat_thumb_student_count($val){
	$val = str_replace('Students', 'Learners', $val);
	return '<span class="intelli_students"><i class="icon-users"> </i>'.$val.'</span>';
}
add_filter( 'vibe_thumb_student_count', 'intellipaat_thumb_student_count', 10 , 1 );
add_filter( 'wplms_course_meta', 'intellipaat_thumb_student_count', 10 , 1 );


function intellipaat_thumb_reviews($val){
	return '';
}
add_filter( 'vibe_thumb_reviews', 'intellipaat_thumb_reviews', 10 , 1 );


function intellipaat_course_credits($course_credits, $course_id){
	if($course_credits == '</strong>' || empty($course_credits) || strlen($course_credits)<= 9 ){
		$pid=get_post_meta($course_id,'intellipaat_online_training_course',true);
		if(isset($pid) && $pid !='' && function_exists('get_product')){
			
			$product = get_product( $pid );
			if(is_object($product))
			$course_credits = '<strong>'.$product->get_price_html().'</strong>';
		}
		
	}
	return $course_credits;
}
add_filter( 'wplms_course_credits', 'intellipaat_course_credits', 10 , 2 );



?>