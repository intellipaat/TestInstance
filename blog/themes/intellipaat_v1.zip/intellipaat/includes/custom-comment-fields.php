<?php

  //the code below for changing default comment form(i have not added it anywhere yet)
add_filter( 'comment_form_defaults', 'intelli_change_comment_form_defaults');

function intelli_change_comment_form_defaults( $default ) {
    $commenter = wp_get_current_commenter();	
    $default[ 'fields' ][ 'email' ] .= '<p class="comment-form-author">' .
        '<label for="city">'. __('City') . '</label>
        <span class="required">*</span>
        <input id="city" name="city" size="30" type="text" /></p>';
    return $default;
}
add_action( 'comment_post', 'intelli_save_comment_meta_data' );

function intelli_save_comment_meta_data( $comment_id ) {
    $cities = explode( ',', $_POST[ 'city' ] );
    foreach ( $cities as $city )
       echo add_comment_meta( $comment_id, 'city', $city, false );
}

add_filter( 'preprocess_comment', 'intelli_verify_comment_meta_data' );

function intelli_verify_comment_meta_data( $commentdata ) {
    if ( ! isset( $_POST['city'] ) )
        wp_die( __( 'Error: please fill the required field (city).' ) );
    return $commentdata;
}
add_filter( 'get_comment_author_link', 'intelli_attach_city_to_author' );

function intelli_attach_city_to_author( $author ) {
    $cities = get_comment_meta( get_comment_ID(), 'city', false );
    if ( $cities ) {
        $author .= ' ( ';
        foreach ( $cities as $city )
            $author .= $city . ' ';
        $author .= ')';
    }
    return $author;
}
$new_city = get_comment_meta( get_comment_ID(), 'city', false );
update_comment_meta( $comment_id, 'city', $new_city );

?>