<?php

class IntellipatCurrencyConvertor extends WP_Widget {

	function IntellipatCurrencyConvertor() {
		// Instantiate the parent object
		parent::__construct( false, 'Woocommerce Currency Convertor for Intellipaat' );
	}

	function widget( $args, $instance ) {
		// Widget output
		extract($args);

		$title   = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
		
		echo $before_widget;

		if ($title) echo $before_title . $title . $after_title;
		
		echo '<p>Select your checkout Currency.</p>';
		
		echo '<select id="curreny_convertor" name="curreny_convertor">
				<option value="USD">US Dollar</option>
				<option value="INR">Indian Rupee</option>
			</select>';
			
		?><script>
			jQuery(document).ready(function($){
				add_curreny_span();	
				switch_currency(jQuery("#curreny_convertor").val());
				//alert(jQuery("#curreny_convertor").val());
				//jQuery("li.payment_method_paypal input").attr("checked","checked");
				//jQuery("li.payment_method_ebs").hide();
								
				jQuery( document ).ajaxComplete(function() {
				  add_curreny_span();
				  switch_currency(jQuery("#curreny_convertor").val());
				});
				
				jQuery("#curreny_convertor").change(function(){
					switch_currency(jQuery(this).val());
				});
				
				jQuery("#billing_country").change(function(){
					if(jQuery(this).val() == 'IN' )
						jQuery("#curreny_convertor").val('INR').trigger('change');
					else
						jQuery("#curreny_convertor").val('USD').trigger('change');
				});
				
				function switch_currency($currency){
					if( $currency == "INR"){
						//settings for payment gateway
						jQuery("li.payment_method_ebs").show();
						jQuery("li.payment_method_ebs input").attr("checked","checked");
						jQuery("li.payment_method_paypal").hide();
						//settings for currency conversion						
						jQuery('span.amount').each(function(){
							jQuery(this).html('&#8377; '+(parseFloat(jQuery(this).attr("data-price"))*57));
						});	
						
					}else{
						//settings for payment gateway
						jQuery("li.payment_method_paypal").show();
						jQuery("li.payment_method_paypal input").attr("checked","checked");
						jQuery("li.payment_method_ebs").hide();
						//settings for currency conversion
						jQuery('span.amount').each(function(){
							jQuery(this).html(jQuery(this).attr("data-original"));
						});
					}
				}
								
				function add_curreny_span(){
					jQuery('span.amount').each(function(){
						
						if(jQuery(this).hasClass('rupee'))
							jQuery(this).hide();
						else{								
							var original_code = jQuery(this).attr("data-original");		
							if (typeof original_code == 'undefined' || original_code == false) {
								jQuery(this).attr("data-original", jQuery(this).html());
								//jQuery(this).addClass("USD");
							}		
								// Original price
							var original_price = jQuery(this).attr("data-price");
				
							if (typeof original_price == 'undefined' || original_price == false) {
				
								// Get original price
								var original_price = jQuery(this).html();
				
								// Small hack to prevent errors with $ symbols
								jQuery( '<del></del>' + original_price ).find('del').remove();
				
								// Remove formatting
								original_price = original_price.replace( ',', '' );
								original_price = original_price.replace(/[^0-9\.]/g, '');
								original_price = parseFloat( original_price );
				
								// Store original price
								jQuery(this).attr("data-price", original_price);
								//jQuery(this).after("<span class='INR amount'>INR. "+original_price+"</span>"); //my second to add span having class inr and toggle hide and show
							}
						}
					
					});
				}
				
			});
		</script>
        <?php
			
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		// Save widget options
		$instance['title'] = empty( $new_instance['title'] ) ? '' : strip_tags(stripslashes($new_instance['title']));
		return $instance;
	}

	function form( $instance ) {
		// Output admin widget options form
		global $wpdb;
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'wc_currency_converter') ?></label>
		<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" value="<?php if (isset ( $instance['title'])) {echo esc_attr( $instance['title'] );} else {echo __('Currency converter', 'wc_currency_converter');} ?>" /></p>
		<?php
	}
}

function IntellipatCurrencyConvertor_widget() {
	register_widget( 'IntellipatCurrencyConvertor' );
}

add_action( 'widgets_init', 'IntellipatCurrencyConvertor_widget' );

?>