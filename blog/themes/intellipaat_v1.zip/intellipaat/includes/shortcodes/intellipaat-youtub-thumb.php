<?php 

add_shortcode( 'videothumb', 'video_thumbnail' );

function video_thumbnail($atts){
	
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < 5; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
	
	extract( shortcode_atts( array(

		  'id'   => 'Rq6kcjUubbU',
		  'class'=> 'col-md-4',
		  'name' => ''

      ), $atts ) );
	
	
	$output = "<div class='thumb_course_links ".$class."'>";	
	
		$output .= "<div class='crop_thumb'>";			
			
				if(is_user_logged_in() || isset($_COOKIE['intellipaat_visitor']) ){
			
					$output .= "<a class='hs-rsp-popup popup-youtube hiddendiv' href='http://www.youtube.com/watch?v=".$id."'>";
					
					$output .= "<img src='//img.youtube.com/vi/".$id."/0.jpg' height='150px' width='200px' title='Click to watch video' class='thumb-img'>";
										
					$output .= "<span class='play-video icon-play-alt'></span></a>";
								
				}
				else{
	
					$output .="<a class='popup-with-form' href='#login-form'>";
					
					$output .= "<img src='//img.youtube.com/vi/".$id."/0.jpg' height='150px' width='200px' class='thumb-img'>";
										
					$output .= "<span class='play-video icon-play-alt'></span></a>";
	
				}
		
		$output .= "</div>";
		
		if(isset($name) && $name!=''){			
			$output .= "</span><p>$name</p>";			
		}
		
	$output .= "</div>";
		
	return $output;
}


add_action('wp_footer','form_to_login_user');

function form_to_login_user(){	
	
	if(is_user_logged_in() || isset($_COOKIE['intellipaat_visitor']) || !is_singular( 'course' ))
		return;
		
    global $post;
	?>	
    
	<div id="login-form"  class="white-popup-block mfp-hide">
		<?php global $user_ID, $user_identity; get_currentuserinfo();  ?>      
              
        <div id="login-div" class="row tab_content_login clearfix">
            
           <?php /*?> <div class="col-md-6 col-md-offset-0 login-sub visible login">
                <h2>User Login</h2>    
    
                <form method="post" action="<?php bloginfo('url') ?>/my-account" class="wp-user-form">
                
                    <div class="input-group">
                      <span class="input-group-addon icon-envelope"></span>
                      <input type="text" class="form-control" name="log" required="required" value="<?php echo esc_attr(stripslashes($user_login)); ?>" size="20" id="user_login" tabindex="1" placeholder="Uername"/> 
                    </div>
                       <br />
                    <div class="input-group">
                      <span class="input-group-addon icon-lock"></span>
                      <input type="password" class="form-control" name="pwd" required="required" value="" size="20" id="user_pass" tabindex="2" placeholder="Password" /> 
                    </div>
                       <br />                                                                   
                    <?php do_action('login_form'); ?>
                    <input type="submit" id="submit" name="user-submit" class="pull-right user-submit" value="<?php _e('Login'); ?>" tabindex="3" />
                    <input type="hidden" name="redirect_to" value="<?php echo site_url().$_SERVER['REQUEST_URI']; ?>" />
                    <input type="hidden" name="user-cookie" value="1" />
                
                </form>
            </div><!--login-sub ends--><?php */?>
            
		   <?php
                $nonce = wp_create_nonce("intellipaat_visitor_secure_signup_nonce");
                $link = admin_url('admin-ajax.php?action=intellipaat_visitor_secure_signup');
            ?>
            
            <div class="col-md-12 login-sub visible register">
                <h2>Enter your details</h2>
                
                 <form method="post" action="<?php echo $link; ?>" name="signup_form" id="signup_form" class="wp-user-form">                                 
                
                   <div class="input-group">
                      <span class="input-group-addon icon-envelope"></span>
                      <input type="email" class="form-control" name="user_email" required="required"  size="20" id="user_login" tabindex="4" placeholder="Email Address (Required)"/> 
                    </div>
                       <br />
                    <div class="input-group">
                      <span class="input-group-addon icon-telephone-24"></span>
                      <input type="text"  class="form-control"  name="phone"  required="required"  placeholder="Phone (Required)" id="phno" tabindex="5" />
                    </div>
                   <br />       
                                                           
                    <input type="hidden" name="nonce" value="<?php echo $nonce ; ?>" /> 
                    <input type="hidden" name="page_id" value="<?php echo $post->ID ; ?>" />        
                    <input type="submit" name="user-submit"  id="signup_submit" value="Submit" tabindex="6" class="pull-right user-submit"/>                        
                   
                 </form>
            </div><!--login sub ends-->
        </div>
    </div>
    
	<script>
    
    	jQuery(document).ready(function() {
										
			jQuery('.popup-with-form').magnificPopup({
				type: 'inline',
				preloader: false,
				focus: '#user_email',
				fixedContentPos: false,
				fixedBgPos: true,
		
				overflowY: 'auto',
		
				closeBtnInside: true,
				preloader: false,
				
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-slide-bottom',
		
				// When elemened is focused, some mobile browsers in some cases zoom in
				// It looks not nice, so we disable it:
				callbacks: {
					beforeOpen: function() {
						if(jQuery(window).width() < 700) {
							this.st.focus = false;
						} else {
							this.st.focus = '#user_email';
						}
					}
				}
			});
			
			var form= jQuery('#signup_form');
			var currentPage = '<?php echo $_SERVER["HTTP_REFERER"]; ?>';
			form.submit(function(ev) {
				ev.preventDefault();
				jQuery.ajax({
					 type : "post",
					 dataType : "json",
					 url : form.attr('action'),
					 data : form.serializeArray(),
					 success: function(response) {
						if(response.type == "success") {
						   location.reload(true);
						}
						else {
						   alert("Oops! Error occured. Please try again.");
						}
					 }
				}); 
				
			});
		});
    
    </script>
    
    <?php
	
}


add_action("wp_ajax_nopriv_intellipaat_visitor_secure_signup", "intellipaat_visitor_secure_signup_callback");

function intellipaat_visitor_secure_signup_callback() {

   if ( !wp_verify_nonce( $_REQUEST['nonce'], "intellipaat_visitor_secure_signup_nonce") && !is_singular( 'course' )) {
      exit("No naughty business please");
   }   
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
	   
	   global $wpdb;
	   $now = date('Y-m-d H:i:s');
	   	$wpdb->insert( 
			$wpdb->prefix.'intellipaat_visitors', 
			array( 
				'email' => $_REQUEST['user_email'] ,
				'phone' => $_REQUEST['phone'], 
				'ip' => $_SERVER['REMOTE_ADDR'] ,
				'visited_url' => get_permalink($_REQUEST['page_id']), 
				'date_time' => $now ,
			)
		);
		setcookie('intellipaat_visitor', true, time()+60*60*24*30, '/');
		setcookie('intellipaat_visitor_email', $_REQUEST['user_email'], time()+60*60*24*30, '/');
		if($_REQUEST['phone'])
			setcookie('intellipaat_visitor_phone', $_REQUEST['phone'], time()+60*60*24*30, '/');
		
		/*$message = '<!DOCTYPE HTML>
						<html>
						<head></head>
						<body>
							<p>
								<strong>New Visitor</strong> @ '.site_url().' <br /><br />
								<strong>Email</strong> : '.$_REQUEST['user_email'].' <br />
								<strong>Phone</strong> : '.$_REQUEST['phone'].'  <br />
								<strong>Visited url</strong> : '.get_permalink($_REQUEST['page_id']).'<br />
								<strong>IP Address </strong>: '.$_SERVER['REMOTE_ADDR'].' <br />
								<strong>Date/time</strong> '.$now.'
							</p>
						</body>
						</html>' ;
		
		$headers .= "Reply-To: ".$_REQUEST['user_email']." \r\n";
		
		$headers .= "MIME-Version: 1.0 \r\n";
		
		$headers .= "Content-type: text/html; charset=utf-8 \r\n";
		
		$headers .= "Content-Transfer-Encoding: quoted-printable \r\n";
					
		wp_mail( get_option( 'admin_email' ) , "New visitor @ ".site_url(), $message, $headers); */
		
		$result['type'] = "success";
		$result['inserted_row'] = $wpdb->insert_id ;
      	$result = json_encode($result);
      	echo $result;
   }
   else {
      header("Location: ".$_SERVER["HTTP_REFERER"]);
   }

   die();
}

/*
Query to create table

CREATE TABLE IF NOT EXISTS `ip_intellipaat_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `visited_url` varchar(150) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

*/
?>