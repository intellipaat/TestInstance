<?php

// Add the comment meta (saved earlier) to the comment text
// You can also output the comment meta values directly to the comments template  

add_filter( 'comment_text', 'intellipaat_modify_comment' ,11);
function intellipaat_modify_comment( $text ){
   global $comment;

	if(get_post_type($comment->comment_post_ID) == 'course'){
		$url = ('http://' == $comment->comment_author_url) ? '' : $comment->comment_author_url;
		$url = esc_url( $url, array('http', 'https') );
	  	if( $url ) {
				$url  = '<div class="pull-right">Follow Me on <a class="linkedin_url" rel="nofollow noindex" href="' . esc_attr( $url  ) . '">LinkedIn</a></div>';
				$text =  $text.$url ;
		  }   
	}
	return $text;
}


// Apply filter
add_filter( 'get_avatar' , 'my_custom_avatar' , 11 , 5 );

function my_custom_avatar( $avatar, $id_or_email, $size, $default, $alt ) {
	if(!is_admin())
	{
		
   /* $user = false;
	
    if ( is_numeric( $id_or_email ) ) {
			
        $id = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );
			
        } elseif ( is_object( $id_or_email ) ) {
			
            if ( ! empty( $id_or_email->user_id ) ) {
                $id = (int) $id_or_email->user_id;
                $user = get_user_by( 'id' , $id );
            }
			
    } else {
        $user = get_user_by( 'email', $id_or_email );	
    }*/
		
   // if ( !$user && is_object( $user ) ) {
			
		$avatar = 'https://1.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=120';
		$avatar = "<img alt='{$alt}' src='{$avatar}' class='avatar avatar-{$size} photo' height='{$size}' width='{$size}' />";
			
    //}
	}
    return $avatar;
}

/****************************************
* extra comment fields
*/
/*
add_action( 'comment_form_logged_in_after', 'intellipaat_additional_fields' );
add_action( 'comment_form_after_fields', 'intellipaat_additional_fields' );

function intellipaat_additional_fields () {
  echo '<p class="comment-form-position">'.
  '<label for="position">' . __( 'Your current Position' ) . '<span class="required">*</span></label>'.
  '<input id="position" class="form_field" name="position" type="text" size="30"  tabindex="4" /></p>';

}

// Save the comment meta data along with comment

add_action( 'comment_post', 'intellipaat_save_comment_meta_data' );
function intellipaat_save_comment_meta_data( $comment_id ) {
 
 if ( ( isset( $_POST['position'] ) ) && ( $_POST['position'] != '') )
  $position = wp_filter_nohtml_kses($_POST['position']);
  add_comment_meta( $comment_id, 'position', $position );
  
}

add_filter( 'preprocess_comment', 'intellipaat_verify_comment_meta_data' );
function intellipaat_verify_comment_meta_data( $commentdata ) {
  if ( ! isset( $_POST['position'] ) ||  empty( $_POST['position'] ))
  wp_die( __( 'Error: Please fil required information (Your Position). Go back and retry again.' ) );
  return $commentdata;
}
*/


/*
add_filter( 'get_comment_author', 'intellipaat_modify_comment_author' );

function intellipaat_modify_comment_author( $text ){
   global $comment;

  if(get_post_type($comment->comment_post_ID) == 'course'){
  		if(!is_admin()){
		   if( $position = get_comment_meta( get_comment_ID(), 'position', true ) ) {
			$position = '<br /><span  class="position">' . esc_attr( $position ) . '</span>';
			$text = $text.$position  ;
		  } 
		}
		else{
			 if( $position = get_comment_meta( get_comment_ID(), 'position', true ) ) {
			$position = ' (' . esc_attr( $position ).')';
			$text = $text.$position  ;
		  } 
		}
  }
  
  return $text;
}

// Add an edit option to comment editing screen  

add_action( 'add_meta_boxes_comment', 'intellipaat_extend_comment_add_meta_box' );
function intellipaat_extend_comment_add_meta_box() {
    add_meta_box( 'position', __( 'A persons Extra Information' ), 'intellipaat_extend_comment_meta_box', 'comment', 'normal', 'high' );
}

function intellipaat_extend_comment_meta_box ( $comment ) {
    $position = get_comment_meta( $comment->comment_ID, 'position', true );
    wp_nonce_field( 'intellipaat_extend_comment_update', 'intellipaat_extend_comment_update', false );
    ?>
    <p>
        <label for="position"><?php _e( 'Position' ); ?></label>
        <input type="text" name="position" id="position" value="<?php echo esc_attr( $position ); ?>" class="widefat" />
    </p>
    <?php
}
// Update comment meta data from comment editing screen 

add_action( 'edit_comment', 'intellipaat_extend_comment_edit_metafields' );

function intellipaat_extend_comment_edit_metafields( $comment_id ) {
    if( ! isset( $_POST['intellipaat_extend_comment_update'] ) || ! wp_verify_nonce( $_POST['intellipaat_extend_comment_update'], 'intellipaat_extend_comment_update' ) ) return;

  if ( ( isset( $_POST['position'] ) ) && ( $_POST['position'] != '') ) :
  $phone = wp_filter_nohtml_kses($_POST['position']);
  update_comment_meta( $comment_id, 'position', $phone );
  else :
  delete_comment_meta( $comment_id, 'position');
  endif;

}*/


?>