
<div class="course_title">
	<h2><?php  _e('Recent Blogs','intellipaat'); ?></h2>
</div>

<div class="course_curriculum blog-list">
<?php			
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
/*$args = array(
  posts_per_page' => 3,
  paged' => $paged
);*/
				$query = new WP_Query( array('post_type' =>array('post'), 'posts_per_page' => 4, 'paged' => $paged, 'no_found_rows' => true, 'post_status' => 'publish', 'ignore_sticky_posts' => true )  );

				if ($query->have_posts() ) : while ($query-> have_posts() ) : $query->the_post();

				$categories = get_the_category();
				$cats='<ul>';
				if($categories){
					foreach($categories as $category) {
						$cats .= '<li><a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $category->name ) ) . '">'.$category->cat_name.'</a></li>';
					}
				}
				$cats .='</ul>';
					
				   echo ' <div class="blogpost">
						<div class="meta">
						   <div class="date">
							<p class="day"><span>'.get_the_time('j').'</span></p>
							<p class="month">'.get_the_time('M').'</p>
						   </div>
						</div>
						'.(has_post_thumbnail(get_the_ID())?'
						<div class="featured">
							<a href="'.get_post_meta(get_the_ID(), 'intellipaat-post-href', true).'">'.get_the_post_thumbnail(get_the_ID(),'full').'</a>
						</div>':'').'
						<div class="excerpt '.(has_post_thumbnail(get_the_ID())?'thumb':'').'">
							<h3><a href="'.get_post_meta(get_the_ID(), 'intellipaat-post-href', true).'">'.get_the_title().'</a></h3>
							<div class="cats">
								'.$cats.'
								<p>| 
								<a href="'.get_post_meta(get_the_ID(), 'intellipaat-post-href', true).'">'.get_the_author_meta( 'display_name' ).'</a>
								</p>
							</div>
							<p>'.get_the_excerpt().'</p>
							<a href="'.get_post_meta(get_the_ID(), 'intellipaat-post-href', true).'" class="link">'.__('Read More','vibe').'</a>
						</div>
					</div>';
				endwhile;?>
				
				<div class="nav-previous alignleft"><?php echo next_posts_link( 'Older posts' ); ?></div>
				<div class="nav-next alignright"><?php echo  previous_posts_link( 'Newer posts' ); ?></div>

				
			<?	endif;
				
				
				wp_reset_postdata();
			?>
                    
</div>

<?php

?>