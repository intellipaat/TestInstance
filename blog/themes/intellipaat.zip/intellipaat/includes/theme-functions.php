<?php 


register_nav_menus( array(

		'country' => __('Country Menus')
) );


function point_to_com_site($link){
	return str_replace(array('http://i','http://m.b','.in','.uk'),array('https://i','http://b','.com','.com'), $link );
}

function all_course_page_id(){
	$pages=get_option('bp-pages');
	return $pages['course'] ;
}

function all_course_page_link(){
	return get_permalink( all_course_page_id() );
}

function intellipaat_selfpaced_course_button($id=NULL){
  global $post;
  $rel = (TLD == 'com' ? '' : 'rel="nofollow"') ;
  if(isset($id) && $id)
    $course_id=$id;
   else 
    $course_id=get_the_ID();

  // Free Course
   $free_course= get_post_meta($course_id,'vibe_course_free',true);

  if(!is_user_logged_in() && vibe_validate($free_course)){
    echo apply_filters('wplms_course_non_loggedin_user','<a href="'.get_permalink($course_id).'?error=login" class="course_button button full" '.$rel.'>'.__('Self-Paced Course','vibe').'</a>'); 
    return;
  }

   $take_course_page=get_permalink(vibe_get_option('take_course_page'));
   $user_id = get_current_user_id();

   do_action('wplms_the_course_button',$course_id,$user_id);

   $coursetaken=get_user_meta($user_id,$course_id,true);
   
   if(isset($free_course) && $free_course && $free_course !='H' && is_user_logged_in()){

      $duration=get_post_meta($course_id,'vibe_duration',true);
      $course_duration_parameter = apply_filters('vibe_course_duration_parameter',86400);
      $new_duration = time()+$course_duration_parameter*$duration; //parameter 86400

      $new_duration = apply_filters('wplms_free_course_check',$new_duration);
      if(update_user_meta($user_id,$course_id,$new_duration)){
        $group_id=get_post_meta($course_id,'vibe_group',true);
        if(isset($group_id) && $group_id !=''){
          groups_join_group($group_id, $user_id );
        }
      }
      $coursetaken = $new_duration;      
   }
	
   if(isset($coursetaken) && $coursetaken && is_user_logged_in()){
	   
	  echo '<a href="http://intellipaat.com/elearning/login/index.php" class="'.((isset($id) && $id )?'':'course_button full ').'button" '.$rel.'>'.__('Start Course','vibe').'</a>'; 
    	
	}else{
      $pid=get_post_meta($course_id,'vibe_product',true);
      $pid=apply_filters('wplms_course_product_id',$pid,$course_id);
      $extra ='';
      if(isset($pid) && $pid){
		  $product = get_product( $pid );
		  if(is_object($product))
			$credits = $product->get_price_html();
			
			//$product_link = point_to_com_site(get_permalink($pid));
			$product_link = point_to_com_site(get_permalink(get_the_ID()));
			$check=vibe_get_option('direct_checkout');
			$check =intval($check);
			if(isset($check) &&  $check){
			  $product_link  .= '?type=selfPaced&redirect';
			}
			else{
				$product_link = point_to_com_site(get_permalink($pid));
			}
			//$credits = apply_filters('wplms_course_credits',$credits,$id);
			
			echo '<div itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
					<h5 class="credits price">'.bp_course_get_course_credits('course_id='.$course_id).'</h5>
					<meta itemprop="price" content="'.$product->get_price().'">
					<meta itemprop="priceCurrency" content="'.get_woocommerce_currency().'">
					<link itemprop="availability" href="http://schema.org/'.($product->is_in_stock() ? 'InStock' : 'OutOfStock').'">
				</div>
				<a href="'.$product_link .'" data-product_id="'.$pid.'" class="'.((isset($id) && $id )?'':' ').'add_to_cart_button button" '.$rel.'>'.__('Take Self-Paced Course','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; 
      }
   }
}

function intellipaat_online_course_button($id=NULL){
  global $post;
  $rel = (TLD == 'com' ? '' : 'rel="nofollow"') ;
  if(isset($id) && $id)
    $course_id=$id;
   else 
    $course_id=get_the_ID();
	
	$pid=get_post_meta($course_id,'intellipaat_online_training_course',true);
 
	if(!empty($pid) && $pid != 'null' && $pid != NULL ){
	  // Free Course
	   //$free_course= get_post_meta($course_id,'intellipaat_online_free_course',true);
	
	  if(!is_user_logged_in() && vibe_validate($free_course)){
		echo apply_filters('wplms_course_non_loggedin_user','<a href="'.get_permalink($course_id).'?error=login" class="course_button button full" '.$rel.'>'.__('Online training','vibe').'</a>'); 
		return;
	  }
	
	   $take_course_page=get_permalink(vibe_get_option('take_course_page'));
	   $user_id = get_current_user_id();
	
	   /*do_action('wplms_the_course_button',$course_id,$user_id);
	
	   $coursetaken=get_user_meta($user_id,$course_id,true);
	   
	   if(isset($free_course) && $free_course && $free_course !='H' && is_user_logged_in()){
	
		  $duration=get_post_meta($course_id,'vibe_duration',true);
		  $course_duration_parameter = apply_filters('vibe_course_duration_parameter',86400);
		  $new_duration = time()+$course_duration_parameter*$duration; //parameter 86400
	
		  $new_duration = apply_filters('wplms_free_course_check',$new_duration);
		  if(update_user_meta($user_id,$course_id,$new_duration)){
			$group_id=get_post_meta($course_id,'vibe_group',true);
			if(isset($group_id) && $group_id !=''){
			  groups_join_group($group_id, $user_id );
			}
		  }
		  $coursetaken = $new_duration;
	   }*/
		
	   if(isset($coursetaken) && $coursetaken && is_user_logged_in()){
		  
		  echo '<a href="http://intellipaat.com/elearning/login/index.php" class="'.((isset($id) && $id )?'':'course_button full ').'button"  '.$rel.'>'.__('Start Online training','vibe').'</a>'; 
			
		}else{
			$pid=apply_filters('wplms_course_product_id',$pid,$course_id);
			$extra ='';
			if(isset($pid) && $pid){
			  
			/*if(vibe_validate($free_course)){
				$credits .= apply_filters('wplms_free_course_price','FREE');
			}else{*/
				
				if(isset($pid) && $pid !='' && function_exists('get_product')){
					
					$product = get_product( $pid );
					if(is_object($product))
					$credits = $product->get_price_html();
					
					//$product_link = point_to_com_site(get_permalink($pid));
					$product_link = point_to_com_site(get_permalink(get_the_ID()));
					$check=vibe_get_option('direct_checkout');
					$check =intval($check);
					if(isset($check) &&  $check){
					  $product_link  .= '?type=onlineTraining&redirect';
					}
					else{
						$product_link = point_to_com_site(get_permalink($pid));
					}
					//$credits = apply_filters('wplms_course_credits',$credits,$id);
					
					echo '<div itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">
							<h5 class="credits price">'.$credits .'</h5>
							<meta itemprop="price" content="'.$product->get_price().'">
							<meta itemprop="priceCurrency" content="'.get_woocommerce_currency().'">
							<link itemprop="availability" href="http://schema.org/'.($product->is_in_stock() ? 'InStock' : 'OutOfStock').'">
						</div>
							<a href="'.$product_link.'" data-product_id="'.$pid.'" class="'.((isset($id) && $id )?'':' ').'button add_to_cart_button" '.$rel.'>'.__('Take Online training','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; 
				
					//echo '<h5 class="credits">'.$credits .'</h5><a href="'.point_to_com_site(get_permalink($pid)).'" class="'.((isset($id) && $id )?'':' ').'button">'.__('Take Online training','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; 
				}else{
						echo '';
				}
			/*}
			
			echo '<div class="course_details"><ul><li><i class="icon-wallet-money"></i> <h5 class="credits">'.$credits .'</h5></li></ul></div>';
			echo '<a href="'.get_permalink($pid).'" class="'.((isset($id) && $id )?'':'course_button full ').'button">'.__('Take Online training','vibe').apply_filters('wplms_course_button_extra',$extra,$course_id).'</a>'; */
		  }
	   }
	}
}


function intellipaat_the_course_details($args=NULL){
  echo intellipaat_get_the_course_details($args);
}

function intellipaat_get_the_course_details($args=NULL){
  $defaults=array(
    'course_id' =>get_the_ID(),
    );
  $r = wp_parse_args( $args, $defaults );
  extract( $r, EXTR_SKIP );

  $precourse=get_post_meta($course_id,'vibe_pre_course',true);
  $maximum = get_post_meta($course_id,'vibe_max_students',true);
  $badge=get_post_meta($course_id,'vibe_course_badge',true);
  $certificate=get_post_meta($course_id,'vibe_course_certificate',true);
  $level = vibe_get_option('level');
  if(isset($level) && $level)
    $levels=get_the_term_list( $course_id, 'level', '', ', ', '' );

  $course_details = array(
    //'price' => '<li><i class="icon-wallet-money"></i> <h5 class="credits">'.bp_course_get_course_credits('course_id='.$course_id).'</h5></li>',
   // 'precourse'=>((isset($precourse) && $precourse!='')?'<li><i class="icon-clipboard-1"></i> '.__('* REQUIRES','vibe').' <a href="'.get_permalink($precourse).'">'.get_the_title($precourse).'</a></li>':''),
   // 'time' => apply_filters('wplms_course_details_time','<li><i class="icon-clock"></i>'.get_the_course_time('course_id='.$course_id).'</li>'),
  //  'level' => ((isset($level) && $level && strlen($levels)>5)?'<li><i class="icon-bars"></i> '.$levels.'</li>':''),
  //  'seats' => ((isset($maximum) && is_numeric($maximum) && $maximum < 9999 )?'<li><i class="icon-users"></i> '.$maximum.' '.__('SEATS','vibe').'</li>':''),
   // 'badge' => ((isset($badge) && $badge && $badge !=' ')?'<li><i class="icon-award-stroke"></i> '.__('Course Badge','vibe').'</li>':''),
   // 'certificate'=> (vibe_validate($certificate)?'<li><i class="icon-certificate-file"></i>  '.__('Course Certificate','vibe').'</li>':''),
    );

  $course_details = apply_filters('wplms_course_details_widget',$course_details);
  global $post;
  $return ='<div class="course_details">
              <ul>'; 
  foreach($course_details as $course_detail){
    if(isset($course_detail) && strlen($course_detail) > 5)
      $return .=$course_detail;
  }
  $return .=  '</ul>
            </div>';
   return apply_filters('wplms_course_front_details',$return);
}

//replace vibe_breadcrumbs() funciton
if(!function_exists('vibe_breadcrumbs') && function_exists('yoast_breadcrumb') ){
	function vibe_breadcrumbs() {  
		$breadcrumbs = yoast_breadcrumb('<p id="breadcrumbs">','</p>',false);

		if(is_singular('course')){
			global $post;
			$wpseo_internallinks = get_option('wpseo_internallinks');
			$breadcrumbs_home = $wpseo_internallinks['breadcrumbs-home'];
			
			$term_list = wp_get_post_terms($post->ID, 'course-cat', array("fields" => "names"));
			if($term_list){
				if (in_array("Big Data", $term_list) || in_array("Cloud Computing", $term_list) || in_array("Application Development", $term_list)){
					$breadcrumbs = str_replace($breadcrumbs_home, 'Hadoop' , $breadcrumbs);
				}
				if (in_array("Business Intelligence", $term_list) || in_array("Data Mining", $term_list) || in_array("DataBase", $term_list)){
					$breadcrumbs = str_replace($breadcrumbs_home, 'Big data' , $breadcrumbs);
				}
			}
		}			
		echo $breadcrumbs;
	}
}


function intellipaat_browse_course_menu($cats){
	$taxonomy = 'course-cat';
	echo '<div id="browse_courses" class="cats-dropdown cats-toggle">';
		echo '<div class="dropdown-toggle" data-toggle="dropdown">
					<a href="#" class="white-link fl">
						<span class="nav-bars alignleft "><span class="nav-one"></span><span class="nav-two"></span><span class="nav-three"></span></span>
						<span class="text fl"> Browse Courses</span>
					</a>
			</div>';

		if($cats)
			$cats = explode(',', $cats);
		else 
			$cats = get_terms($taxonomy , array('orderby' => 'id'));

		$no_of_cats = count($cats);
		$no_of_courses_shown_in_cat = $no_of_cats;
		echo '<div class="dropdown-menu" >';
			echo '<ul class="dropdown-menu-list">';
			/*if(is_user_logged_in()){
				echo '<li>
							<a class="main-cat" href="'.site_url('#Discover_Courses').'">
								<i class="icon-rocket cat-icon"></i>
								<span>Recommended for You</span>
							</a>
						</li>';
				echo '<li class="divider"></li>';
			}*/
			foreach($cats as $cat){
				$term = get_term( $cat, $taxonomy );
				echo '<li  data-submenu-id="submenu-'.$term->slug.'"><a class="main-cat menu-item" href="javascript:void(0)" title="'.$term->name.'" ><span>'.$term->name.'</span><i class="icon-arrow-1-right arr"></i></a>';
				$courses = get_posts(array(
								'posts_per_page' => -1,
								'post_type' => 'course',
								$taxonomy => $term->slug,
								'orderby' => 'menu_order',
								'order' => 'ASC'
							));
				$no_of_courses = count($courses );
				$box_width = 300*(intval( $no_of_courses/$no_of_courses_shown_in_cat)+1)+30;
				$count = 0;
					
					echo '<div id="submenu-'.$term->slug.'" class="dropdown-menu sub" style="width:'.$box_width.'px">';
					echo '<h4 class="heading">All '.$term->name.' courses</h4>';
					foreach ( $courses as $course ) : 
						if($count%$no_of_courses_shown_in_cat == 0)
							echo '<ul class="browse-sub-menu">';

						echo '<li>
								<a href="'.get_permalink($course->ID).'">'.get_the_title($course->ID).'</a>
							</li>'; 
						$count++;

						if($count%$no_of_courses_shown_in_cat == 0 || $count == $no_of_courses)
							echo '</ul>';
					endforeach; 

					echo '</div>';
				wp_reset_postdata();
				echo '</li>';
			}
			echo '</ul>';
		echo '</div>';
	echo '</div>';
}

function intellipaat_jump_to(){
	$taxonomy = 'course-cat';
	$cats = vibe_get_option('browse_courses');
	
	if($cats)
			$cats = explode(',', $cats);
	else 
		$cats = get_terms($taxonomy , array('orderby' => 'id'));
		
	echo '<ul class="jump_to_menu clearfix"><p class="fl">Jump to :</p>';
	foreach($cats as $cat){
		$term = get_term( $cat, $taxonomy );
		echo '<li><a href="'.all_course_page_link().$term->slug.'/" title="'.$term->name.'" >'.$term->name.'</a>';
	}
	echo '</ul>';
}

function featured_reviews(){
	
	$output = " ";
	
	 $args = array(
        'number'=>2,
        'offset'=>0,
		'post_type' => 'course',
        'status'=>'approve',
        'order'=>'DESC',
        'search'=>'linkedin',
		'meta_query'=> array(
									'relation' => 'AND',
									array(
										'key'     => 'review_title',
										'value'   => '',
										'compare' => '!='
									),
									array(
										'key'     => 'review_rating',
										'value'   => '5',
										'type' => 'numeric',
										'compare' => '='
									)
							),
    );
	
			
			foreach( get_comments($args) as $comment ){			
				
					$rating ='';
					$url = ('http://' == $comment->comment_author_url) ? '' : $comment->comment_author_url;
						$url = esc_url( $url, array('http', 'https') );
						if( $url ) {
								$url  = '<div class="linkedin fr">Follow Me on <a class="linkedin_url" rel="nofollow noindex" href="' . esc_attr( $url  ) . '">LinkedIn</a></div>';
						}  
						else
							$url ='';
						  
					$commenttitle = get_comment_meta($comment->comment_ID, 'review_title', true );
					if( $commentrating = get_comment_meta( $comment->comment_ID, 'review_rating', true ) ) {
					  $rating .= '<div class="comment-rating star-rating fr">';
					  for($i=0;$i<5;$i++){
						if($commentrating > $i)
						  $rating .='<span class="fill"></span>';
						else
						  $rating .='<span></span>';
					  }
					  $rating .='</div>'; 
					}  
					
					$output .= '<div class="col-md-6 col-sm-6"> ';
									 $output .= '<div class="review-body" id="review-'.$comment->comment_ID.'">
													<div class="review-header clearfix">'.( ( $commenttitle) ? '<strong>' . esc_attr( $commenttitle ) . '</strong>' : '').$rating.'</div>
													<p class="comment-content">'.$comment->comment_content.'</p>
								
										<div class="comment-author vcard clearfix">
											<cite class="fn">-- '.apply_filters( 'comment_author',$comment->comment_author ) .'</cite>
											'.$url .'
										</div> 		
										<div class="author-img img-rounded">
										'.get_avatar( $comment->comment_author_email , 50 ).'			
										</div>								
									</div>'; 
					$output .= '</div> '; 
					
			}
					
	
		
	
	return $output;
}

function intellipaat_recent_posts(){
	global $post;
	$args = array( 'posts_per_page' => 3);

	$myposts = get_posts( $args );
	
	if($myposts){ ?>
        <div id="recent-posts" class="clearfix">
            <h3 class="footertitle col-md-12">Recent Posts</h3>
            <?php foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
                <div class="col-sm-4 footer_posts">
                    <?php if ( has_post_thumbnail() ){ ?>
                            <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail(array(120,71), array('class'=>'alignleft img-responsive'));  ?>
                            </a>
                    <?php } ?>
                    <h5 class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                    <div class="excerpt">
                        <?php the_excerpt(); ?>
                         <a class="read-more link fr" href="<?php the_permalink(); ?>">Read More</a>
                    </div>
            	</div>
            <?php endforeach; ?>
        </div>
	<?php }
	wp_reset_postdata();
}

function the_intellipaat_quiz($args=NULL){

  $defaults=array(
  'quiz_id' =>get_the_ID(),
  'ques_id'=> ''
  );

  $r = wp_parse_args( $args, $defaults );
  extract( $r, EXTR_SKIP );

    $user_id = get_current_user_id();

    $questions = vibe_sanitize(get_post_meta($quiz_id,'quiz_questions'.$user_id,false));
    if(!isset($questions) || !is_array($questions)) // Fallback for Older versions
      $questions = vibe_sanitize(get_post_meta($quiz_id,'vibe_quiz_questions',false));

    if(isset($questions['ques']) && is_array($questions['ques']))
      $key=array_search($ques_id,$questions['ques']);

    if($ques_id){
      $the_query = new WP_Query(array(
        'post_type'=>'question',
        'p'=>$ques_id
        ));
      while ( $the_query->have_posts() ) : $the_query->the_post(); 
        the_question();

        echo '<div class="quiz_bar">';
        if($key == 0){ // FIRST QUESTION
          if($key != (count($questions['ques'])-1)) // First But not the Last
            echo '<a href="#" class="ques_link right quiz_question nextq" data-quiz="'.$quiz_id.'" data-qid="'.$questions['ques'][($key+1)].'">'.__('Next Question','vibe').' &rsaquo;</a>';

        }elseif($key == (count($questions['ques'])-1)){ // LAST QUESTION

          echo '<a href="#" class="ques_link left quiz_question prevq" data-quiz="'.$quiz_id.'" data-qid="'.$questions['ques'][($key-1)].'">&lsaquo; '.__('Previous Question','vibe').'</a>';
          echo '<a id="finalise_quiz" href="#" class="ques_link right nextq" data-quiz="'.$quiz_id.'" data-qid="'.$questions['ques'][($key+1)].'">'.__('Submit Quiz','vibe').'</a>';

        }else{
          echo '<a href="#" class="ques_link left quiz_question prevq" data-quiz="'.$quiz_id.'" data-qid="'.$questions['ques'][($key-1)].'">&lsaquo; '.__('Previous Question','vibe').'</a>';
          echo '<a href="#" class="ques_link right quiz_question nextq" data-quiz="'.$quiz_id.'" data-qid="'.$questions['ques'][($key+1)].'">'.__('Next Question','vibe').' &rsaquo;</a>';
        }

        echo '</div>';
		
					 echo '<small>(Warning: Mandatory to submit an answer, otherwise counted zero) </small>';
      endwhile;
      wp_reset_postdata();
    }else{
        
        $quiz_taken=get_user_meta($user_id,$quiz_id,true);

        if(isset($quiz_taken) && $quiz_taken && ($quiz_taken < time())){
          
          $message=get_post_meta($quiz_id,'vibe_quiz_message',true);
          echo '<div class="main_content">';
          echo $message;
          echo '</div>';
        }else{
          echo '<div class="main_content">';
          the_content();
          echo '</div>';
        }
    } 
  }
?>