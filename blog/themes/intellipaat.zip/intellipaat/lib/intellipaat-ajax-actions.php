<?php

/*
*	WP ajax to send sale initiate email to admin
*/
add_action("wp_ajax_intellipaat_visitor_purchase", "intellipaat_visitor_purchase_callback");
add_action("wp_ajax_nopriv_intellipaat_visitor_purchase", "intellipaat_visitor_purchase_callback");

function intellipaat_visitor_purchase_callback() {

  /* if ( !wp_verify_nonce( $_REQUEST['nonce'], "intellipaat_visitor_purchase_nonce")) {
      exit("No naughty business please");
   } 
   
	$nonce = wp_create_nonce("intellipaat_visitor_purchase_nonce"); 
	*/  
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {

		$now = date('Y-m-d H:i:s');

		$message = '<!DOCTYPE HTML>
						<html>
						<head></head>
						<body>
							<tableborder="1" cellpadding="5" bordercolor="#333333">
								<tr><td style="border:1px solid #cdcdcd;">Key</td><td style="border:1px solid #cdcdcd;>Value</td></tr>';
							
								foreach($_REQUEST as $k => $v){
									$message .=	'<tr style="border:1px solid #cdcdcd;><td>'.$k.'</td><td style="border:1px solid #cdcdcd;>'.$v.'</td></tr>';
								}
								/*<strong>New Visitor</strong> @ '.site_url().' <br /><br />
								<strong>Email</strong> : '.$_REQUEST['billing_email'].' <br />
								<strong>Phone</strong> : '.$_REQUEST['phone'].'  <br />
								<strong>Visited url</strong> : '.get_permalink($_REQUEST['page_id']).'<br />
								<strong>IP Address </strong>: '.$_SERVER['REMOTE_ADDR'].' <br />
								<strong>Date/time</strong> '.$now.'*/

			$message .=				'</table>
										<hr />';
			
			ob_start(); ?>
			
							<table border="1" cellpadding="5" bordercolor="#333333" class="shop_table">
								<thead>
									<tr>
										<th class="product-name"><?php _e( 'Product', 'vibe' ); ?></th>
										<th class="product-total"><?php _e( 'Total', 'vibe' ); ?></th>
									</tr>
								</thead>
								<tfoot>
						
									<tr class="cart-subtotal">
										<th><?php _e( 'Cart Subtotal', 'vibe' ); ?></th>
										<td><?php wc_cart_totals_subtotal_html(); ?></td>
									</tr>
						
									<?php foreach ( WC()->cart->get_coupons( 'cart' ) as $code => $coupon ) : ?>
										<tr class="cart-discount coupon-<?php echo esc_attr( $code ); ?>">
											<th><?php _e( 'Coupon:', 'vibe' ); ?> <?php echo esc_html( $code ); ?></th>
											<td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
										</tr>
									<?php endforeach; ?>
						
									<?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>
						
										<?php do_action( 'woocommerce_review_order_before_shipping' ); ?>
						
										<?php wc_cart_totals_shipping_html(); ?>
						
										<?php do_action( 'woocommerce_review_order_after_shipping' ); ?>
						
									<?php endif; ?>
						
									<?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
										<tr class="fee">
											<th><?php echo esc_html( $fee->name ); ?></th>
											<td><?php wc_cart_totals_fee_html( $fee ); ?></td>
										</tr>
									<?php endforeach; ?>
						
									<?php if ( WC()->cart->tax_display_cart === 'excl' ) : ?>
										<?php if ( get_option( 'woocommerce_tax_total_display' ) === 'itemized' ) : ?>
											<?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
												<tr class="tax-rate tax-rate-<?php echo sanitize_title( $code ); ?>">
													<th><?php echo esc_html( $tax->label ); ?></th>
													<td><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
												</tr>
											<?php endforeach; ?>
										<?php else : ?>
											<tr class="tax-total">
												<th><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
												<td><?php echo wc_price( WC()->cart->get_taxes_total() ); ?></td>
											</tr>
										<?php endif; ?>
									<?php endif; ?>
						
									<?php foreach ( WC()->cart->get_coupons( 'order' ) as $code => $coupon ) : ?>
										<tr class="order-discount coupon-<?php echo esc_attr( $code ); ?>">
											<th><?php _e( 'Coupon:', 'vibe' ); ?> <?php echo esc_html( $code ); ?></th>
											<td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
										</tr>
									<?php endforeach; ?>
						
									<?php do_action( 'woocommerce_review_order_before_order_total' ); ?>
						
									<tr class="order-total">
										<th><?php _e( 'Order Total', 'vibe' ); ?></th>
										<td><?php wc_cart_totals_order_total_html(); ?></td>
									</tr>
						
									<?php do_action( 'woocommerce_review_order_after_order_total' ); ?>
						
								</tfoot>
								<tbody>
									<?php
										do_action( 'woocommerce_review_order_before_cart_contents' );
						
										foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
											$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
						
											if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
												?>
												<tr class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
													<td class="product-name">
														<?php echo apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key ); ?>
														<?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <strong class="product-quantity">' . sprintf( '&times; %s', $cart_item['quantity'] ) . '</strong>', $cart_item, $cart_item_key ); ?>
														<?php echo WC()->cart->get_item_data( $cart_item ); ?>
													</td>
													<td class="product-total">
														<?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?> <small>(Inclusive of all taxes)</small>
													</td>
												</tr>
												<?php
											}
										}
						
									?>
								</tbody>
							</table>

                     <?php
				$cart =	ob_get_contents();
				ob_end_clean();
		$message .=				$cart.'</body>
						</html>' ;
		
		$headers .= "Reply-To: ".$_REQUEST['billing_email']." \r\n";
		
		$headers .= "MIME-Version: 1.0 \r\n";
		
		$headers .= "Content-type: text/html; charset=utf-8 \r\n";
		
		$headers .= "Content-Transfer-Encoding: quoted-printable \r\n";
					
		wp_mail( get_option( 'admin_email' ) , "A new sale initiated by ".$_REQUEST['billing_first_name']." ".$_REQUEST['billing_last_name']."@ ".site_url(), $message, $headers); 
		
		global $wpdb;
		
		/*$now = date('Y-m-d H:i:s');
		$wpdb->insert( 
			$wpdb->prefix.'cf7dbplugin_submits', 
			array( 
				'submit_time' 	=> 	$now ,
				'form_name'		=>	'Checkout New Sales',
				'field_name'	=>	'',
				'email'			=> 	$_REQUEST['user_email'] ,
				'phone' 		=> 	$_REQUEST['phone'], 
				'ip' 			=> 	$_SERVER['REMOTE_ADDR'] ,
				'visited_url' 	=> 	get_permalink($_REQUEST['page_id']), 
			)
		);
		*/
		$result['type'] = "success";
		$result['inserted_row'] = $wpdb->insert_id ;
      	$result = json_encode($result);
      	echo $result;
   }
   else {
      header("Location: ".$_SERVER["HTTP_REFERER"]);
   }

   die();
}


/*
*	WP ajax to get secutiry key for visitor form
*/
add_action("wp_ajax_nopriv_intellipaat_visitor_secure_key", "intellipaat_visitor_secure_key_callback");

function intellipaat_visitor_secure_key_callback() {
	die( wp_create_nonce("intellipaat_visitor_secure_signup_nonce") );
}

/*
*	WP ajax to to submit visitor form and regirter user.
*/
add_action("wp_ajax_nopriv_intellipaat_visitor_secure_signup", "intellipaat_visitor_secure_signup_callback");

function intellipaat_visitor_secure_signup_callback() {

   if ( !wp_verify_nonce( $_REQUEST['nonce'], "intellipaat_visitor_secure_signup_nonce") && !is_singular( 'course' )) {
      exit("No naughty business please");
   }   
   if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
	   		
		$fname  = isset($_REQUEST['first_name']) ? $_REQUEST['first_name'] : '' ;
		$lname  = isset($_REQUEST['last_name']) ? $_REQUEST['last_name'] : '' ;
		$email = $_REQUEST['user_email'];
		$mobile = isset($_REQUEST['phone']) ? $_REQUEST['phone'] : '';
		$country_code = $_REQUEST['country'];
		$country = WC()->countries->countries[$country_code];
		$course_title  = get_the_title($_REQUEST['page_id']);
		$message  = '';
		$referer  = get_permalink($_REQUEST['page_id']);
		$lead_source = 'Visitor Sign Up';
		
		global $wpdb;
		$now = date('Y-m-d H:i:s');
	   	$wpdb->insert( 
			$wpdb->prefix.'intellipaat_visitors', 
			array( 
				'name' => $fname.' '.$lname,
				'email' => $email,
				'phone' => $mobile, 
				'country' => $country,
				'course' => $course_title, 
				'ip' => $_SERVER['REMOTE_ADDR'] ,
				'visited_url' => $referer, 
				'date_time' => $now ,
			)
		);		

		/* Zoho code disabled temporary
		$xml  = '<?xml version="1.0" encoding="UTF-8"?>'; // same error with or without this line
		$xml .= '<Leads>';
		$xml .= '<row no="1">';
		if(isset($fname)) $xml .= '<FL val="First Name">'.$fname.'</FL>';
		if(isset($lname)) $xml .= '<FL val="Last Name">'.$lname.'</FL>';
		$xml .= '<FL val="Email">'.$email.'</FL>';
		if(isset($mobile))  $xml .= '<FL val="Mobile">'.$mobile.'</FL>';
		$xml .= '<FL val="Country">'.$country.'</FL>';
		$xml .= '<FL val="Courses">'.html_entity_decode($course_title,ENT_QUOTES, 'UTF-8').'</FL>';
		$xml .= '<FL val="Lead Source">'.$lead_source.'</FL>';
		$xml .= '<FL val="Referrer">'.$referer.'</FL>';
		$xml .= '</row>';
		$xml .= '</Leads>';
		ZohoCRM_API_call($xml); //Zoho CRM API call for lead genaration.*/
		
		if ( email_exists($email) == false ) {
			$user_id = wc_create_new_customer($email);
			
			if ( !is_wp_error( $user_id ) ){
				$userdata = array(
					'ID'			=>  $user_id,
					'first_name'	=>  $fname,
					'last_name'		=>  $lname,
					'display_name' 	=>	$fname.' '.$lname,
					//'user_pass'		=>  wp_generate_password( $length=12, $include_standard_special_chars=false )
				);
				//$user_id = wp_insert_user( $userdata ) ;
				wp_update_user( apply_filters( 'woocommerce_checkout_customer_userdata', $userdata, $this ) );
				
				update_user_meta($user_id, 'billing_first_name', $fname);
				update_user_meta($user_id, 'shipping_first_name', $fname);
				update_user_meta($user_id, 'billing_last_name', $lname);
				update_user_meta($user_id, 'shipping_last_name', $lname);
				update_user_meta($user_id, 'billing_email', $email);
				update_user_meta($user_id, 'billing_phone', $mobile);
				update_user_meta($user_id, 'billing_country', $country_code);
				update_user_meta($user_id, 'shipping_country', $country_code);
				wp_set_current_user($user_id);
				wp_set_auth_cookie($user_id);
				$result['user_id'] = $user_id ;	
			}	
			else{ //If user creation fails then send an email to admin 
				wp_mail( "mane.makarand@gmail.com" , "Visitor Sign up form user creation failure", print_r($user_id, TRUE) ); 
				$result['user'] = "No user account created and mail sent to admin";
			}
		} 
		
		setcookie('intellipaat_visitor', true, time()+60*60*24*30, '/');
		setcookie('intellipaat_visitor_email', $email, time()+60*60*24*30, '/');
		if($mobile)
			setcookie('intellipaat_visitor_phone', $mobile, time()+60*60*24*30, '/');
		
		$message = '<!DOCTYPE HTML>
						<html>
						<head></head>
						<body>
							<p>
								<strong>New Visitor</strong> @ '.site_url().' <br /><br />
								<strong>Full Name</strong> : '.$fname.' '.$fname.' <br />
								<strong>Email</strong> : '.$email.' <br />
								<strong>Phone</strong> : '.$mobile.'  <br />
								<strong>Country</strong> : '.$country.'  <br />
								<strong>Course Title</strong> : '.$course_title.'  <br />
								<strong>Visited url</strong> : '.$referer.'<br />
								<strong>IP Address </strong>: '.$_SERVER['REMOTE_ADDR'].' <br />
								<strong>Date/time</strong> '.$now.'
							</p>
						</body>
						</html>' ;
		
		$headers .= "Reply-To: ".$email." \r\n";
		
		$headers .= "MIME-Version: 1.0 \r\n";
		
		$headers .= "Content-type: text/html; charset=utf-8 \r\n";
		
		$headers .= "Content-Transfer-Encoding: quoted-printable \r\n";
		
		$headers .= 'Cc: sales@intellipaat.com' . "\r\n";
					
		wp_mail( get_option( 'admin_email' ) , "New visitor @ ".site_url(), $message, $headers); 
		
		$result['type'] = "success";
		$result['inserted_row'] = $wpdb->insert_id ;
      	$result = json_encode($result);
      	echo $result;
   }
   else {
      header("Location: ".$_SERVER["HTTP_REFERER"]);
   } 

   die();
}

/*
Query to create table

CREATE TABLE IF NOT EXISTS `ip_intellipaat_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `visited_url` varchar(150) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

*/
?>