<?php 

	global $post; 
	
	get_template_part('templates/sidebar', $post->post_type);

?>