<?php

require_once('non-com/intellipaat-ajax-actions.php');
require_once('non-com/intellipaat-theme-actions.php');
require_once('non-com/intellipaat-popup-login-signup-form.php');
require_once('non-com/intellipaat-woocommerce-actions.php');

?>