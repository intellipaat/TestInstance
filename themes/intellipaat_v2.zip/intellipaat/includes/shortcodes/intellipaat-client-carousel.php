<?php 
add_shortcode('carousel_thumb','carouselthumb_generator');

function carouselthumb_generator($atts){
	
	extract( shortcode_atts( array(

      'id'   => '',
	  'class'=> '',
	  
      ), $atts ) );
	
	$output = " ";
	
	if(isset($id) && !empty($id)){
	 $thumbs= explode(',' , $id);	
	
		//$output .= "<div class='v_module v_column stripe_container fullwidth v_first'>";
		
		 $output .= "<div id='thumb_carousel' class='thumb_carousel flexslider'  data-block-min='2' data-block-max='4' data-block-width='200'>";
		 
			$output .= "<ul class='slides'>";
		
			foreach($thumbs as $thumb){
				
				$output .= "<li>";
				
					$output .= wp_get_attachment_image( $thumb , 'full');
					
				$output .= "</li>"; 
				
			}
			
			$output .= "</ul>";
			
		  $output  .= "</div>";
			
		//$output .= "</div>";
		
	}
	
	return $output;
}

?>