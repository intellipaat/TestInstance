<?php

//add_action('user_register', 'create_zoho_account');


/**
* 	WSL action on thank you page to logout user to get social media icons
*/
function intellipaat_force_form_login()
{
	//var_dump($_SESSION);
	if(!$_SESSION['checkout_user_ID'] || !is_wc_endpoint_url('order-received') )
		return;
		
	global $current_user;
	$current_user = null;
	wp_set_current_user( 0 );
	wp_destroy_current_session();
	wp_clear_auth_cookie();	
	unset($current_user);
}

add_action( 'wordpress_social_login', 'intellipaat_force_form_login' , 1  );

/**
*	checks new user and register session veriable
*
*	apply_filters( 'wsl_hook_process_login_delegate_wp_insert_user', $userdata, $provider, $hybridauth_user_profile )
*/
function intellipaat_map_user_id($userdata, $provider, $hybridauth_user_profile){
	if(!$_SESSION['checkout_user_ID'])
		return;
		
	$user_id = $_SESSION['checkout_user_ID'];
	unset($_SESSION['order_billing_email'] , $_SESSION['order_id'] ,$_SESSION['checkout_user_created'], $_SESSION['checkout_user_ID']);
	
	$_SESSION['intellipaat_map_user'] = TRUE;
	return $user_id;
}
add_filter( 'wsl_hook_process_login_delegate_wp_insert_user', 'intellipaat_map_user_id', 1, 3 );

//add_action('wsl_hook_process_login_before_wp_insert_user')

/**
*	checks new user and register session veriable
*/

add_action( "wsl_process_login_update_wsl_user_data_start", 'intellipaat_process_login_update_wsl_user_data_start' , 10, 5);

function intellipaat_process_login_update_wsl_user_data_start($is_new_user , $user_id, $provider, $adapter, $hybridauth_user_profile){
	if($is_new_user && !$_SESSION['intellipaat_map_user'])
		$_SESSION['intellipaat_is_new_user'] = TRUE;
}


/**
* 	Save users details.
*/

add_action( "wsl_process_login_authenticate_wp_user_start", 'intellipaat_process_login_authenticate_wp_user_start', 10 , 5); 

function intellipaat_process_login_authenticate_wp_user_start($user_id, $provider, $redirect_to, $adapter, $hybridauth_user_profile ){
	
	if($_REQUEST['intellipaat_profile_completion']){
				
		update_user_meta( $user_id, 'billing_first_name'   , $hybridauth_user_profile->firstName );
		update_user_meta( $user_id, 'billing_last_name' , $hybridauth_user_profile->lastName );
				
		update_user_meta( $user_id, 'billing_email'   , $hybridauth_user_profile->email);
		update_user_meta( $user_id, 'billing_city'   , $_REQUEST['city'] );
		update_user_meta( $user_id, 'billing_country' , $_REQUEST['country'] );
		update_user_meta( $user_id, 'billing_phone' , $_REQUEST['phone'] );
		
		unset($_SESSION['intellipaat_is_new_user']);
		
	}
	unset($_SESSION['order_billing_email'] , $_SESSION['order_id'] ,$_SESSION['checkout_user_created'], $_SESSION['checkout_user_ID'], $_SESSION['intellipaat_map_user']);
}



/**
* 	Asks for update details if new user.
*/

add_action( 'wsl_hook_process_login_before_wp_set_auth_cookie', 'intellipaat_hook_process_login_before_wp_set_auth_cookie', 10, 3);

function intellipaat_hook_process_login_before_wp_set_auth_cookie($user_id, $provider, $hybridauth_profile ){

	if(!$_SESSION['intellipaat_is_new_user'])
		return;
		
	/*$user = get_userdata($user_id);
	$billing_city 		= 	get_user_meta( $user_id, 'billing_city' 	, TRUE ); 
	$billing_city		=	$billing_city ? $billing_city : $hybridauth_profile->city;
	$billing_country	= 	get_user_meta( $user_id, 'billing_country'	, TRUE ); 
	$billing_country	=	$billing_country ? $billing_country : $hybridauth_profile->country;
	$billing_phone 		= 	get_user_meta( $user_id, 'billing_phone' , TRUE ); 
	$billing_phone		=	$billing_phone ? $billing_phone : $hybridauth_profile->phone;*/
		
	$assets_base_url = WORDPRESS_SOCIAL_LOGIN_PLUGIN_URL . '/assets/img/16x16/';
?>
	<!DOCTYPE html>
		<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Complete your profile - <?php echo get_bloginfo('name'); ?></title>
		<head>
			<style> 
				body.login{background:0 repeat scroll 0 0 #fbfbfb;min-width:0}body,#wpbody,.form-table .pre,.ui-autocomplete li a{color:#333}body{font-family:sans-serif;font-size:12px;line-height:1.4em;min-width:600px;}html,body{height:100%;margin:0;padding:0}#login{margin:auto;padding:114px 0 0;width:400px; max-width:96%;}div.updated,.login .message{background-color:#ffffe0;border-color:#e6db55}.message{margin:0 0 16px 8px;padding:12px;border-radius:3px 3px 3px 3px;border-style:solid;border-width:1px}.info{font-family:sans-serif;font-size:12px;line-height:1.4em}.login form{background:0 repeat scroll 0 0 #fff;border:1px solid #e5e5e5;box-shadow:0 4px 10px -1px rgba(200,200,200,.7);font-weight:400;margin-left:8px;padding:26px 24px 46px;border-radius:3px 3px 3px 3px}.login label{color:#777;font-size:14px;cursor:pointer;vertical-align:middle}input[type="text"]{background:0 repeat scroll 0 0 #fbfbfb;border:1px solid #e5e5e5;box-shadow:1px 1px 2px rgba(200,200,200,.2) inset;color:#555;font-size:24px;font-weight:200;line-height:1;margin-bottom:16px;margin-right:6px;margin-top:2px;outline:0 none;padding:3px;width:100%}.button-primary{display:inline-block;text-decoration:none;font-size:12px;line-height:23px;height:24px;margin:0;padding:0 10px 1px;cursor:pointer;border-width:1px;border-style:solid;-webkit-border-radius:3px;-webkit-appearance:none;border-radius:3px;white-space:nowrap;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;background-color:#21759b;background-image:-webkit-gradient(linear,left top,left bottom,from(#2a95c5),to(#21759b));background-image:-webkit-linear-gradient(top,#2a95c5,#21759b);background-image:-moz-linear-gradient(top,#2a95c5,#21759b);background-image:-ms-linear-gradient(top,#2a95c5,#21759b);background-image:-o-linear-gradient(top,#2a95c5,#21759b);background-image:linear-gradient(to bottom,#2a95c5,#21759b);border-color:#21759b;border-bottom-color:#1e6a8d;-webkit-box-shadow:inset 0 1px 0 rgba(120,200,230,.5);box-shadow:inset 0 1px 0 rgba(120,200,230,.5);color:#fff;text-decoration:none;text-shadow:0 1px 0 rgba(0,0,0,.1);float:right;height:36px;}#login{width:580px}.error{margin:0 0 16px 8px;padding:12px;border-radius:3px 3px 3px 3px;border-style:solid;border-width:1px;background-color: #FFEBE8;border:1px solid #CC0000;}
			</style>
			<script>
				function init() {
					if( document.getElementById('city') ) document.getElementById('city').focus()
					if( document.getElementById('country') ) document.getElementById('country').focus()
				}
			</script>
		</head>
		<body class="login" onLoad="init();"> 
			<div id="login">
               
                    <h2 style="padding:0 10px;"> Hello <?php echo $hybridauth_profile->firstName.' '.$hybridauth_profile->lastName ?>,</h2>
            
    
				<?php var_dump($hybridauth_profile);
					if( ! isset( $_REQUEST["intellipaat_profile_completion"] ) ){ 
						?><p class="message"><?php _wsl_e( "Almost there, we just need to finish few more details.", 'wordpress-social-login' ); ?></p><?php
					}
					elseif( $shall_pass_errors ){ 
						foreach( $shall_pass_errors as $k => $v ){
							?><p class="error"><?php echo $k; ?></p><?php
						}
					} 
				?>
				<form method="post" action="<?php echo site_url( 'wp-login.php', 'login_post' ); ?>" id="loginform" name="loginform"> 
                
						<p>
							<label for="city"><?php _wsl_e( "City", 'wordpress-social-login' ); ?><br><input type="text" name="city" id="city" class="input" value="<?php echo $hybridauth_profile->city ?>" size="25" required /></label>
						</p>	
    
						<p>
							<label for="country"><?php _wsl_e( "Country", 'wordpress-social-login' ); ?><br><input type="text" name="country" id="country" class="input" value="<?php echo $hybridauth_profile->country ?>" size="25" required /></label>
						</p>	
    
						<p>
							<label for="phone"><?php _wsl_e( "Mobile", 'wordpress-social-login' ); ?><br><input type="text" name="phone" id="phone" class="input" value="<?php echo $hybridauth_profile->phone ?>" size="25" required /></label>
						</p>
                        
					<table width="100%" border="0">
						<tr>
							<td valign="bottom">
								<span class="info">
									<img src="<?php echo $assets_base_url . strtolower( $provider ) . '.png' ?>" style="vertical-align: top;width:16px;height:16px;" />
									<?php _wsl_e("You are now connected via", 'wordpress-social-login' ); ?> <b><?php echo ucfirst($provider) ?></b>.
								</span>
							</td>
							<td>
								<input type="submit" value="<?php _wsl_e( "Continue", 'wordpress-social-login' ); ?>" class="button button-primary button-large" id="wp-submit" name="wp-submit"> 
							</td>
						</tr>
					</table>
	
					<input type="hidden" id="redirect_to" name="redirect_to" value="<?php echo $_REQUEST['redirect_to'] ?>"> 
					<input type="hidden" id="provider" name="provider" value="<?php echo $provider ?>"> 
					<input type="hidden" id="action" name="action" value="wordpress_social_profile_completion">
					<input type="hidden" id="intellipaat_profile_completion" name="intellipaat_profile_completion" value="1">
				</form>
			</div> 
		</body>
	</html> 
	<?php  
			die();
}
?>