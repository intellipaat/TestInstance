<?php

global $post;

function register_my_session()
{
  if( !session_id() )
  {
    session_start();
  }
}

add_action('init', 'register_my_session');

/*
*	cusotm fucntion by makarand to point urls to intellipaat.com website
*/
add_filter( 'vibe-opts-sections-wplms', 'intellipaat_sttings_in_wplms', 10, 1 );
function intellipaat_sttings_in_wplms($args){
	
	$args[1]['fields'][]= array(
								'id'	=> 'header_banner_code',
								'type'	 => 'textarea',
								'title'	=> 'Header text banner',
								'sub_desc'	=> 'Banner code text/HTML',
								'desc'	=> "Please enter text or HTML code for text banner which will be displayed above header." 
							);
	
	$args[1]['fields'][]= array(
								'id'	=> 'header_banner_color',
								'type'	 => 'color',
								'title'	=> 'Header banner color',
								'std'	=>	'#FFFFFF',
								'sub_desc'	=> 'Text color in Hex format',
								'desc'	=> "Please click on input box. You will be hsown a color picker. Choose color which you want to apply for text of Header text banner." 
							);
	
	$args[1]['fields'][]= array(
								'id'	=> 'header_banner_bg_color',
								'type'	 => 'color',
								'title'	=> 'Header banner Background',
								'std'	=>	'#3B385F',
								'sub_desc'	=> 'Background color in Hex format',
								'desc'	=> "Please click on input box. You will be hsown a color picker. Choose color which you want to apply for background of Header text banner." 
							);
	
	$args[1]['fields'][]= array(
								'id'	=> 'header_banner_bg_image',
								'type'	 => 'upload',
								'title'	=> 'Header banner Background',
								'sub_desc'	=> 'Background image JPG/PNG/GIF',
								'desc'	=> "Upload an image for background of Header text banner." 
							);
	
	$args[1]['fields'][]= array(
								'id'	=> 'tracking_code',
								'type'	 => 'textarea',
								'title'	=> 'Google analytics or any tracking code',
								'sub_desc'	=> 'Insert javascript/CSS code in html head section',
								'desc'	=> "Please enter full code with javascript tags. (May be Google analytics or any tracking code or CSS). This code will be kept before closing of &lt;/head&gt; tag" 
							);
	
	$args[1]['fields'][]= array(
								'id'	=> 'home_page_head_scripts',
								'type'	 => 'textarea',
								'title'	=> 'Custom Home page Scripts',
								'sub_desc'	=> 'Javascript/CSS code in html head section',
								'desc'	=> "Whatever You you will put only displayed on Home Page. (May be JS or CSS code). This code will be kept before closing of &lt;/head&gt; tag" 
							);
	
	$args[8]['fields'][4]['title'] = 'Google analytics or any tracking code';
	$args[8]['fields'][4]['sub_desc']= 'Insert javascript code in html body section';
	$args[8]['fields'][4]['desc']= "Please enter full code with javascript tags. This code will be kept before closing of &lt;/body&gt; tag" ;
	
	$args[] = array(
						'title'	=>	'Intellipaat Customs',
						'desc'	=>	'This is Custom tab created by Makarand to add cusotm options for Intellipaat website.',
						'icon'	=>	'admin-generic',
						'fields'=>	array(										  
										array(
											'id'	=> 'browse_courses',
											'type'	 => 'text',
											'title'	=> 'Browse courses',
											'sub_desc'	=> 'Course catgories in browse courses menu',
											'desc'	=> "Enter ID number of all Course categories saperated by comma(,). Write in order as wish to display in front end." 
										),										  
										array(
											'id'	=> 'excluded_pages',
											'type'	 => 'text',
											'title'	=> 'Excluded pages from sitemap',
											'sub_desc'	=> 'ID number of Excluded pages',
											'desc'	=> "Enter ID number of pages saperated by comma(,). Enter only ID number of pages which you like to be excluded on <a href='".esc_url( get_permalink( get_page_by_title( 'sitemap' ) ) )."'>sitemap page</a>." 
										),									  
										array(
											'id'	=> 'zoho_api_key',
											'type'	 => 'text',
											'title'	=> 'Zoho Api Key',
											'sub_desc'	=> 'Secret auth tokens for Zoho API calls',
											'std'	=> '',
											'desc'	=> "For Zoho API calls, Secret auth token is needed. Enter here a Secret auth token, Genarated on Zoho accounts settings page, click on this <a href='https://accounts.zoho.com/u/h#setting/authtoken'>link</a> to get your secret token." 
										),							  
										array(
											'id'	=> 'base_currency_conversion_rate',
											'type'	 => 'text',
											'title'	=> 'Currency Conversion Rate',
											'sub_desc'	=> 'Currency Conversion Rate for Base currency',
											'std'	=> 1,
											'desc'	=> "Enter Currency Conversion Rate to convert Base currency to display in front end everywhere." 
										),
										array(
											'id'	=> 'checkout_conversion_pixel_code',
											'type'	 => 'textarea',
											'title'	=> 'Checkout page Conversion pixel',
											'sub_desc'	=> 'Before payment Conversion pixel code',
											'desc'	=> "Please enter full code with javascript tags. This code will be kept before closing of &lt;/head&gt; tag on Checkout page." 
										),
										array(
											'id'	=> 'order_received_conversion_code',
											'type'	 => 'textarea',
											'title'	=> 'Conversion Pixel codes',
											'sub_desc'	=> 'Conversion Pixel code on thank you page',
											'desc'	=> "Please enter full code with javascript tags. This code will be kept before closing of &lt;/head&gt; tag on thank you page." 
										),
										array(
											'id'	=> 'self_pace_course_conversion_code',
											'type'	 => 'textarea',
											'title'	=> 'Self paced course Conversion Pixel',
											'sub_desc'	=> 'Conversion Pixel code on purchase of self paced course',
											'desc'	=> "Please enter full code with javascript tags. This code will be kept before closing of &lt;/body&gt; tag on thank you page." 
										),
										array(
											'id'	=> 'online_training_course_conversion_code',
											'type'	 => 'textarea',
											'title'	=> 'Online Training Course Conversion Pixel',
											'sub_desc'	=> 'Conversion Pixel code on purchase of Online Training course',
											'desc'	=> "Please enter full code with javascript tags. This code will be kept before closing of &lt;/body &gt; tag  on thank you page." 
										),
										array(
											'id' => 'turn_on_ssl',
											'type' => 'button_set',
											'title' => __('Front End SSL Mode', 'vibe'), 
											'sub_desc' => __('Turn on SSL mode for Whole website', 'vibe'),
											'desc' => __('If you enable this, then "Whole Site" will force the whole site to use SSL (not recommended unless you have a really good reason to use it). Make sure that port 443 is enabled and SSL certificate installed for '.site_url(), 'vibe'),
											'options' => array(0 => __('Disable','vibe'),1 => __('Enable','vibe')),
											'std' => 0
										), 
									),						
					);
	
	return $args;
}

/*
 *	Enqueue CSS and JS on website
 */
function intellipaat_javascripts() {
	
	if( !is_admin()){
		 //Removing Woocommerce unnecessary javascripts
		if((is_single() && get_post_type() != 'product') || (is_page() && !is_page('cart') && !is_page('checkout')) || is_home() || is_front_page()){
			wp_deregister_script( 'woocommerce' );
			wp_deregister_script( 'wc-cart-fragments' );
		}
		
		/*wp_enqueue_style( 'intellipaat-mobile', get_stylesheet_directory_uri() .'/css/mobile.css', array('style-css','theme-css') );
		wp_enqueue_script('responsive-tabs', 
						  get_stylesheet_directory_uri().'/js/responsive-tabs.js', 
						  array('jquery','jquery-ui-core') );
		*/		
		wp_enqueue_script('intellipaat_script', 
						  get_stylesheet_directory_uri().'/js/custom.js', 
						  array('jquery','jquery-ui-core'), //,'responsive-tabs'
						  '1.0', 
						  true);
		global $wp;
		$settings_array = array(
			'cartUrl' => WC()->cart->get_cart_url(),
			'cart_ajax_url' => admin_url('admin-ajax.php?action=intellipaat_cart'),
			'SecKeyLink'	=>	admin_url('admin-ajax.php?action=intellipaat_visitor_secure_key'),
			'currentPage'	=>	home_url(add_query_arg(array(),$wp->request))
		); 
		if(isset($_SESSION['new_product_added']) || (isset($_GET['removed_item']) && !is_page('cart')  && !is_page('checkout') )){
			$settings_array['new_product_added'] = 1;
			unset($_SESSION['new_product_added']);
		}else{
			$settings_array['new_product_added'] = 0;
		}
		if(is_page('cart')){ $settings_array['cart_page'] = 1; } else { $settings_array['cart_page'] = 0; }
		if(is_page('checkout')){ $settings_array['saleInitiateUrl'] = admin_url('admin-ajax.php?action=intellipaat_visitor_purchase'); } 
		wp_localize_script( 'intellipaat_script', 'intellipaat', $settings_array );

		
		/*if ( ! function_exists( 'is_plugin_active_for_network' ) )
			require_once( ABSPATH . '/wp-admin/includes/plugin.php' );
			// Makes sure the plugin is defined before trying to use it
			
		if ( is_plugin_active_for_network('woocommerce/woocommerce.php') ||  in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {     
		   wp_deregister_style( 'woocommerce_chosen_styles' );
		   wp_enqueue_style( 'woocommerce-css', VIBE_URL .'/css/woocommerce.css' );
		}*/
		if(is_page(array('Online training calendar','online-training-calendar')) || is_singular('course'))
			wp_enqueue_script('moment',get_stylesheet_directory_uri().'/js/moment.min.js','','2.8.2', false );
	}
 
}
add_action('wp_enqueue_scripts', 'intellipaat_javascripts', 30);


/*
 *	cusotm javascripts to be added on home page head
 */

add_action('wp_head','intellipaat_print_head_scripts', 50);

function intellipaat_print_head_scripts()
{
	
	echo vibe_get_option('tracking_code');

	if(is_home() || is_front_page()){
		echo vibe_get_option('home_page_head_scripts');
	}
}


/*
*	Modifyied search for course search
*	http://wpsnipp.com/index.php/functions-php/limit-search-to-post-titles-only/
*	http://www.paulund.co.uk/limit-wordpress-search-to-post-titles
*/
function search_by_title_only( $search, &$wp_query )
{
    global $wpdb;

    if ( empty( $search ) || !isset($_GET['post_type']))
        return $search; // skip processing - no search term in query

    $q = $wp_query->query_vars;    
    $n = ! empty( $q['exact'] ) ? '' : '%';

    $search =
    $searchand = '';

    foreach ( (array) $q['search_terms'] as $term ) {
        $term = esc_sql( like_escape( $term ) );
        $search .= "{$searchand}($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
        $searchand = ' AND ';
    }

    if ( ! empty( $search ) ) {
        $search = " AND ({$search}) ";
        if ( ! is_user_logged_in() )
            $search .= " AND ($wpdb->posts.post_password = '') ";
    }

    return $search;
}
add_filter( 'posts_search', 'search_by_title_only', 500, 2 );

/**
 * 		Change order of posts on course search page
 */
function modify_main_query( $query ) {
	//if($query->is_main_query()); die();

	/**
	* http://wordpress.stackexchange.com/questions/72099/can-i-exclude-a-post-by-meta-key-using-pre-get-posts-function
	*/	
	
	/*if ( !is_admin() && $query->is_main_query() && $query->is_tax/*( !empty( $query->query['post_type'])  && $query->query['post_type']==  'course' ) ) {

		$query->set( 'orderby', 'menu_order');
		$query->query[ 'orderby']= 'menu_order';
		
		return;
	}*/
	
	
	if(!is_admin() && is_search() && is_main_query() && isset($_GET['post_type']) && isset($query->query["s"]) && $query->query["post_type"]=="course") {
		$query->set('orderby', 'meta_value_num');
		$query->set('order', 'DESC');
		$query->set('meta_key', 'vibe_students');
	}	//search results order set according to no of students enrolled in course
	
	return $query;

}
add_action( 'pre_get_posts', 'modify_main_query', 10 );

/**
 * 		Change order of posts on course category page
 */
function custom_courses_orderby($orderby) {
	global $wpdb;	
	if ( !is_admin() && is_main_query() && is_tax('course-cat') ) {
		$orderby = $wpdb->prefix . "posts.menu_order  ASC";
	}
	
	return $orderby;
}
add_filter('posts_orderby', 'custom_courses_orderby', 1);


/**
 * Remove the slug from published post permalinks.
 *
 * http://colorlabsproject.com/tutorials/remove-slugs-custom-post-type-url/
 */
function intelli_remove_cpt_slug( $post_link, $post, $leavename ) {
 
 
	if ( 'news' == $post->post_type && !is_admin() && (is_home() || is_front_page()) ) {
		$post_link = get_post_meta($post->ID, 'intellipaat-post-href', true);
		if($post_link)
			return $post_link.'" rel="nofollow noindex';
		else
			return site_url('media');
	}
	
	if ( 'post' == $post->post_type ) {
		$link = get_post_meta($post->ID, 'intellipaat_custom_blog_url', true);
		if(!empty($link))
			return $link;
		else
			return $post_link;
	}
	
	if ( 'course' != $post->post_type || 'publish' != $post->post_status ) {
		return $post_link;
	}
	$post_link = str_replace( '/' . $post->post_type . '/', '/', $post_link );
	 
	return $post_link;
}
add_filter( 'post_type_link', 'intelli_remove_cpt_slug', 10, 3 );
add_filter( 'post_link', 'intelli_remove_cpt_slug', 10, 3 );

	
	
/**
 * Some hackery to have WordPress match postname to any of our public post types
 * All of our public post types can have /post-name/ as the slug, so they better be unique across all posts
 * Typically core only accounts for posts and pages where the slug is /post-name/
 */
function custom_parse_request_tricksy( $query ) {
 
    // Only noop the main query
    if ( ! $query->is_main_query() )
        return;
 
    // Only noop our very specific rewrite rule match
    if ( 2 != count( $query->query ) || ! isset( $query->query['page'] ) ) {
        return;
    }
 
    // 'name' will be set if post permalinks are just post_name, otherwise the page rule will match
    if ( ! empty( $query->query['name'] ) ) {
        $query->set( 'post_type', array( 'post', 'course', 'page' ) );
    }
}
add_action( 'pre_get_posts', 'custom_parse_request_tricksy' );


/*
*	Force SSL on front end using theme options
*/
function force_ssl()
{	
    if (vibe_get_option('turn_on_ssl') && !is_ssl () )
    {
		wp_redirect('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301 );
		//header('HTTP/1.1 301 Moved Permanently');
      	//header("Location: https://" . $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"]);
     	exit();
    }
}
add_action('template_redirect', 'force_ssl');

/*
*	Custom function which will rewrite all url coming from database (non conditional action)
*/
function custom_ssl_url_scheme($url){
	return str_replace(array('http://intellipaat.com','http://intellipaat.in'),array('https://intellipaat.com','https://intellipaat.in'), $url );
}
add_filter('set_url_scheme', 'custom_ssl_url_scheme',10,1);

/*
uses define('FRONT_END_SSL' , false);
if (defined('FRONT_END_SSL'))
	add_action('template_redirect', 'force_ssl');
	
function force_ssl(){	
	
    if ( FRONT_END_SSL && !is_ssl () )
    {
		wp_redirect('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], 301 );
		//header('HTTP/1.1 301 Moved Permanently');
      	//header("Location: https://" . $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"]);
     	exit();
    }
}*/


/*
*	WPSEO breadcrumb modificaton
*/
function intellipaat_breadcrumb_output($output){
	if(is_single() || is_page()){
		return str_replace(array('<span typeof="v:Breadcrumb"><strong class="breadcrumb_last" property="v:title"'),array('<span><strong class="breadcrumb_last"'),$output);
	}
	return $output;
}
add_filter(  'wpseo_breadcrumb_output', 'intellipaat_breadcrumb_output');


/*
*	Zoho CRM API calll before we send email to admin using cform 7
*/
//add_action( 'wpcf7_before_send_mail', 'intellipaat_cform7_WebToLead' );
function intellipaat_cform7_WebToLead( $cf7 )
{
	$submission = WPCF7_Submission::get_instance();
	if($submission && ($cf7->id == 2101 || $cf7->id == 2129)) {
		$posted_data = $submission->get_posted_data();	
		
		/*$email = $cf7->posted_data["your-email"];
		$first_name  = $cf7->posted_data["your-firstname"];
		$last_name  = $cf7->posted_data["your-lastname"];
		$phone = $cf7->posted_data["your-phone"];
		$company = $cf7->posted_data["your-company"];
		$message  = $cf7->posted_data["your-message"];
		$lead_source = $cf7->title;*/
		$email = $posted_data["email"];
		$fname  = $posted_data["firstname"];
		$lname  = $posted_data["lastname"];
		$mobile = $posted_data["mobile"];
		$country = $posted_data["country"];
		$description  = $posted_data["description"];
		$referer  = $posted_data["referer"];
		$course_title  = $posted_data["course_title"];
		$lead_source = $cf7->title;

		$xml  = '<?xml version="1.0" encoding="UTF-8"?>'; // same error with or without this line
		$xml .= '<Leads>';
		$xml .= '<row no="1">';
		$xml .= '<FL val="First Name">'.$fname.'</FL>';
		$xml .= '<FL val="Last Name">'.$lname.'</FL>';
		$xml .= '<FL val="Email">'.$email.'</FL>';
		$xml .= '<FL val="Mobile">'.$mobile.'</FL>';
		$xml .= '<FL val="Country">'.$country.'</FL>';
		$xml .= '<FL val="Description">'.$description.'</FL>';
		$xml .= '<FL val="Lead Source">'.$lead_source.'</FL>';
		$xml .= '<FL val="Referrer">'.$referer.'</FL>';
		$xml .= '<FL val="Courses">'.$course_title.'</FL>';
		$xml .= '</row>';
		$xml .= '</Leads>'; 
		
		ZohoCRM_API_call($xml);
	}
}

function ZohoCRM_API_call($xml){
		//var_dump($xml); 
		$authtoken = vibe_get_option('zoho_api_key');
		$url ="https://crm.zoho.com/crm/private/xml/Leads/insertRecords";
		$data="authtoken=".$authtoken."&scope=crmapi&xmlData=".$xml;
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_POST,1);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch,CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT, 5);
		
		//Execute cUrl session
		$response = curl_exec($ch);
		curl_close($ch);	
		//var_dump($response); die();
}

?>