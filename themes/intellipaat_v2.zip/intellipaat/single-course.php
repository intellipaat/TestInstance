<?php 
	get_header( 'buddypress' );
?>
<section id="content">
	<div class="course-breadcrumb container">
	
		<?php vibe_breadcrumbs(); ?>
    
    </div>
	<div id="buddypress">
	    <div class="container">
	        <div class="row">
	            <div class="col-md-3 col-sm-3">
					<?php if ( bp_course_has_items() ) : while ( bp_course_has_items() ) : bp_course_the_item(); ?>

					<?php do_action( 'bp_before_course_home_content' ); ?>

					<div id="item-header" role="complementary">

						<?php locate_template( array( 'course/single/course-header.php' ), true ); ?>

					</div><!-- #item-header -->
			
				<div id="item-nav">
					<div class="item-list-tabs no-ajax" id="object-nav" role="navigation">
                    	<?php 
							$content = get_the_content();
							$curriculum = get_field( "intellipaat_curriculum" );
							$course_and_infographics = get_field( "intellipaat_about_course_and_infographics" );
							$title_course_and_infographics = get_field( "intellipaat_title_for_what_is_this_course_tab" );
							if(!$title_course_and_infographics)
								$title_course_and_infographics = "What is ".get_the_title();
							$is_faq = get_field( "course_faq" );
							$data_index = 0;
						?>
						<ul>
                        	<?php if(isset($content) && !empty($content)){ $about_index=$data_index;?><li class="about-us selected" ><a href="#about-us" data-index="<?php echo $data_index; $data_index++; ?>">About Course</a></li><?php }?>
                            <?php if(isset($curriculum) && !empty($curriculum)){?><li class="curriculum"><a href="#curriculum" data-index="<?php echo $data_index; $data_index++; ?>" >Course Content</a></li><?php }?>
                            <?php if (isset($content) && !empty($content)) { ?><li class="sample-video" ><a href="#about-us" data-index="<?php echo $about_index; ?>">Watch sample video</a></li><?php } ?> 
                            <?php if(isset($is_faq) && !empty($is_faq)){?><li class="faq"><a href="#faq" data-index="<?php echo $data_index; $data_index++; ?>" >FAQ</a></li><?php }?>
							<?php if(isset($course_and_infographics) && !empty($course_and_infographics)){?><li class="course_and_infographics"><a href="#course_and_infographics" data-index="<?php echo $data_index; $data_index++; ?>" ><?php echo $title_course_and_infographics ?></a></li><?php }?>
                            <li class="self-instructor"><a href="#self-instructor" class="scrollMe" >Self-Paced Vs Instructor LED Online</a></li>
                           
							<?php //bp_get_options_nav(); ?>
                            
							<?php

							/*if(function_exists('bp_course_nav_menu'))
								bp_course_nav_menu();
							else{*/
							?>	
							<?php /*?><li id="home" class="<?php echo (!isset($_GET['action'])?'selected':''); ?>"><a href="<?php bp_course_permalink(); ?>"><?php  _e( 'Home', 'vibe' ); ?></a></li>
							<li id="curriculum" class="<?php echo (($_GET['action']=='curriculum')?'selected':''); ?>"><a href="<?php bp_course_permalink(); ?>?action=curriculum"><?php  _e( 'Curriculum', 'vibe' ); ?></a></li>
							<li id="members" class="<?php echo (($_GET['action']=='members')?'selected':''); ?>"><a href="<?php bp_course_permalink(); ?>?action=members"><?php  _e( 'Members', 'vibe' ); ?></a></li><?php */?>
							
							<?php
							//}
							/*$vgroup=get_post_meta(get_the_ID(),'vibe_group',true);
							if(isset($vgroup) && $vgroup){
								$group=groups_get_group(array('group_id'=>$vgroup));
							?>
							<li id="group"><a href="<?php echo bp_get_group_permalink($group); ?>"><?php  _e( 'Group', 'vibe' ); ?></a></li>
							<?php
							}	
							$forum=get_post_meta(get_the_ID(),'vibe_forum',true);
							if(isset($forum) && $forum){
							?>
							<li id="forum"><a href="<?php echo get_permalink($forum); ?>"><?php  _e( 'Forum', 'vibe' ); ?></a></li>
							<?php 
							}
							if(is_super_admin() || is_instructor()){
								?>
								<li id="admin" class="<?php echo ((isset($_GET['action']) && $_GET['action']=='admin')?'selected':''); ?>"><a href="<?php bp_course_permalink(); ?>?action=admin"><?php  _e( 'Admin', 'vibe' ); ?></a></li>
								<?php
							}*/					
							?>
                            
                            <li class="reviews"><a href="#reviews" class="scrollMe" >Reviews</a></li>
                            <li class="certification"><a href="#certification" class="scrollMe" >Certification</a></li>                            
                            <li class="blog"><a href="https://intellipaat.com/blog/">Blog</a></li>
                            
							<?php do_action( 'bp_course_options_nav' ); ?>
						</ul>
					</div>
				</div><!-- #item-nav -->
                
			</div>
			<div class="col-md-6 col-sm-6">	
			<?php do_action( 'template_notices' ); ?>
            
            
            
			<div id="item-body">           
                
              <?php /*?>  <h1><?php the_title(); ?></h1><?php */?>
                
            	<?php 
					
					
					ob_start();
					
					echo '[tabs style="" theme=]';
					
					if(isset($content) && !empty($content)){
						echo '[tab title="About Course" icon=""]';
								locate_template( array( 'course/single/front.php' ), true );
						echo '[/tab]';
					}
					
					if(isset($curriculum) && !empty($curriculum)){
						echo '[tab title="Course Content" icon=""]';
								locate_template( array( 'course/single/curriculum.php'  ), true );
								
						echo '[/tab]';
					}
					
					if(isset($is_faq) && !empty($is_faq)){
						
						echo '[tab title="FAQ" icon=""]';
							echo "<div class='course_title'>";
								echo "<h2>Frequently Asked Questions</h2>";
								echo "</div>";
								echo "<div style='display:none;'>".do_shortcode('[agroup] [accordion title="&nbsp;&nbsp;"]&nbsp;&nbsp; [/accordion][/agroup]')."</div>";
								echo $is_faq;	
						echo '[/tab]';												
					}	
											
					if(isset($course_and_infographics) && !empty($course_and_infographics)){
						echo '[tab title="'.$title_course_and_infographics .'" icon=""]';
								echo $course_and_infographics;								
						echo '[/tab]';
					}
					
					echo '[/tabs]';
					
					$course_tabs = ob_get_contents();
					ob_end_clean();
					
					$course_tabs = do_shortcode($course_tabs);
					//$course_tabs = str_replace('</ul>', '<li><a href="#reviews" onclick="jQuery(\'body,html\').animate({ scrollTop: jQuery(\'#reviews\').offset().top -90 }, 1200); return false;" >Reviews</a></li></ul>', $course_tabs);
					echo $course_tabs;
					
					global $withcomments;
					$withcomments = true;
					comments_template('/course-review.php',true);
				?>
          		

				<?php 
				
				do_action( 'bp_before_course_body' );
				?>
				  
				<?php
				/**
				 * Does this next bit look familiar? If not, go check out WordPress's
				 * /wp-includes/template-loader.php file.
				 *
				 * @todo A real template hierarchy? Gasp!
				 */

				/*if(isset($_GET['action']) && $_GET['action']):

					/*switch($_GET['action']){
						case 'curriculum':
							locate_template( array( 'course/single/curriculum.php'  ), true );
						break;
						case 'members':
							locate_template( array( 'course/single/members.php'  ), true );
						break;
						case 'events':
							locate_template( array( 'course/single/events.php'  ), true );
						break;
						case 'admin':
							if(current_user_can( 'manage_options' ) || (get_current_user_id() == $post->post_author)){
								locate_template( array( 'course/single/admin.php'  ), true );	
							}else{
								locate_template( array( 'course/single/front.php' ) );
							}
							
						break;
						default:
							locate_template( array( 'course/single/front.php' ) );
					}*/
					
				
				/*else :
					
					if ( isset($_POST['review_course']) && isset($_POST['review']) && wp_verify_nonce($_POST['review'],get_the_ID()) ){
						 global $withcomments;
					      $withcomments = true;
					      comments_template('/course-review.php',true);
					}/*else if(isset($_POST['submit_course']) && isset($_POST['review']) && wp_verify_nonce($_POST['review'],get_the_ID())){ // Only for Validation purpose

						bp_course_check_course_complete();

						bp_course_record_activity(array(
					          'action' => 'Student Submitted the course '.get_the_title(),
					          'content' => 'Student '.bp_core_get_userlink(get_current_user_id()).' submitted the course '.get_the_title().' for evaluation',
					          'type' => 'submit_course',
					          'item_id' => get_the_ID(),
					          'primary_link'=>get_permalink(get_the_ID()),
					          'secondary_item_id'=>$user_id
					        ));	


					// Looking at home location
					}else if ( bp_is_course_home() ){

						// Use custom front if one exists
						$custom_front = locate_template( array( 'course/single/front.php' ) );
						if     ( ! empty( $custom_front   ) ) : load_template( $custom_front, true );
						
						elseif ( bp_is_active( 'structure'  ) ) : locate_template( array( 'course/single/structure.php'  ), true );

						// Otherwise show members
						elseif ( bp_is_active( 'members'  ) ) : locate_template( array( 'course/single/members.php'  ), true );

						endif;

					// Not looking at home
					}else {

						// Course Admin/Instructor
						if     ( bp_is_course_admin_page() ) : locate_template( array( 'course/single/admin.php'        ), true );

							// Course Members
						elseif ( bp_is_course_members()    ) : locate_template( array( 'course/single/members.php'      ), true );

						// Anything else (plugins mostly)
						else                                : locate_template( array( 'course/single/plugins.php'      ), true );

						endif;
					}
				endif;*/
					
				do_action( 'bp_after_course_body' ); ?>

			</div><!-- #item-body -->

			<?php do_action( 'bp_after_course_home_content' ); ?>

			<?php endwhile; endif; ?>
			</div>
			<div class="col-md-3 col-sm-3">
            	<?php if ( is_active_sidebar( 'contactus' ) ) : ?>          
         	
                	<?php dynamic_sidebar( 'contactus' ); ?>
             
              	<?php endif; ?>	
            		
				<div class="widget pricing">
					<?php intellipaat_selfpaced_course_button(); ?>
					<?php intellipaat_online_course_button(); ?>					
				</div>  
            		
				
				<?php  
                    if ( sizeof( WC()->cart->get_cart() ) > 0 ) {
                        $total = WC()->cart->cart_contents_count.' Course'.( WC()->cart->cart_contents_count > 1 ? 's' : '');
                        echo '<div class="widget woocart pricing">';
                        echo "You have ".$total." of ".WC()->cart->get_cart_total()." in your cart. (<a class='link' href='".WC()->cart->get_cart_url()."'>Edit Cart</a>)";
						echo '<p class="buttons">
								<a class="button wc-forward" href="'.site_url('all-courses/').'">Shop More</a>
								<a class="button checkout wc-forward" href="'.WC()->cart->get_checkout_url().'">Checkout</a>
							</p>';
                        echo '</div> ';
					}
                ?>					
				                       
                        
                        <?php				
							
							$key_feature = "";
							
							$key_feature_value = "";
							
							for($i=1; $i<=6 ; $i++){
								
								$key_value = get_field("course_".$i."_key_feature");
								
								$key_text = get_field("course_".$i."_key_feature_text");
								
								//check if both key and value are set
								if((isset($key_value) && !empty($key_value)) && (isset($key_text) && !empty($key_text))){
							
									$key_feature_value .=  "[accordion title='".get_field("course_".$i."_key_feature")."']";
									
									$key_feature_value .= get_field("course_".$i."_key_feature_text");
									
									$key_feature_value .= "[/accordion]";
								
								}
																				
							}
							
							//Check if anything is set..from all key features
							if(isset($key_feature_value) && !empty($key_feature_value)){
								
								$key_feature .= "[agroup]".$key_feature_value."[/agroup]" ;	
							?>                            
                            	 <div class="widget pricing">
                                 	
                                    <h3 style="margin-top:0;">Key Features :</h3>
                                    
                             		<?php 	echo do_shortcode($key_feature); ?>
                                    
                                    <?php intellipaat_the_course_details(); ?>
                             
                             	</div>                             
                            <?
								
							 }
							
						 ?>  
                         <div id="contact-form" class="widget pricing ">
                            <h3 class="contact-title">Drop Us A Query</h3>
                            <?php  echo do_shortcode('[contact-form-7 id="2101" title="Drop a Query Here"]');?>
                        </div>
                          
                         <?php
						 	/*
						 	if( class_exists('BP_Course_Widget') ){
								 
								$intellipaat_recommended_courses = get_post_meta( get_the_ID(), 'intellipaat_recommended_courses',true );//get_field('intellipaat_recommended_courses');
								
						 		$ids = implode(',',$intellipaat_recommended_courses);
								
								if(!$ids)
									$ids = '2482,2525,2357';
								
								$args = array(
									'before_widget' => '<div class="widget">',
									'after_widget' 	=> '</div>',
									'before_title' 	=> '<h4 class="widget_title">',
									'after_title' 	=> '</h4>'
								);
								
								$instance = array( 'title'=> 'Recommended Course','style' => 'single','orderby'=>'name','order'=>'DESC','category'=>'','ids'=>$ids , 'max_items' => 3 );
								
								the_widget( 'BP_Course_Widget', $instance, $args  ); 
								
							}*/
							
							
							$sidebar = apply_filters('wplms_sidebar','coursesidebar',get_the_ID());
							
							if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar($sidebar) ) : 
							
							endif;
							
							?>           
                
                </div>
				
               
			 	
                
			</div>
		</div><!-- .padder -->
		
	</div><!-- #container -->
	</div>
</section>	
<?php get_footer( 'buddypress' ); ?>
